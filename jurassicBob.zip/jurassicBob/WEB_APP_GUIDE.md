# Guia da Aplicação Web - EJB Test Application

## 📱 Visão Geral da Interface

Esta aplicação web fornece uma interface gráfica moderna e intuitiva para testar o EJB SimpleTest, permitindo comparar o desempenho entre interfaces Local e Remote.

## 🎨 Páginas da Aplicação

### 1. Página Inicial (`index.jsp`)

**URL**: `http://localhost:9080/`

**Funcionalidades**:
- Apresentação visual da aplicação
- Cards informativos sobre as funcionalidades
- Badges de tecnologias utilizadas
- Botão de acesso ao teste

**Design**:
- Layout responsivo com gradiente roxo
- Animações suaves
- Cards com hover effects
- Ícones emoji para melhor UX

**Código de Exemplo**:
```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>EJB 3.2 Test Application</title>
</head>
<body>
    <!-- Conteúdo da página -->
</body>
</html>
```

---

### 2. Página de Teste (`test.jsp`)

**URL**: `http://localhost:9080/test`

**Funcionalidades**:
- Formulário para entrada de mensagem
- Seleção de tipo de interface:
  - **Local**: Teste apenas interface local
  - **Remote**: Teste apenas interface remote
  - **Ambas**: Teste e compare ambas
- Validação de entrada
- Design moderno com radio buttons estilizados

**Campos do Formulário**:

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| message | text | Sim | Mensagem a ser processada pelo EJB |
| testType | radio | Sim | Tipo de interface (local/remote/both) |

**Exemplo de Uso**:
```html
<form action="test" method="post">
    <input type="text" name="message" value="Mundo" required>
    <input type="radio" name="testType" value="local" checked>
    <input type="radio" name="testType" value="remote">
    <input type="radio" name="testType" value="both">
    <button type="submit">Executar Teste</button>
</form>
```

**Validações**:
- Mensagem não pode estar vazia
- Tipo de teste deve ser selecionado
- Valores padrão fornecidos

---

### 3. Página de Resultados (`result.jsp`)

**URL**: `http://localhost:9080/test` (POST)

**Funcionalidades**:
- Exibição do resultado do EJB
- Métricas de performance detalhadas
- Comparação entre interfaces (quando ambas testadas)
- Informações técnicas contextuais
- Tratamento de erros

**Dados Exibidos**:

#### Em Caso de Sucesso:
- ✅ Mensagem de entrada
- 📤 Resultado retornado pelo EJB
- 🔌 Interface utilizada
- ⏱️ Tempo de execução (ms e µs)
- ℹ️ Informações técnicas sobre a interface

#### Em Caso de Erro:
- ❌ Tipo de erro
- 📝 Mensagem de erro detalhada
- 💡 Sugestões de solução

**Atributos da Requisição**:

```java
// Sucesso
request.setAttribute("success", true);
request.setAttribute("message", "Mundo");
request.setAttribute("result", "OlaMundo");
request.setAttribute("interfaceUsed", "Local");
request.setAttribute("executionTimeMs", "0.123");
request.setAttribute("executionTimeMicros", "123.456");

// Erro
request.setAttribute("success", false);
request.setAttribute("error", "Mensagem de erro");
request.setAttribute("errorType", "NullPointerException");
```

---

### 4. Página de Erro (`error.jsp`)

**URL**: Automática em caso de erro HTTP

**Funcionalidades**:
- Exibição amigável de erros
- Código de erro HTTP
- Botão para retornar à página inicial

**Erros Tratados**:
- 404 - Página não encontrada
- 500 - Erro interno do servidor

---

## 🔧 Servlet: EjbTestServlet

### Configuração

```java
@WebServlet(name = "EjbTestServlet", urlPatterns = {"/test"})
public class EjbTestServlet extends HttpServlet {
    @EJB
    private SimpleTestLocal simpleTestLocal;
    
    @EJB
    private SimpleTestRemote simpleTestRemote;
}
```

### Métodos

#### doGet()
- **Propósito**: Exibir formulário de teste
- **Ação**: Forward para `test.jsp`
- **Parâmetros**: Nenhum

#### doPost()
- **Propósito**: Processar teste do EJB
- **Parâmetros**:
  - `message`: String - Mensagem a processar
  - `testType`: String - Tipo de teste (local/remote/both)
- **Retorno**: Forward para `result.jsp` com atributos

### Fluxo de Execução

```
1. Usuário acessa /test (GET)
   ↓
2. Servlet exibe formulário (test.jsp)
   ↓
3. Usuário preenche e submete (POST)
   ↓
4. Servlet processa requisição
   ↓
5. Chama EJB (Local/Remote/Ambos)
   ↓
6. Mede tempo de execução
   ↓
7. Prepara atributos de resposta
   ↓
8. Forward para result.jsp
   ↓
9. Exibe resultados ao usuário
```

### Medição de Performance

```java
// Início
long startTime = System.nanoTime();

// Chamada EJB
String result = simpleTestLocal.hello(message);

// Fim
long endTime = System.nanoTime();

// Cálculo
long executionTime = endTime - startTime;
double executionTimeMs = executionTime / 1_000_000.0;
double executionTimeMicros = executionTime / 1000.0;
```

---

## 🎯 Casos de Uso

### Caso 1: Teste Interface Local

**Objetivo**: Testar chamada EJB local

**Passos**:
1. Acesse `http://localhost:9080/test`
2. Digite mensagem: "Teste Local"
3. Selecione: "Interface Local"
4. Clique em "Executar Teste"

**Resultado Esperado**:
- Resultado: "OlaTeste Local"
- Tempo: ~0.1-0.5 ms
- Interface: Local

---

### Caso 2: Teste Interface Remote

**Objetivo**: Testar chamada EJB remota

**Passos**:
1. Acesse `http://localhost:9080/test`
2. Digite mensagem: "Teste Remote"
3. Selecione: "Interface Remote"
4. Clique em "Executar Teste"

**Resultado Esperado**:
- Resultado: "OlaTeste Remote"
- Tempo: ~1-5 ms (maior que Local)
- Interface: Remote

---

### Caso 3: Comparação de Interfaces

**Objetivo**: Comparar performance Local vs Remote

**Passos**:
1. Acesse `http://localhost:9080/test`
2. Digite mensagem: "Comparação"
3. Selecione: "Ambas as Interfaces"
4. Clique em "Executar Teste"

**Resultado Esperado**:
```
Local: OlaComparação (tempo: 0.234 µs)
Remote: OlaComparação (tempo: 2.456 µs)
```

**Análise**:
- Interface Local é mais rápida
- Diferença devido ao overhead de serialização/rede
- Útil para decisões arquiteturais

---

## 🔍 Análise de Performance

### Fatores que Afetam Performance

#### Interface Local
- ✅ Sem serialização
- ✅ Sem overhead de rede
- ✅ Acesso direto à memória
- ⚡ Tempo típico: 0.1-1 ms

#### Interface Remote
- ⚠️ Serialização de objetos
- ⚠️ Overhead de rede (mesmo local)
- ⚠️ Protocolo RMI/IIOP
- 🐌 Tempo típico: 1-10 ms

### Quando Usar Cada Interface

#### Use Interface Local quando:
- Aplicação monolítica
- Componentes na mesma JVM
- Performance crítica
- Não há necessidade de distribuição

#### Use Interface Remote quando:
- Aplicação distribuída
- Componentes em JVMs diferentes
- Necessidade de escalabilidade horizontal
- Integração com sistemas externos

---

## 🎨 Personalização da Interface

### Cores e Temas

As cores principais estão definidas no CSS inline:

```css
/* Gradiente principal */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Cores de destaque */
--primary-color: #667eea;
--secondary-color: #764ba2;
--success-color: #28a745;
--error-color: #dc3545;
```

### Modificar Estilos

Para personalizar, edite os arquivos JSP:
- `index.jsp` - Página inicial
- `test.jsp` - Formulário
- `result.jsp` - Resultados
- `error.jsp` - Erros

### Adicionar Novos Campos

1. Adicione campo no formulário (`test.jsp`):
```html
<input type="text" name="novoCampo" placeholder="Novo campo">
```

2. Capture no Servlet:
```java
String novoValor = request.getParameter("novoCampo");
```

3. Processe e exiba no resultado

---

## 🧪 Testes

### Teste Manual Completo

```bash
# 1. Iniciar aplicação
./deploy-all.sh

# 2. Abrir navegador
open http://localhost:9080

# 3. Testar cada interface
# - Local
# - Remote  
# - Ambas

# 4. Verificar logs
tail -f simple-web/target/liberty/wlp/usr/servers/simpleWebServer/logs/messages.log
```

### Teste com cURL

```bash
# Teste Local
curl -X POST http://localhost:9080/test \
  -d "message=TesteCURL&testType=local" \
  -L

# Teste Remote
curl -X POST http://localhost:9080/test \
  -d "message=TesteCURL&testType=remote" \
  -L

# Teste Ambos
curl -X POST http://localhost:9080/test \
  -d "message=TesteCURL&testType=both" \
  -L
```

---

## 🐛 Troubleshooting

### Problema: Página em branco

**Causa**: JSP não compilado

**Solução**:
```bash
# Limpar e reconstruir
mvn clean package
./deploy-all.sh
```

---

### Problema: EJB não injetado

**Causa**: Anotação @EJB não funcionando

**Solução**:
1. Verificar que o EJB JAR está no classpath
2. Confirmar configuração do server.xml
3. Verificar logs para erros de injeção

---

### Problema: Erro 404

**Causa**: Contexto ou URL incorreto

**Solução**:
- Verificar context-root no server.xml
- Confirmar URL: `http://localhost:9080/test`
- Verificar se aplicação está deployada

---

## 📊 Métricas e Monitoramento

### Logs Importantes

```bash
# Inicialização da aplicação
[INFO] CWWKZ0001I: Application simple-web started

# Chamadas EJB
[INFO] SimpleTestBean.hello() called with: Mundo

# Erros
[ERROR] Exception in EjbTestServlet: ...
```

### Monitorar Performance

```bash
# Ver tempo de resposta
tail -f logs/messages.log | grep "execution time"

# Contar requisições
grep "doPost" logs/messages.log | wc -l
```

---

## 🚀 Melhorias Futuras

### Funcionalidades Sugeridas

1. **Dashboard de Estatísticas**
   - Gráficos de performance
   - Histórico de testes
   - Comparações visuais

2. **Testes Automatizados**
   - Testes de carga
   - Testes de stress
   - Relatórios automáticos

3. **API REST**
   - Endpoint JSON
   - Documentação Swagger
   - Integração com outras aplicações

4. **Autenticação**
   - Login de usuários
   - Histórico por usuário
   - Controle de acesso

5. **Exportação de Resultados**
   - PDF
   - CSV
   - JSON

---

## 📚 Recursos Adicionais

- [JSP Tutorial](https://docs.oracle.com/javaee/7/tutorial/servlets.htm)
- [Servlet Specification](https://javaee.github.io/servlet-spec/)
- [JSTL Guide](https://docs.oracle.com/javaee/5/tutorial/doc/bnakc.html)
- [Liberty Web Features](https://openliberty.io/docs/latest/reference/feature/servlet-3.1.html)

---

**Desenvolvido para demonstração de integração EJB + Web**

**Versão**: 2.0.0  
**Data**: 2026-02-06