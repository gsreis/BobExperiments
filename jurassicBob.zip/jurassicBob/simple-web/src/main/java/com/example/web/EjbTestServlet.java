package com.example.web;

import com.example.ejb.SimpleTestLocal;
import com.example.ejb.SimpleTestRemote;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet para testar o EJB SimpleTest
 * Testa tanto a interface Local quanto a Remote
 */
@WebServlet(name = "EjbTestServlet", urlPatterns = {"/test"})
public class EjbTestServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Injeção do EJB usando interface Local
     * Usado para chamadas dentro da mesma JVM
     */
    @EJB
    private SimpleTestLocal simpleTestLocal;
    
    /**
     * Injeção do EJB usando interface Remote
     * Usado para demonstrar acesso remoto
     */
    @EJB
    private SimpleTestRemote simpleTestRemote;
    
    /**
     * Construtor padrão
     */
    public EjbTestServlet() {
        super();
    }
    
    /**
     * Processa requisições GET
     * Exibe o formulário de teste
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Forward para a página JSP
        request.getRequestDispatcher("/WEB-INF/views/test.jsp").forward(request, response);
    }
    
    /**
     * Processa requisições POST
     * Executa os testes do EJB e retorna os resultados
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obter parâmetro da requisição
        String message = request.getParameter("message");
        String testType = request.getParameter("testType");
        
        // Validar entrada
        if (message == null || message.trim().isEmpty()) {
            message = "Mundo";
        }
        
        String result = null;
        String interfaceUsed = null;
        long startTime = 0;
        long endTime = 0;
        
        try {
            // Testar baseado no tipo selecionado
            if ("local".equals(testType)) {
                // Teste usando interface Local
                interfaceUsed = "Local";
                startTime = System.nanoTime();
                result = simpleTestLocal.hello(message);
                endTime = System.nanoTime();
                
            } else if ("remote".equals(testType)) {
                // Teste usando interface Remote
                interfaceUsed = "Remote";
                startTime = System.nanoTime();
                result = simpleTestRemote.hello(message);
                endTime = System.nanoTime();
                
            } else if ("both".equals(testType)) {
                // Testar ambas as interfaces
                interfaceUsed = "Local e Remote";
                
                // Teste Local
                long localStart = System.nanoTime();
                String localResult = simpleTestLocal.hello(message);
                long localEnd = System.nanoTime();
                long localTime = localEnd - localStart;
                
                // Teste Remote
                long remoteStart = System.nanoTime();
                String remoteResult = simpleTestRemote.hello(message);
                long remoteEnd = System.nanoTime();
                long remoteTime = remoteEnd - remoteStart;
                
                // Preparar resultado combinado
                result = String.format(
                    "Local: %s (tempo: %.3f µs)\nRemote: %s (tempo: %.3f µs)",
                    localResult, localTime / 1000.0,
                    remoteResult, remoteTime / 1000.0
                );
                
                startTime = localStart;
                endTime = remoteEnd;
            }
            
            // Calcular tempo de execução
            long executionTime = endTime - startTime;
            double executionTimeMs = executionTime / 1_000_000.0;
            double executionTimeMicros = executionTime / 1000.0;
            
            // Adicionar atributos para a página JSP
            request.setAttribute("success", true);
            request.setAttribute("message", message);
            request.setAttribute("result", result);
            request.setAttribute("interfaceUsed", interfaceUsed);
            request.setAttribute("executionTimeMs", String.format("%.3f", executionTimeMs));
            request.setAttribute("executionTimeMicros", String.format("%.3f", executionTimeMicros));
            request.setAttribute("testType", testType);
            
        } catch (Exception e) {
            // Tratar erros
            request.setAttribute("success", false);
            request.setAttribute("error", e.getMessage());
            request.setAttribute("errorType", e.getClass().getSimpleName());
            e.printStackTrace();
        }
        
        // Forward para a página de resultado
        request.getRequestDispatcher("/WEB-INF/views/result.jsp").forward(request, response);
    }
    
    /**
     * Retorna informações sobre o servlet
     */
    @Override
    public String getServletInfo() {
        return "Servlet para testar EJB SimpleTest (Local e Remote)";
    }
}

// Made with Bob
