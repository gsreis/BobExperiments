# Guia Rápido - Simple EJB 3.2

## Início Rápido em 3 Passos

### 1️⃣ Construir a Aplicação

**Unix/Linux/Mac:**
```bash
./build.sh
```

**Windows:**
```cmd
build.bat
```

### 2️⃣ Fazer Deploy

**Unix/Linux/Mac:**
```bash
./deploy.sh
```

**Windows:**
```cmd
deploy.bat
```

### 3️⃣ Verificar

Acesse: http://localhost:9080

O servidor Liberty estará rodando com seu EJB deployado!

---

## Comandos Essenciais

### Build
```bash
mvn clean package
```

### Deploy com Maven
```bash
mvn liberty:create
mvn liberty:install-apps
mvn liberty:start
```

### Parar Servidor
```bash
mvn liberty:stop
```

### Ver Logs
```bash
# Unix/Linux/Mac
tail -f target/liberty/wlp/usr/servers/simpleEjbServer/logs/messages.log

# Windows
type target\liberty\wlp\usr\servers\simpleEjbServer\logs\messages.log
```

---

## Estrutura Básica do Projeto

```
jurassicBob/
├── pom.xml                          # Configuração Maven
├── build.sh / build.bat             # Scripts de build
├── deploy.sh / deploy.bat           # Scripts de deploy
└── src/main/java/com/example/ejb/
    ├── SimpleTestBean.java          # Implementação EJB
    ├── SimpleTestLocal.java         # Interface Local
    └── SimpleTestRemote.java        # Interface Remote
```

---

## Exemplo de Uso do EJB

### Código Java para Acessar o EJB

```java
import javax.naming.InitialContext;
import com.example.ejb.SimpleTestLocal;

public class ClientExample {
    public static void main(String[] args) throws Exception {
        // Lookup do EJB
        InitialContext ctx = new InitialContext();
        SimpleTestLocal bean = (SimpleTestLocal) ctx.lookup(
            "java:app/simple-ejb/SimpleTestBean!com.example.ejb.SimpleTestLocal"
        );
        
        // Usar o método
        String resultado = bean.hello(" Mundo!");
        System.out.println(resultado); // Output: Ola Mundo!
    }
}
```

---

## Troubleshooting Rápido

| Problema | Solução |
|----------|---------|
| Maven não encontrado | Instale Maven e adicione ao PATH |
| Java não encontrado | Configure JAVA_HOME |
| Porta 9080 em uso | Altere a porta em `server.xml` |
| Build falhou | Execute `mvn clean` e tente novamente |

---

## Próximos Passos

1. ✅ Build e Deploy concluídos
2. 📖 Leia o [README.md](README.md) completo para detalhes
3. 🔧 Customize o EJB para suas necessidades
4. 🧪 Adicione testes unitários
5. 🚀 Implemente novas funcionalidades

---

## Links Úteis

- **Documentação Completa**: [README.md](README.md)
- **Liberty Docs**: https://openliberty.io/docs/
- **Maven Central**: https://search.maven.org/
- **EJB 3.2 Spec**: https://jcp.org/en/jsr/detail?id=345

---

**Dica**: Para desenvolvimento rápido, use `mvn liberty:dev` para hot reload automático!