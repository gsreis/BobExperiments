#!/bin/bash

###############################################################################
# Deployment Script for Simple EJB Application
# Deploys to Liberty Profile Server
###############################################################################

set -e  # Exit on error

echo "=========================================="
echo "Simple EJB 3.2 Deployment Script"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if JAR file exists
JAR_FILE="target/simple-ejb.jar"
if [ ! -f "$JAR_FILE" ]; then
    print_error "JAR file not found: $JAR_FILE"
    print_info "Please run ./build.sh first"
    exit 1
fi

# Liberty server configuration
SERVER_NAME="simpleEjbServer"
LIBERTY_HOME="${LIBERTY_HOME:-}"

# Check if LIBERTY_HOME is set
if [ -z "$LIBERTY_HOME" ]; then
    print_warning "LIBERTY_HOME environment variable is not set"
    print_info "Using Maven Liberty plugin for deployment..."
    
    # Deploy using Maven Liberty plugin
    print_info "Creating Liberty server..."
    mvn liberty:create
    
    print_info "Installing application..."
    mvn liberty:install-apps
    
    print_info "Starting Liberty server..."
    mvn liberty:start
    
    print_success "Deployment completed using Maven Liberty plugin!"
    echo ""
    print_info "Server is running at: http://localhost:9080"
    print_info "To stop the server, run: mvn liberty:stop"
    
else
    # Deploy to existing Liberty installation
    print_info "LIBERTY_HOME: $LIBERTY_HOME"
    
    SERVER_DIR="$LIBERTY_HOME/usr/servers/$SERVER_NAME"
    APPS_DIR="$SERVER_DIR/apps"
    CONFIG_DIR="$SERVER_DIR"
    
    # Create server if it doesn't exist
    if [ ! -d "$SERVER_DIR" ]; then
        print_info "Creating Liberty server: $SERVER_NAME"
        "$LIBERTY_HOME/bin/server" create "$SERVER_NAME"
    fi
    
    # Create apps directory if it doesn't exist
    mkdir -p "$APPS_DIR"
    
    # Copy server configuration
    print_info "Copying server configuration..."
    cp src/main/liberty/config/server.xml "$CONFIG_DIR/"
    
    # Copy JAR file
    print_info "Copying EJB JAR to Liberty server..."
    cp "$JAR_FILE" "$APPS_DIR/"
    
    # Start or restart the server
    print_info "Starting Liberty server..."
    "$LIBERTY_HOME/bin/server" start "$SERVER_NAME"
    
    print_success "Deployment completed!"
    echo ""
    print_info "Server is running at: http://localhost:9080"
    print_info "To stop the server, run: $LIBERTY_HOME/bin/server stop $SERVER_NAME"
    print_info "To view logs: tail -f $SERVER_DIR/logs/messages.log"
fi

echo ""
print_success "Deployment process completed!"
echo ""

# Made with Bob
