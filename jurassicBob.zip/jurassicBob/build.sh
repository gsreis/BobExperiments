#!/bin/bash

###############################################################################
# Build Script for Simple EJB Application
# Compatible with Liberty Profile
###############################################################################

set -e  # Exit on error

echo "=========================================="
echo "Simple EJB 3.2 Build Script"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored messages
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    print_error "Maven is not installed. Please install Maven first."
    exit 1
fi

print_info "Maven version:"
mvn -version
echo ""

# Clean previous builds
print_info "Cleaning previous builds..."
mvn clean

# Compile and package the EJB
print_info "Building EJB application..."
mvn package

# Check if build was successful
if [ $? -eq 0 ]; then
    print_success "Build completed successfully!"
    echo ""
    print_info "Generated artifacts:"
    ls -lh target/*.jar 2>/dev/null || echo "No JAR files found"
    echo ""
else
    print_error "Build failed!"
    exit 1
fi

# Optional: Install to local Maven repository
read -p "Do you want to install to local Maven repository? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_info "Installing to local Maven repository..."
    mvn install
    print_success "Installation completed!"
fi

echo ""
print_success "Build process completed!"
echo ""
echo "Next steps:"
echo "  1. Deploy: ./deploy.sh"
echo "  2. Or manually copy target/simple-ejb.jar to Liberty server"
echo ""

# Made with Bob
