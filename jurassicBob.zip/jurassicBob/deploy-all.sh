#!/bin/bash

###############################################################################
# Deployment Script for Complete EJB + Web Application
# Deploys both modules to Liberty Profile Server
###############################################################################

set -e  # Exit on error

echo "=========================================="
echo "Complete Application Deployment Script"
echo "EJB 3.2 + Web Application"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if JAR and WAR files exist
EJB_JAR="simple-ejb/target/simple-ejb.jar"
WEB_WAR="simple-web/target/simple-web.war"

if [ ! -f "$EJB_JAR" ]; then
    print_error "EJB JAR not found: $EJB_JAR"
    print_info "Please run ./build-all.sh first"
    exit 1
fi

if [ ! -f "$WEB_WAR" ]; then
    print_error "Web WAR not found: $WEB_WAR"
    print_info "Please run ./build-all.sh first"
    exit 1
fi

print_success "✓ Found EJB JAR: $EJB_JAR"
print_success "✓ Found Web WAR: $WEB_WAR"
echo ""

# Deploy using Maven Liberty plugin (recommended)
print_info "Deploying using Maven Liberty plugin..."
echo ""

cd simple-web

print_info "Step 1: Creating Liberty server..."
mvn liberty:create

print_info "Step 2: Copying EJB JAR to shared apps directory..."
SHARED_DIR="target/liberty/wlp/usr/shared/apps"
mkdir -p "$SHARED_DIR"
cp "../$EJB_JAR" "$SHARED_DIR/"
print_success "✓ EJB JAR copied to $SHARED_DIR"

print_info "Step 3: Installing web application..."
mvn liberty:install-apps

print_info "Step 4: Starting Liberty server..."
mvn liberty:start

cd ..

print_success "Deployment completed!"
echo ""
print_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "🚀 Application is now running!"
print_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
print_info "📱 Access the application:"
echo "   🌐 Web Interface: ${GREEN}http://localhost:9080${NC}"
echo "   🧪 Test Page: ${GREEN}http://localhost:9080/test${NC}"
echo ""
print_info "📋 Useful commands:"
echo "   • Stop server: ${YELLOW}cd simple-web && mvn liberty:stop${NC}"
echo "   • View logs: ${YELLOW}tail -f simple-web/target/liberty/wlp/usr/servers/simpleWebServer/logs/messages.log${NC}"
echo "   • Dev mode: ${YELLOW}cd simple-web && mvn liberty:dev${NC}"
echo ""
print_info "💡 Tip: Use 'mvn liberty:dev' for hot reload during development!"
echo ""

# Made with Bob
