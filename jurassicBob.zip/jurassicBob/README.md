# Aplicação EJB 3.2 com Interface Web

## 🎯 Visão Geral

Este projeto implementa uma aplicação completa Java EE com:
- **EJB 3.2** (Enterprise JavaBeans) - Lógica de negócio
- **Aplicação Web** - Interface de usuário para testar o EJB
- **Liberty Profile** - Servidor de aplicação
- **Maven** - Gerenciamento de build multi-módulo

## 📁 Estrutura do Projeto

```
jurassicBob/
├── pom.xml                                    # POM pai (multi-módulo)
├── build-all.sh / build-all.bat              # Scripts de build completo
├── deploy-all.sh / deploy-all.bat            # Scripts de deploy completo
│
├── simple-ejb/                                # Módulo EJB
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/ejb/
│       │   ├── SimpleTestBean.java           # EJB Stateless
│       │   ├── SimpleTestLocal.java          # Interface Local
│       │   └── SimpleTestRemote.java         # Interface Remote
│       ├── resources/META-INF/
│       │   └── ejb-jar.xml                   # Descritor EJB
│       └── liberty/config/
│           └── server.xml                    # Config Liberty (EJB)
│
└── simple-web/                                # Módulo Web
    ├── pom.xml
    └── src/main/
        ├── java/com/example/web/
        │   └── EjbTestServlet.java           # Servlet de teste
        ├── webapp/
        │   ├── index.jsp                     # Página inicial
        │   └── WEB-INF/
        │       ├── web.xml                   # Descritor Web
        │       └── views/
        │           ├── test.jsp              # Formulário de teste
        │           ├── result.jsp            # Página de resultados
        │           └── error.jsp             # Página de erro
        └── liberty/config/
            └── server.xml                    # Config Liberty (Web+EJB)
```

## 🚀 Início Rápido

### Pré-requisitos
- **JDK 8+** ([Download](https://adoptium.net/))
- **Maven 3.6+** ([Download](https://maven.apache.org/download.cgi))

### Build e Deploy em 2 Passos

#### Unix/Linux/Mac:
```bash
# 1. Build
./build-all.sh

# 2. Deploy
./deploy-all.sh
```

#### Windows:
```cmd
REM 1. Build
build-all.bat

REM 2. Deploy
deploy-all.bat
```

### Acessar a Aplicação

Após o deploy, acesse:
- **Página Inicial**: http://localhost:9080
- **Teste EJB**: http://localhost:9080/test

## 📱 Funcionalidades da Aplicação Web

### 1. Página Inicial (`/`)
- Apresentação da aplicação
- Informações sobre tecnologias utilizadas
- Link para página de teste

### 2. Página de Teste (`/test`)
- Formulário para entrada de mensagem
- Seleção de tipo de interface (Local/Remote/Ambas)
- Interface moderna e responsiva

### 3. Página de Resultados (`/result`)
- Exibição do resultado do EJB
- Métricas de performance (tempo de execução)
- Comparação entre interfaces Local e Remote
- Informações técnicas detalhadas

## 🔧 Componentes Técnicos

### Módulo EJB (`simple-ejb`)

#### SimpleTestBean
```java
@Stateless
public class SimpleTestBean implements SimpleTestLocal, SimpleTestRemote {
    public String hello(String message) {
        return "Ola" + message;
    }
}
```

**Características:**
- Stateless Session Bean
- Implementa interfaces Local e Remote
- Thread-safe e escalável

### Módulo Web (`simple-web`)

#### EjbTestServlet
```java
@WebServlet(urlPatterns = {"/test"})
public class EjbTestServlet extends HttpServlet {
    @EJB
    private SimpleTestLocal simpleTestLocal;
    
    @EJB
    private SimpleTestRemote simpleTestRemote;
    
    // Métodos doGet() e doPost()
}
```

**Características:**
- Injeção automática de EJBs via `@EJB`
- Suporte para testes Local e Remote
- Medição de performance
- Tratamento de erros

## 🎨 Interface do Usuário

### Design
- **Responsivo**: Funciona em desktop, tablet e mobile
- **Moderno**: Gradientes, sombras e animações
- **Intuitivo**: Navegação clara e feedback visual
- **Acessível**: Cores contrastantes e labels descritivos

### Tecnologias Frontend
- HTML5
- CSS3 (Flexbox, Grid, Gradients)
- JSP 2.3
- JSTL 1.2

## 📊 Testes de Interface

### Interface Local
- **Uso**: Chamadas dentro da mesma JVM
- **Performance**: Mais rápida (sem serialização)
- **Cenário**: Aplicações monolíticas

### Interface Remote
- **Uso**: Chamadas remotas via RMI/IIOP
- **Performance**: Mais lenta (overhead de rede)
- **Cenário**: Aplicações distribuídas

### Comparação
A aplicação permite testar ambas simultaneamente e comparar:
- Tempo de execução
- Overhead de comunicação
- Diferenças de performance

## 🛠️ Comandos Maven

### Build
```bash
# Build completo (raiz do projeto)
mvn clean package

# Build apenas EJB
cd simple-ejb && mvn clean package

# Build apenas Web
cd simple-web && mvn clean package
```

### Deploy e Execução
```bash
# Modo desenvolvimento (hot reload)
cd simple-web && mvn liberty:dev

# Criar servidor
cd simple-web && mvn liberty:create

# Instalar aplicações
cd simple-web && mvn liberty:install-apps

# Iniciar servidor
cd simple-web && mvn liberty:start

# Parar servidor
cd simple-web && mvn liberty:stop

# Ver status
cd simple-web && mvn liberty:status
```

### Testes
```bash
# Executar testes
mvn test

# Executar testes com cobertura
mvn test jacoco:report
```

## 📝 Configuração do Liberty

### Features Habilitadas
- `ejbLite-3.2` - EJB 3.2
- `servlet-3.1` - Servlets
- `jsp-2.3` - JavaServer Pages
- `jndi-1.0` - JNDI
- `cdi-1.2` - CDI (Contexts and Dependency Injection)
- `localConnector-1.0` - Conector local

### Portas
- **HTTP**: 9080
- **HTTPS**: 9443

## 🔍 Logs e Troubleshooting

### Localização dos Logs
```bash
# Messages log
simple-web/target/liberty/wlp/usr/servers/simpleWebServer/logs/messages.log

# Console log
simple-web/target/liberty/wlp/usr/servers/simpleWebServer/logs/console.log
```

### Ver Logs em Tempo Real
```bash
# Unix/Linux/Mac
tail -f simple-web/target/liberty/wlp/usr/servers/simpleWebServer/logs/messages.log

# Windows
powershell Get-Content simple-web\target\liberty\wlp\usr\servers\simpleWebServer\logs\messages.log -Wait
```

### Problemas Comuns

#### EJB não encontrado
**Sintoma**: `javax.naming.NameNotFoundException`

**Solução**:
1. Verifique se o EJB JAR está em `shared/apps`
2. Confirme a configuração no `server.xml`
3. Reinicie o servidor

#### Porta em uso
**Sintoma**: `Address already in use`

**Solução**:
```bash
# Encontrar processo usando a porta 9080
lsof -i :9080  # Unix/Linux/Mac
netstat -ano | findstr :9080  # Windows

# Matar o processo ou alterar a porta no server.xml
```

#### ClassNotFoundException
**Sintoma**: Classes do EJB não encontradas

**Solução**:
1. Verifique o classloader no `server.xml`
2. Confirme que o EJB está no classpath
3. Limpe e reconstrua: `mvn clean package`

## 🧪 Testando a Aplicação

### Teste Manual

1. **Acesse a página inicial**
   ```
   http://localhost:9080
   ```

2. **Clique em "Iniciar Teste"**

3. **Preencha o formulário**
   - Mensagem: "Mundo"
   - Interface: "Ambas as Interfaces"

4. **Clique em "Executar Teste"**

5. **Verifique os resultados**
   - Resultado Local: "OlaMundo"
   - Resultado Remote: "OlaMundo"
   - Tempo de execução de cada interface

### Teste via cURL

```bash
# Teste POST
curl -X POST http://localhost:9080/test \
  -d "message=Teste&testType=local"
```

## 📚 Documentação Adicional

- [QUICKSTART.md](QUICKSTART.md) - Guia rápido
- [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) - Resumo do projeto
- [WEB_APP_GUIDE.md](WEB_APP_GUIDE.md) - Guia da aplicação web

## 🔐 Segurança

### Configuração Básica
O `server.xml` inclui um registro básico:
```xml
<basicRegistry id="basic" realm="BasicRealm">
    <user name="admin" password="admin" />
</basicRegistry>
```

**⚠️ IMPORTANTE**: Altere as credenciais em produção!

## 🚀 Próximos Passos

1. **Adicionar Persistência**
   - Integrar JPA/Hibernate
   - Configurar DataSource
   - Criar entidades

2. **Implementar REST API**
   - Adicionar JAX-RS
   - Expor EJB via REST
   - Documentar com Swagger

3. **Adicionar Segurança**
   - Implementar autenticação
   - Adicionar autorização
   - Configurar SSL/TLS

4. **Testes Automatizados**
   - Testes unitários (JUnit)
   - Testes de integração (Arquillian)
   - Testes de UI (Selenium)

5. **CI/CD**
   - Configurar GitHub Actions
   - Adicionar Docker
   - Automatizar deploys

## 📄 Licença

Projeto fornecido como exemplo educacional.

## 👥 Contribuindo

Contribuições são bem-vindas! Por favor:
1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📞 Suporte

- **Documentação Liberty**: https://openliberty.io/docs/
- **Maven Central**: https://search.maven.org/
- **Stack Overflow**: Tags `websphere-liberty`, `ejb-3.x`

---

**Desenvolvido com ❤️ para demonstração de EJB 3.2 + Web Application**

**Última atualização**: 2026-02-06  
**Versão**: 2.0.0