#!/bin/bash

###############################################################################
# Build Script for Complete EJB + Web Application
# Builds both EJB and Web modules
###############################################################################

set -e  # Exit on error

echo "=========================================="
echo "Complete Application Build Script"
echo "EJB 3.2 + Web Application"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    print_error "Maven is not installed. Please install Maven first."
    exit 1
fi

print_info "Maven version:"
mvn -version
echo ""

# Clean previous builds
print_info "Cleaning previous builds..."
mvn clean

# Build parent project (includes all modules)
print_info "Building complete application (EJB + Web)..."
echo ""
print_info "This will build:"
echo "  1. simple-ejb module (EJB JAR)"
echo "  2. simple-web module (WAR)"
echo ""

mvn package

# Check if build was successful
if [ $? -eq 0 ]; then
    print_success "Build completed successfully!"
    echo ""
    print_info "Generated artifacts:"
    echo ""
    
    if [ -f "simple-ejb/target/simple-ejb.jar" ]; then
        print_success "✓ EJB Module: simple-ejb/target/simple-ejb.jar"
        ls -lh simple-ejb/target/simple-ejb.jar
    fi
    
    if [ -f "simple-web/target/simple-web.war" ]; then
        print_success "✓ Web Module: simple-web/target/simple-web.war"
        ls -lh simple-web/target/simple-web.war
    fi
    
    echo ""
else
    print_error "Build failed!"
    exit 1
fi

# Optional: Install to local Maven repository
read -p "Do you want to install to local Maven repository? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_info "Installing to local Maven repository..."
    mvn install
    print_success "Installation completed!"
fi

echo ""
print_success "Build process completed!"
echo ""
echo "Next steps:"
echo "  1. Deploy: ./deploy-all.sh"
echo "  2. Or use Maven: mvn liberty:run (in simple-web directory)"
echo ""
echo "Application will be available at: http://localhost:9080"
echo ""

# Made with Bob
