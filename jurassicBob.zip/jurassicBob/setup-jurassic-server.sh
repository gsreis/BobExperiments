#!/bin/bash

###############################################################################
# Jurassic Server Setup Script
# Creates Liberty server, builds and deploys EJB + WAR, and starts the server
###############################################################################

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
LIBERTY_HOME="/Users/glaucoreis/liberty/wlp"
SERVER_NAME="jurassic"
SERVER_DIR="${LIBERTY_HOME}/usr/servers/${SERVER_NAME}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Function to print colored messages
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_step() {
    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}$1${NC}"
    echo -e "${GREEN}========================================${NC}"
}

# Check if Liberty is installed
if [ ! -d "$LIBERTY_HOME" ]; then
    print_error "Liberty installation not found at: $LIBERTY_HOME"
    exit 1
fi

print_info "Liberty Home: $LIBERTY_HOME"
print_info "Server Name: $SERVER_NAME"
print_info "Project Directory: $PROJECT_DIR"
echo ""

# Step 1: Build the application
print_step "Step 1: Building Application"
print_info "Cleaning and building EJB + WAR modules..."

if ! command -v mvn &> /dev/null; then
    print_error "Maven is not installed. Please install Maven first."
    exit 1
fi

mvn clean package

if [ $? -ne 0 ]; then
    print_error "Build failed!"
    exit 1
fi

print_success "Build completed successfully!"
print_info "Generated artifacts:"
echo "  - EJB: ${PROJECT_DIR}/simple-ejb/target/simple-ejb.jar"
echo "  - WAR: ${PROJECT_DIR}/simple-web/target/simple-web.war"

# Step 2: Create or recreate Liberty server
print_step "Step 2: Setting up Liberty Server"

# Stop server if it's running
if [ -d "$SERVER_DIR" ]; then
    print_warning "Server '$SERVER_NAME' already exists. Stopping if running..."
    "${LIBERTY_HOME}/bin/server" stop "$SERVER_NAME" 2>/dev/null || true
    
    # Ask user if they want to recreate
    read -p "Do you want to recreate the server? (y/n) " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_info "Removing existing server..."
        rm -rf "$SERVER_DIR"
        print_info "Creating new server '$SERVER_NAME'..."
        "${LIBERTY_HOME}/bin/server" create "$SERVER_NAME"
    else
        print_info "Using existing server..."
    fi
else
    print_info "Creating new server '$SERVER_NAME'..."
    "${LIBERTY_HOME}/bin/server" create "$SERVER_NAME"
fi

print_success "Server setup completed!"

# Step 3: Configure server
print_step "Step 3: Configuring Server"

print_info "Copying server configuration..."
cp "${PROJECT_DIR}/server-config/jurassic-server.xml" "${SERVER_DIR}/server.xml"
print_success "Server configuration copied!"

# Create apps directory if it doesn't exist
mkdir -p "${SERVER_DIR}/apps"

# Step 4: Deploy applications
print_step "Step 4: Deploying Applications"

print_info "Deploying EJB module..."
cp "${PROJECT_DIR}/simple-ejb/target/simple-ejb.jar" "${SERVER_DIR}/apps/"
print_success "EJB deployed: simple-ejb.jar"

print_info "Deploying WAR module..."
cp "${PROJECT_DIR}/simple-web/target/simple-web.war" "${SERVER_DIR}/apps/"
print_success "WAR deployed: simple-web.war"

# Step 5: Start the server
print_step "Step 5: Starting Server"

print_info "Starting Liberty server '$SERVER_NAME'..."
"${LIBERTY_HOME}/bin/server" start "$SERVER_NAME"

if [ $? -eq 0 ]; then
    print_success "Server started successfully!"
    echo ""
    print_info "Server Details:"
    echo "  - Server Name: $SERVER_NAME"
    echo "  - Server Directory: $SERVER_DIR"
    echo "  - HTTP Port: 9080"
    echo "  - HTTPS Port: 9443"
    echo ""
    print_info "Application URLs:"
    echo "  - Web Application: http://localhost:9080/simple-web"
    echo "  - Test Servlet: http://localhost:9080/simple-web/test"
    echo ""
    print_info "Useful Commands:"
    echo "  - View logs: tail -f ${SERVER_DIR}/logs/messages.log"
    echo "  - Stop server: ${LIBERTY_HOME}/bin/server stop ${SERVER_NAME}"
    echo "  - Server status: ${LIBERTY_HOME}/bin/server status ${SERVER_NAME}"
    echo ""
    
    # Wait a moment for server to fully start
    print_info "Waiting for server to fully initialize..."
    sleep 5
    
    # Show server status
    print_info "Server Status:"
    "${LIBERTY_HOME}/bin/server" status "$SERVER_NAME"
    
    echo ""
    print_success "Setup Complete! Server is running."
    echo ""
    print_warning "To view real-time logs, run:"
    echo "  tail -f ${SERVER_DIR}/logs/messages.log"
else
    print_error "Failed to start server!"
    print_info "Check logs at: ${SERVER_DIR}/logs/messages.log"
    exit 1
fi

# Made with Bob