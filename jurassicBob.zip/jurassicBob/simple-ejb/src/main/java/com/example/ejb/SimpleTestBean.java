package com.example.ejb;

import javax.ejb.Stateless;

/**
 * Stateless Session Bean implementation for SimpleTest
 * EJB 3.2 compatible with Liberty Profile
 * 
 * This bean provides a simple greeting service that can be accessed
 * both locally and remotely.
 */
@Stateless
public class SimpleTestBean implements SimpleTestLocal, SimpleTestRemote {
    
    /**
     * Default constructor
     */
    public SimpleTestBean() {
        // Default constructor required for EJB
    }
    
    /**
     * Returns a greeting message by concatenating "Ola" with the provided message
     * 
     * @param message the message to append to the greeting
     * @return greeting string in the format "Ola{message}"
     */
    @Override
    public String hello(String message) {
        return "Ola" + message;
    }
}

// Made with Bob
