package com.example.ejb;

import javax.ejb.Local;

/**
 * Local interface for SimpleTest EJB
 * Defines the business methods available for local clients
 */
@Local
public interface SimpleTestLocal {
    
    /**
     * Returns a greeting message
     * @param message the message to append to the greeting
     * @return greeting string with the provided message
     */
    String hello(String message);
}

// Made with Bob
