package com.example.ejb;

import javax.ejb.Remote;

/**
 * Remote interface for SimpleTest EJB
 * Defines the business methods available for remote clients
 */
@Remote
public interface SimpleTestRemote {
    
    /**
     * Returns a greeting message
     * @param message the message to append to the greeting
     * @return greeting string with the provided message
     */
    String hello(String message);
}

// Made with Bob
