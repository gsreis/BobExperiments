public class SimpleTest {
     public String hello(String message) {
        return  "Ola" + message;
     }
}
