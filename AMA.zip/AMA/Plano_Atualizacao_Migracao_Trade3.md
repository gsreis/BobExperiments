# Plano Detalhado de Atualização e Migração - Trade3 Application

## Sumário Executivo

**Aplicação:** trade3wls.ear  
**Origem:** WebSphere Application Server 8.5.5 + IBM Java 6 + Java EE 6  
**Destino:** WebSphere Liberty + IBM Java 8  
**Data da Análise:** IBM Application Modernization Accelerator (AMA) v21.0.0.3

### Resumo de Impacto

| Categoria | Total de Regras | Total de Ocorrências | Arquivos Afetados |
|-----------|----------------|---------------------|-------------------|
| **Severe** | 3 | 11 | 125 |
| **Warning** | 3 | 123 | 125 |
| **Information** | 1 | 1 | 125 |
| **TOTAL** | **7** | **135** | **125** |

---

## 1. Problemas Críticos (Severity: Severe)

### 1.1 Entity EJBs Não Suportados no Liberty

**Regra:** `DetectEJBEntityBeansXML`  
**Impacto:** Alto - 6 Entity Beans identificados  
**Esforço de Desenvolvimento:** 10 dias por instância = **60 dias**  
**Arquivo Afetado:** `trade3EJB.jar/META-INF/ejb-jar.xml`

#### Entity Beans Identificados:
1. **AccountEJB** (linha 111)
2. **HoldingEJB** (linha 216)
3. **OrderEJB** (linha 272)
4. **QuoteEJB** (linha 405)
5. **AccountProfileEJB** (linha 438)
6. **Outro Entity Bean** (linha 531)

#### Estratégia de Migração:

**Opção 1: Migração para JPA 2.x (Recomendado)**
```
Entity EJB 2.x → JPA 2.x Entities
```

**Passos:**
1. **Análise de Mapeamento:**
   - Revisar cada Entity Bean e seus relacionamentos
   - Documentar campos CMP (Container-Managed Persistence)
   - Identificar relacionamentos CMR (Container-Managed Relationships)

2. **Conversão para JPA:**
   - Criar classes JPA Entity com anotações `@Entity`
   - Mapear campos com `@Column`, `@Id`, `@GeneratedValue`
   - Converter relacionamentos para `@OneToMany`, `@ManyToOne`, `@ManyToMany`
   - Criar `persistence.xml` com configuração do DataSource

3. **Refatoração de Lógica de Negócio:**
   - Migrar métodos ejbCreate → construtores JPA
   - Migrar métodos ejbFind → JPQL queries
   - Implementar EntityManager para operações CRUD

4. **Exemplo de Conversão:**

**Antes (Entity EJB):**
```java
public abstract class AccountEJB implements EntityBean {
    public abstract Integer getAccountID();
    public abstract void setAccountID(Integer id);
    public abstract String getUserID();
    public abstract void setUserID(String userId);
    // ... outros campos CMP
}
```

**Depois (JPA Entity):**
```java
@Entity
@Table(name = "ACCOUNT")
public class Account implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACCOUNTID")
    private Integer accountID;
    
    @Column(name = "USERID", nullable = false)
    private String userID;
    
    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL)
    private Collection<Holding> holdings;
    
    // Getters, setters, construtores
}
```

**Opção 2: Migração para Session Beans + JDBC**
- Menos recomendado, mas viável se JPA não for possível
- Requer mais código manual para persistência

---

### 1.2 JAX-RPC Não Suportado

**Regra:** `DetectJAXRPC`  
**Impacto:** Alto - Web Services legados  
**Esforço de Desenvolvimento:** 5 dias  
**Arquivo Afetado:** `TradeWebSoapProxy.class`

#### Problema:
```java
// Código atual usa JAX-RPC (javax.xml.rpc)
javax.xml.rpc.ServiceException
```

#### Estratégia de Migração:

**Migração para JAX-WS 2.x:**

1. **Análise do WSDL:**
   - Localizar arquivos WSDL existentes
   - Documentar operações e tipos de dados

2. **Regeneração de Stubs:**
   - Usar `wsimport` (JAX-WS) ao invés de `wsdl2java` (JAX-RPC)
   - Comando: `wsimport -keep -s src -d bin -p com.ibm.websphere.samples.trade.soap.jaxws <WSDL_URL>`

3. **Refatoração do Proxy:**

**Antes (JAX-RPC):**
```java
import javax.xml.rpc.*;
import javax.xml.namespace.QName;

Service service = ServiceFactory.newInstance().createService(
    new URL(wsdlUrl), 
    new QName(namespace, serviceName)
);
TradePort port = (TradePort) service.getPort(TradePort.class);
```

**Depois (JAX-WS):**
```java
import javax.xml.ws.*;

@WebServiceClient(name = "TradeService", 
                  targetNamespace = "http://trade.samples.websphere.ibm.com/")
public class TradeService extends Service {
    public TradeService(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }
    
    @WebEndpoint(name = "TradePort")
    public TradePort getTradePort() {
        return super.getPort(new QName(namespace, "TradePort"), TradePort.class);
    }
}
```

4. **Atualização de Dependências:**
   - Remover bibliotecas JAX-RPC
   - Adicionar features Liberty: `jaxws-2.2` ou `jaxws-2.3`

---

### 1.3 Propagação de Transação em EJB Remote

**Regra:** `DetectTransactionPropagationEJBRemote`  
**Impacto:** Médio-Alto - 4 interfaces remotas  
**Esforço de Desenvolvimento:** 1 dia por instância = **4 dias**  
**Arquivo Afetado:** `ejb-jar.xml` (linhas 12, 35, 212, 277)

#### Problema:
Liberty não suporta propagação de transação para interfaces EJB remotas.

#### Estratégia de Migração:

**Opção 1: Converter para Local Interfaces (Recomendado)**
```xml
<!-- Antes -->
<remote>com.ibm.websphere.samples.trade.ejb.Trade</remote>

<!-- Depois -->
<local>com.ibm.websphere.samples.trade.ejb.TradeLocal</local>
```

**Passos:**
1. Identificar todos os clientes que usam interfaces remotas
2. Se clientes estão na mesma JVM, converter para local
3. Atualizar lookups JNDI
4. Remover serialização desnecessária

**Opção 2: Usar REST/SOAP para Comunicação Remota**
- Se realmente precisa de acesso remoto
- Implementar camada REST com JAX-RS
- Gerenciar transações explicitamente

**Opção 3: Gerenciamento Manual de Transações**
```java
@TransactionManagement(TransactionManagementType.BEAN)
public class TradeBean implements Trade {
    @Resource
    private UserTransaction userTransaction;
    
    public void executeOperation() throws Exception {
        userTransaction.begin();
        try {
            // lógica de negócio
            userTransaction.commit();
        } catch (Exception e) {
            userTransaction.rollback();
            throw e;
        }
    }
}
```

---

## 2. Problemas de Aviso (Severity: Warning)

### 2.1 Classes Geradas por WSDL2Java

**Regra:** `WebSphereWebServicesGeneratedClassesRule`  
**Impacto:** Médio - 21 classes geradas  
**Esforço de Desenvolvimento:** 0 dias (regeneração automática)

#### Classes Afetadas:
- AccountDataBean_Deser/Ser/Helper
- AccountProfileDataBean_Deser/Ser/Helper
- HoldingDataBean_Deser/Ser/Helper
- MarketSummaryDataBeanWS_Deser/Ser/Helper
- OrderDataBean_Deser/Ser/Helper
- QuoteDataBean_Deser/Ser/Helper
- RunStatsDataBean_Deser/Ser/Helper

#### Estratégia:

1. **Regenerar com JAX-WS:**
   ```bash
   wsimport -keep -s src/main/java -d target/classes \
            -p com.ibm.websphere.samples.trade.ws \
            -Xnocompile \
            http://localhost:9080/trade3/services/TradeService?wsdl
   ```

2. **Atualizar Imports:**
   - Remover: `com.ibm.ws.webservices.engine.*`
   - Adicionar: `javax.xml.ws.*`, `javax.jws.*`

3. **Validar Serialização:**
   - Testar marshalling/unmarshalling de objetos
   - Verificar compatibilidade de tipos

---

### 2.2 Problemas de Compilação (101 ocorrências)

**Regra:** `DetectBadClasses`  
**Impacto:** Alto - Código não compila  
**Esforço de Desenvolvimento:** 15-20 dias

#### Categorias de Problemas:

**A. Dependências WebLogic (Maioria dos erros)**
```
weblogic.ejb20 cannot be resolved
weblogic.transaction cannot be resolved
weblogic.logging cannot be resolved
```

**Causa:** Aplicação foi portada de WebLogic para WebSphere, mas manteve classes WebLogic.

**Solução:**
1. **Remover todas as referências WebLogic:**
   - Classes em `trade3EJB.jar` com sufixo `_vkbo0d_*`
   - Estas são classes geradas pelo WebLogic
   
2. **Regenerar Stubs EJB:**
   - Usar ferramentas Liberty para gerar stubs
   - Ou remover completamente se migrar para JPA

3. **Arquivos a Remover/Regenerar:**
   ```
   AccountEJB_vkbo0d_ELOImpl.class
   AccountEJB_vkbo0d_Intf.class
   AccountEJB_vkbo0d_LocalHomeImpl.class
   AccountEJB_vkbo0d__WebLogic_CMP_RDBMS.class
   (e todos os similares para outras entidades)
   ```

**B. Dependências de Utilitários Trade**
```
com.ibm.websphere.samples.trade.util cannot be resolved
Log cannot be resolved
FinancialUtils cannot be resolved
```

**Solução:**
1. Verificar se classes utilitárias estão no classpath
2. Adicionar JAR de utilitários ao EAR
3. Atualizar `application.xml` se necessário

**C. JSP Compilados com Problemas**
- Todos os arquivos `jsp_servlet/__*.class`
- Contêm referências WebLogic

**Solução:**
1. **Deletar JSPs pré-compilados**
2. **Deixar Liberty compilar JSPs em runtime**
3. **Ou recompilar JSPs:**
   ```bash
   # Usar JspC do Liberty
   <liberty_install>/bin/jspBatchCompiler.sh \
       -webxml.encoding UTF-8 \
       -compileToWebInf \
       -source <webapp_dir>
   ```

---

### 2.3 Dynamic Cache Service

**Regra:** `DynamicCacheRule`  
**Impacto:** Baixo - 1 ocorrência  
**Esforço de Desenvolvimento:** 1 dia  
**Arquivo Afetado:** `ClosedOrdersCommand.class`

#### Código Atual:
```java
import com.ibm.websphere.cache.*;

DynamicCacheAccessor cacheAccessor = ...;
Cache cache = cacheAccessor.getCache();
cache.invalidate(...);
```

#### Estratégia de Migração:

**Opção 1: Usar Liberty Dynamic Cache (Compatível)**
```xml
<!-- server.xml -->
<server>
    <featureManager>
        <feature>distributedMap-1.0</feature>
    </featureManager>
    
    <cache id="tradeCache" 
           cacheSize="2000" 
           enableServletCaching="true"/>
</server>
```

**Opção 2: Migrar para JCache (JSR-107)**
```java
import javax.cache.*;
import javax.cache.configuration.*;

CachingProvider provider = Caching.getCachingProvider();
CacheManager cacheManager = provider.getCacheManager();

MutableConfiguration<String, Object> config = 
    new MutableConfiguration<String, Object>()
        .setTypes(String.class, Object.class)
        .setExpiryPolicyFactory(CreatedExpiryPolicy.factoryOf(Duration.ONE_HOUR));

Cache<String, Object> cache = cacheManager.createCache("tradeCache", config);
cache.remove(key); // equivalente a invalidate
```

**Opção 3: Usar Cache Simples (Map)**
```java
import java.util.concurrent.ConcurrentHashMap;

private static final Map<String, Object> cache = new ConcurrentHashMap<>();

public void invalidateCache(String key) {
    cache.remove(key);
}
```

---

## 3. Problemas Informativos (Severity: Information)

### 3.1 Mudança de Comportamento em NumberFormat

**Regra:** `NumberFormatRounding`  
**Impacto:** Muito Baixo  
**Esforço de Desenvolvimento:** 0 dias (apenas teste)  
**Arquivo Afetado:** `ChangeRenderer.class`

#### Problema:
Java 8 mudou o comportamento de arredondamento em `NumberFormat.format(double)`.

#### Ação:
1. **Testar formatação de números:**
   ```java
   NumberFormat nf = NumberFormat.getInstance();
   double value = 123.456789;
   String formatted = nf.format(value);
   // Verificar se resultado é o esperado
   ```

2. **Se necessário, especificar modo de arredondamento:**
   ```java
   NumberFormat nf = NumberFormat.getInstance();
   if (nf instanceof DecimalFormat) {
       ((DecimalFormat) nf).setRoundingMode(RoundingMode.HALF_UP);
   }
   ```

---

## 4. Plano de Execução Detalhado

### Fase 1: Preparação (1 semana)

**Semana 1:**
- [ ] Configurar ambiente de desenvolvimento Liberty
- [ ] Instalar IBM Java 8
- [ ] Configurar ferramentas de build (Maven/Gradle)
- [ ] Criar repositório Git para controle de versão
- [ ] Documentar arquitetura atual
- [ ] Backup completo da aplicação

**Entregáveis:**
- Ambiente de desenvolvimento configurado
- Documentação de arquitetura
- Plano de testes

---

### Fase 2: Limpeza e Preparação do Código (2 semanas)

**Semana 2-3:**
- [ ] Remover todas as classes geradas pelo WebLogic (`*_vkbo0d_*`)
- [ ] Deletar JSPs pré-compilados
- [ ] Limpar dependências WebLogic do classpath
- [ ] Atualizar estrutura de diretórios se necessário
- [ ] Criar branch Git para migração

**Entregáveis:**
- Código limpo sem dependências WebLogic
- Estrutura de projeto atualizada

---

### Fase 3: Migração de Entity Beans para JPA (6 semanas)

**Semana 4-5: AccountEJB e AccountProfileEJB**
- [ ] Analisar mapeamento de campos
- [ ] Criar entidades JPA
- [ ] Criar `persistence.xml`
- [ ] Implementar DAOs/Repositories
- [ ] Testes unitários

**Semana 6-7: HoldingEJB e OrderEJB**
- [ ] Criar entidades JPA
- [ ] Mapear relacionamentos
- [ ] Implementar DAOs
- [ ] Testes unitários

**Semana 8-9: QuoteEJB e Entity Bean restante**
- [ ] Criar entidades JPA
- [ ] Implementar DAOs
- [ ] Testes de integração
- [ ] Validar relacionamentos

**Entregáveis:**
- 6 entidades JPA completas
- DAOs implementados
- Suite de testes unitários
- Documentação de mapeamento

---

### Fase 4: Migração de Web Services (1 semana)

**Semana 10:**
- [ ] Localizar WSDLs existentes
- [ ] Regenerar stubs com JAX-WS (wsimport)
- [ ] Refatorar TradeWebSoapProxy
- [ ] Atualizar clientes SOAP
- [ ] Testes de integração de Web Services

**Entregáveis:**
- Stubs JAX-WS gerados
- Proxy refatorado
- Testes de Web Services

---

### Fase 5: Refatoração de EJBs (2 semanas)

**Semana 11:**
- [ ] Converter interfaces remotas para locais
- [ ] Atualizar lookups JNDI
- [ ] Refatorar gerenciamento de transações
- [ ] Atualizar `ejb-jar.xml`

**Semana 12:**
- [ ] Implementar Session Beans para lógica de negócio
- [ ] Integrar com camada JPA
- [ ] Testes de integração

**Entregáveis:**
- EJBs refatorados
- Configuração atualizada
- Testes de integração

---

### Fase 6: Atualização de Cache e Utilitários (1 semana)

**Semana 13:**
- [ ] Migrar Dynamic Cache para JCache ou Liberty Cache
- [ ] Atualizar ClosedOrdersCommand
- [ ] Verificar utilitários (Log, FinancialUtils)
- [ ] Testes de cache

**Entregáveis:**
- Cache migrado
- Utilitários validados

---

### Fase 7: Configuração Liberty (1 semana)

**Semana 14:**
- [ ] Criar `server.xml` do Liberty
- [ ] Configurar features necessárias
- [ ] Configurar DataSources
- [ ] Configurar segurança
- [ ] Configurar logging

**Exemplo `server.xml`:**
```xml
<server description="Trade3 Liberty Server">
    <featureManager>
        <feature>javaee-8.0</feature>
        <feature>jpa-2.2</feature>
        <feature>ejb-3.2</feature>
        <feature>servlet-4.0</feature>
        <feature>jsp-2.3</feature>
        <feature>jaxws-2.2</feature>
        <feature>jdbc-4.2</feature>
        <feature>jndi-1.0</feature>
        <feature>distributedMap-1.0</feature>
    </featureManager>

    <httpEndpoint id="defaultHttpEndpoint"
                  httpPort="9080"
                  httpsPort="9443" />

    <dataSource id="TradeDataSource" jndiName="jdbc/TradeDataSource">
        <jdbcDriver libraryRef="DB2Lib"/>
        <properties.db2.jcc 
            databaseName="TRADEDB"
            serverName="localhost"
            portNumber="50000"
            user="db2admin"
            password="{xor}Lz4sLCgwLTs="/>
    </dataSource>

    <library id="DB2Lib">
        <fileset dir="${server.config.dir}/lib" includes="db2jcc4.jar"/>
    </library>

    <application location="trade3.ear" name="trade3">
        <classloader delegation="parentLast"/>
    </application>

    <logging traceSpecification="*=info:com.ibm.websphere.samples.trade.*=all"/>
</server>
```

**Entregáveis:**
- Configuração Liberty completa
- DataSources configurados
- Documentação de configuração

---

### Fase 8: Testes e Validação (2 semanas)

**Semana 15:**
- [ ] Testes funcionais completos
- [ ] Testes de performance
- [ ] Testes de carga
- [ ] Validação de dados

**Semana 16:**
- [ ] Correção de bugs
- [ ] Otimizações
- [ ] Testes de regressão
- [ ] Documentação de testes

**Entregáveis:**
- Relatório de testes
- Bugs corrigidos
- Métricas de performance

---

### Fase 9: Deploy e Estabilização (1 semana)

**Semana 17:**
- [ ] Deploy em ambiente de homologação
- [ ] Testes de aceitação do usuário
- [ ] Ajustes finais
- [ ] Preparação para produção

**Entregáveis:**
- Aplicação em homologação
- Documentação de deploy
- Plano de rollback

---

## 5. Configuração de Dependências

### Maven `pom.xml` (Exemplo)

```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.ibm.websphere.samples</groupId>
    <artifactId>trade3</artifactId>
    <version>3.0.0-liberty</version>
    <packaging>ear</packaging>

    <properties>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <liberty.version>21.0.0.3</liberty.version>
    </properties>

    <dependencies>
        <!-- Java EE 8 APIs -->
        <dependency>
            <groupId>javax</groupId>
            <artifactId>javaee-api</artifactId>
            <version>8.0</version>
            <scope>provided</scope>
        </dependency>

        <!-- JPA 2.2 -->
        <dependency>
            <groupId>javax.persistence</groupId>
            <artifactId>javax.persistence-api</artifactId>
            <version>2.2</version>
            <scope>provided</scope>
        </dependency>

        <!-- JAX-WS -->
        <dependency>
            <groupId>javax.xml.ws</groupId>
            <artifactId>jaxws-api</artifactId>
            <version>2.3.1</version>
            <scope>provided</scope>
        </dependency>

        <!-- EJB 3.2 -->
        <dependency>
            <groupId>javax.ejb</groupId>
            <artifactId>javax.ejb-api</artifactId>
            <version>3.2</version>
            <scope>provided</scope>
        </dependency>

        <!-- Servlet 4.0 -->
        <dependency>
            <groupId>javax.servlet</groupId>
            <artifactId>javax.servlet-api</artifactId>
            <version>4.0.1</version>
            <scope>provided</scope>
        </dependency>

        <!-- JDBC Driver (exemplo DB2) -->
        <dependency>
            <groupId>com.ibm.db2</groupId>
            <artifactId>jcc</artifactId>
            <version>11.5.0.0</version>
            <scope>runtime</scope>
        </dependency>

        <!-- Logging -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
            <version>1.7.30</version>
        </dependency>

        <!-- Testing -->
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.13.2</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>io.openliberty.tools</groupId>
                <artifactId>liberty-maven-plugin</artifactId>
                <version>3.3.4</version>
            </plugin>
        </plugins>
    </build>
</project>
```

---

## 6. Checklist de Migração

### Pré-Migração
- [ ] Backup completo da aplicação
- [ ] Documentação da arquitetura atual
- [ ] Inventário de dependências
- [ ] Plano de testes definido
- [ ] Ambiente Liberty configurado

### Durante Migração
- [ ] Remover dependências WebLogic
- [ ] Migrar Entity Beans para JPA
- [ ] Migrar JAX-RPC para JAX-WS
- [ ] Converter EJB Remote para Local
- [ ] Atualizar cache
- [ ] Configurar Liberty
- [ ] Executar testes

### Pós-Migração
- [ ] Validação funcional completa
- [ ] Testes de performance
- [ ] Documentação atualizada
- [ ] Treinamento da equipe
- [ ] Plano de suporte definido

---

## 7. Riscos e Mitigações

| Risco | Probabilidade | Impacto | Mitigação |
|-------|--------------|---------|-----------|
| Perda de dados durante migração JPA | Média | Alto | Backup completo, testes extensivos, migração incremental |
| Incompatibilidade de Web Services | Baixa | Médio | Testes com clientes reais, manter versão antiga em paralelo |
| Performance degradada | Média | Alto | Testes de carga, profiling, otimização de queries JPA |
| Problemas de transação | Média | Alto | Testes de concorrência, logs detalhados |
| Dependências não identificadas | Baixa | Médio | Análise estática adicional, testes exploratórios |

---

## 8. Estimativa de Esforço Total

| Fase | Duração | Recursos |
|------|---------|----------|
| Preparação | 1 semana | 1 desenvolvedor |
| Limpeza de código | 2 semanas | 1 desenvolvedor |
| Migração JPA | 6 semanas | 2 desenvolvedores |
| Migração Web Services | 1 semana | 1 desenvolvedor |
| Refatoração EJBs | 2 semanas | 2 desenvolvedores |
| Cache e utilitários | 1 semana | 1 desenvolvedor |
| Configuração Liberty | 1 semana | 1 desenvolvedor |
| Testes | 2 semanas | 2 desenvolvedores + 1 QA |
| Deploy | 1 semana | 1 desenvolvedor + 1 ops |
| **TOTAL** | **17 semanas** | **~4 meses** |

**Esforço Total:** Aproximadamente 60-80 dias-pessoa

---

## 9. Recursos Necessários

### Equipe
- 2 Desenvolvedores Java/JEE sênior
- 1 Especialista em JPA/Hibernate
- 1 Analista de QA
- 1 Administrador Liberty
- 1 DBA (part-time)

### Ferramentas
- IBM WebSphere Liberty 21.0.0.3+
- IBM Java 8
- Maven ou Gradle
- IDE (Eclipse/IntelliJ)
- Git
- Ferramentas de teste (JUnit, Arquillian)
- Ferramentas de profiling

### Infraestrutura
- Ambiente de desenvolvimento
- Ambiente de testes
- Ambiente de homologação
- Banco de dados de desenvolvimento

---

## 10. Próximos Passos Imediatos

1. **Aprovação do Plano:** Revisar e aprovar este plano com stakeholders
2. **Alocação de Recursos:** Confirmar disponibilidade da equipe
3. **Setup de Ambiente:** Configurar ambientes de desenvolvimento e teste
4. **Kickoff:** Reunião de início do projeto
5. **Início da Fase 1:** Começar preparação e limpeza de código

---

## 11. Contatos e Suporte

### Documentação IBM
- [Liberty Migration Guide](https://www.ibm.com/docs/en/was-liberty/base?topic=liberty-migrating-applications)
- [JPA 2.2 Documentation](https://www.ibm.com/docs/en/was-liberty/base?topic=features-java-persistence-api-22)
- [JAX-WS Documentation](https://www.ibm.com/docs/en/was-liberty/base?topic=features-java-xml-web-services-22)

### Suporte IBM
- IBM Support Portal
- IBM Developer Community
- Stack Overflow (tag: websphere-liberty)

---

## Apêndices

### Apêndice A: Mapeamento de Features Liberty

| Funcionalidade | Feature Liberty |
|----------------|-----------------|
| EJB 3.2 | `ejb-3.2` |
| JPA 2.2 | `jpa-2.2` |
| JAX-WS 2.2 | `jaxws-2.2` |
| Servlet 4.0 | `servlet-4.0` |
| JSP 2.3 | `jsp-2.3` |
| JDBC 4.2 | `jdbc-4.2` |
| JNDI 1.0 | `jndi-1.0` |
| JTA 1.2 | `jta-1.2` |
| CDI 2.0 | `cdi-2.0` |
| Bean Validation 2.0 | `beanValidation-2.0` |

### Apêndice B: Scripts Úteis

**Script para limpar classes WebLogic:**
```bash
#!/bin/bash
find . -name "*_vkbo0d_*" -type f -delete
find . -name "jsp_servlet" -type d -exec rm -rf {} +
echo "Limpeza concluída"
```

**Script para regenerar Web Services:**
```bash
#!/bin/bash
WSDL_URL="http://localhost:9080/trade3/services/TradeService?wsdl"
OUTPUT_DIR="src/main/java"
PACKAGE="com.ibm.websphere.samples.trade.ws"

wsimport -keep -s $OUTPUT_DIR -p $PACKAGE $WSDL_URL
echo "Web Services regenerados"
```

---

**Documento gerado por:** IBM Application Modernization Accelerator (AMA)  
**Data:** 2026-02-09  
**Versão:** 1.0