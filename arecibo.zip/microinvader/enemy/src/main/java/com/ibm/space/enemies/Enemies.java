package com.ibm.space.enemies;

import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.json.Json;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;


@Path("/")
public class Enemies {
	
	private static final Logger LOGGER = Logger.getLogger(Enemies.class.getName());
	private static final int GRID_MAX_X = 9;
	private static final int GRID_MAX_Y = 15;
	private static final int KEY_RESET = 48; // '0' key
	
	@Context
	private ServletContext context;
	
	
    @GET
 @Path("/position")
    @Produces("application/json")
 public Response position(@Context HttpServletRequest request) {
  try {
   JsonArrayBuilder arr = Json.createArrayBuilder();
   EnemiesValues values = getValues();
   
   if (values != null) {
    for (OneTie tie : values.getTies()) {
    	JsonObject obj = Json.createObjectBuilder()
    		.add("type", "enemy")
    		.add("id", tie.getId())
    		.add("destroyed", tie.isDestroyed())
    		.add("x", tie.getX())
    		.add("y", tie.getY())
    		.add("ip", "http://" + request.getLocalAddr() + ":" + request.getLocalPort())
    		.build();
    	arr.add(obj);
    }
   }
   return Response.ok(arr.build()).build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error getting enemy positions", e);
   return Response.serverError()
    .entity(Json.createObjectBuilder()
    	.add("error", "Failed to retrieve positions")
    	.build())
    .build();
  }
    }
    
    @GET
 @Path("/run")
    public Response run() {
  try {
   EnemiesValues values = getValues();
   if (values == null || values.isFinished()) {
    return Response.ok().build();
   }
   
   int x0 = values.getTies()[0].getX();
   int y0 = values.getTies()[0].getY();
   
   if (x0 <= GRID_MAX_X) {
    incrementAllX();
   } else {
    returnAllXtoBegin();
    if (y0 <= GRID_MAX_Y) {
    	incrementAllY();
    } else {
    	// Enemies reached the bottom - game over
    	destroyAllEnemies();
    	LOGGER.info("Enemies reached bottom - game over");
    }
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error updating enemy positions", e);
   return Response.serverError().build();
  }
    }

    @GET
    @Path("/destroy/{id}")
    public Response destroy(@PathParam("id") int id) {
  try {
   EnemiesValues values = getValues();
   if (values != null && id >= 0 && id < values.getTies().length) {
    values.getTies()[id].setDestroyed(true);
    LOGGER.log(Level.FINE, "Enemy destroyed: {0}", id);
    return Response.ok().build();
   }
   return Response.status(Response.Status.BAD_REQUEST)
    .entity(Json.createObjectBuilder()
    	.add("error", "Invalid enemy ID")
    	.build())
    .build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error destroying enemy: " + id, e);
   return Response.serverError().build();
  }
    }
    
    @GET
 @Path("/move/{key}")
 public Response move(@PathParam("key") int key) {
  try {
   if (key == KEY_RESET) {
    resetValues();
    LOGGER.info("Enemy values reset");
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error processing move", e);
   return Response.serverError().build();
  }
    }
    
    private void destroyAllEnemies() {
		for (int i = 0; i < getValues().getTies().length; i++) {
			getValues().getTies()[i].setDestroyed(true);
		}	
	}

	@GET
	@Path("/isFinished")
    @Produces("application/json")
    public Response hasEnded() throws Exception {
    	return Response.status(200).entity(Json.createObjectBuilder().add("finished", getValues().isFinished()).build()).build();
    }
    
    private void incrementAllY() {
		for (int i = 0; i < getValues().getTies().length; i++) {
			getValues().getTies()[i].setY(getValues().getTies()[i].getY() + 1);
		}
	}

	private void returnAllXtoBegin() {
		for (int i = 0; i < getValues().getTies().length; i++) {
		getValues().getTies()[i].setX( getValues().getTies()[i].getId() % 10);
	}
}
    
	private void incrementAllX() {
		for (int i = 0; i < getValues().getTies().length; i++) {
			getValues().getTies()[i].setX( getValues().getTies()[i].getX() + 1);
		}		
    }
	
	private EnemiesValues getValues()
	{
		if (context != null) {
			if (context.getAttribute(EnemiesValues.class.getSimpleName()) == null) {
				EnemiesValues values = new EnemiesValues();
				context.setAttribute(EnemiesValues.class.getSimpleName(), values);			
			}
			return (EnemiesValues) context.getAttribute(EnemiesValues.class.getSimpleName());
		}
		else {
			return null;
		}
	}
	
	private void resetValues()
	{
		EnemiesValues values = new EnemiesValues();
		context.setAttribute(EnemiesValues.class.getSimpleName(), values);
	}
}
