# Java Modernization Plan for MicroInvader

## Overview

This document provides a detailed, step-by-step plan to modernize the MicroInvader codebase from Java 8 to Java 17 LTS (or Java 21 LTS), incorporating modern Java features, Jakarta EE 10, and best practices.

---

## 1. Migration Strategy

### 1.1 Target Platform
- **Java Version**: Java 17 LTS (recommended) or Java 21 LTS
- **Jakarta EE**: Jakarta EE 10
- **Liberty**: Open Liberty 23.x or later
- **Build Tool**: Maven 3.9.x

### 1.2 Migration Phases

```mermaid
graph LR
    A[Java 8] --> B[Java 11]
    B --> C[Java 17]
    C --> D[Jakarta EE 10]
    D --> E[Modern Features]
```

---

## 2. Dependency Updates

### 2.1 Parent POM Updates

**File**: [`pom.xml`](pom.xml)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/maven-v4_0_0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.ibm.space</groupId>
    <artifactId>microinvader-parent</artifactId>
    <version>2.0.0</version>
    <packaging>pom</packaging>
    <name>MicroInvader Parent</name>

    <properties>
        <maven.compiler.release>17</maven.compiler.release>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
        
        <!-- Jakarta EE 10 -->
        <jakarta.version>10.0.0</jakarta.version>
        <microprofile.version>6.0</microprofile.version>
        
        <!-- Liberty -->
        <liberty.version>23.0.0.12</liberty.version>
        
        <!-- Testing -->
        <junit.version>5.10.1</junit.version>
        <mockito.version>5.8.0</mockito.version>
        <rest-assured.version>5.4.0</rest-assured.version>
    </properties>

    <modules>
        <module>bomb</module>
        <module>collision</module>
        <module>enemy</module>
        <module>player</module>
        <module>space</module>
    </modules>

    <dependencyManagement>
        <dependencies>
            <!-- Jakarta EE BOM -->
            <dependency>
                <groupId>jakarta.platform</groupId>
                <artifactId>jakarta.jakartaee-bom</artifactId>
                <version>${jakarta.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            
            <!-- MicroProfile BOM -->
            <dependency>
                <groupId>org.eclipse.microprofile</groupId>
                <artifactId>microprofile</artifactId>
                <version>${microprofile.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            
            <!-- Testing -->
            <dependency>
                <groupId>org.junit.jupiter</groupId>
                <artifactId>junit-jupiter</artifactId>
                <version>${junit.version}</version>
                <scope>test</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <build>
        <pluginManagement>
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-compiler-plugin</artifactId>
                    <version>3.11.0</version>
                    <configuration>
                        <release>17</release>
                        <compilerArgs>
                            <arg>-parameters</arg>
                            <arg>-Xlint:all</arg>
                        </compilerArgs>
                    </configuration>
                </plugin>
                
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-war-plugin</artifactId>
                    <version>3.4.0</version>
                </plugin>
                
                <plugin>
                    <groupId>io.openliberty.tools</groupId>
                    <artifactId>liberty-maven-plugin</artifactId>
                    <version>3.9</version>
                </plugin>
                
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-surefire-plugin</artifactId>
                    <version>3.2.3</version>
                </plugin>
            </plugins>
        </pluginManagement>
    </build>
</project>
```

### 2.2 Module POM Updates

**Example for bomb module** - Apply similar changes to all modules:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    
    <parent>
        <groupId>com.ibm.space</groupId>
        <artifactId>microinvader-parent</artifactId>
        <version>2.0.0</version>
    </parent>
    
    <artifactId>bomb</artifactId>
    <packaging>war</packaging>
    <name>Bomb Service</name>

    <dependencies>
        <!-- Jakarta EE APIs -->
        <dependency>
            <groupId>jakarta.servlet</groupId>
            <artifactId>jakarta.servlet-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <dependency>
            <groupId>jakarta.ws.rs</groupId>
            <artifactId>jakarta.ws.rs-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <dependency>
            <groupId>jakarta.json</groupId>
            <artifactId>jakarta.json-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <dependency>
            <groupId>jakarta.json.bind</groupId>
            <artifactId>jakarta.json.bind-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <dependency>
            <groupId>jakarta.enterprise</groupId>
            <artifactId>jakarta.enterprise.cdi-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <!-- MicroProfile -->
        <dependency>
            <groupId>org.eclipse.microprofile.config</groupId>
            <artifactId>microprofile-config-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <dependency>
            <groupId>org.eclipse.microprofile.rest.client</groupId>
            <artifactId>microprofile-rest-client-api</artifactId>
            <scope>provided</scope>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <scope>test</scope>
        </dependency>
        
        <dependency>
            <groupId>org.mockito</groupId>
            <artifactId>mockito-core</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
</project>
```

---

## 3. Code Modernization

### 3.1 Package Rename: javax → jakarta

**All Java files need package updates:**

```java
// OLD (Java EE)
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.json.Json;

// NEW (Jakarta EE)
import jakarta.servlet.ServletContext;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.json.Json;
```

### 3.2 Modernize Bombs.java

**File**: [`bomb/src/main/java/com/ibm/space/bombs/Bombs.java`](bomb/src/main/java/com/ibm/space/bombs/Bombs.java)

```java
package com.ibm.space.bombs;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/")
@ApplicationScoped
public class Bombs {
    
    private static final Logger LOGGER = Logger.getLogger(Bombs.class.getName());
    
    @Context 
    private ServletContext context;
    
    @Inject
    @ConfigProperty(name = "game.grid.size", defaultValue = "20")
    private int gridSize;
    
    @GET
    @Path("/position")
    @Produces("application/json")
    public Response position(@Context HttpServletRequest request) {
        try {
            JsonArrayBuilder arr = Json.createArrayBuilder();
            BombsValues values = getValues();
            
            if (values != null) {
                List<OneBomb> bombs = values.getBombs();
                for (OneBomb bomb : bombs) {
                    JsonObject obj = Json.createObjectBuilder()
                        .add("type", "bomb")
                        .add("x", bomb.getX())
                        .add("y", bomb.getY())
                        .add("up", bomb.isFromPlayer())
                        .add("id", bomb.getId())
                        .add("destroyed", bomb.isDestroyed())
                        .add("ip", "http://%s:%d".formatted(
                            request.getLocalAddr(), 
                            request.getLocalPort()))
                        .build();
                    arr.add(obj);
                }
            }
            
            return Response.ok(arr.build()).build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error getting bomb positions", e);
            return Response.serverError()
                .entity(Json.createObjectBuilder()
                    .add("error", "Failed to retrieve positions")
                    .build())
                .build();
        }
    }
    
    @GET
    @Path("/run")
    public Response run() {
        try {
            BombsValues values = getValues();
            if (values == null || values.isHasFinished()) {
                return Response.ok().build();
            }
            
            values.getBombs().stream()
                .filter(bomb -> !bomb.isDestroyed())
                .forEach(this::updateBombPosition);
            
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error running bomb update", e);
            return Response.serverError().build();
        }
    }
    
    private void updateBombPosition(OneBomb bomb) {
        if (bomb.isFromPlayer()) {
            if (bomb.getY() <= 0) {
                bomb.setDestroyed(true);
            } else {
                bomb.setY(bomb.getY() - 1);
            }
        } else {
            if (bomb.getY() >= gridSize) {
                bomb.setDestroyed(true);
            } else {
                bomb.setY(bomb.getY() + 1);
            }
        }
    }
    
    @GET
    @Path("/destroy/{id}")
    public Response destroy(@PathParam("id") long id) {
        try {
            BombsValues values = getValues();
            if (values != null) {
                values.getBombs().stream()
                    .filter(bomb -> bomb.getId() == id)
                    .findFirst()
                    .ifPresent(bomb -> bomb.setDestroyed(true));
            }
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error destroying bomb: " + id, e);
            return Response.serverError().build();
        }
    }
    
    @GET
    @Path("/move/{key}")
    public Response move(@PathParam("key") int key) {
        if (key == 48) { // '0' key - reset
            resetValues();
        }
        return Response.ok().build();
    }
    
    @GET
    @Path("/isFinished")
    @Produces("application/json")
    public Response hasEnded() {
        return Response.ok(
            Json.createObjectBuilder()
                .add("finished", false)
                .build()
        ).build();
    }
    
    @GET
    @Path("/create/{x}/{y}/{fromPlayer}")
    public Response create(
            @PathParam("x") @Min(0) @Max(19) int x,
            @PathParam("y") @Min(0) @Max(19) int y,
            @PathParam("fromPlayer") boolean fromPlayer) {
        
        try {
            OneBomb bomb = new OneBomb(
                (int)(Math.random() * Integer.MAX_VALUE),
                x, y, fromPlayer
            );
            
            BombsValues values = getValues();
            if (values != null) {
                values.getBombs().add(bomb);
                LOGGER.log(Level.FINE, "Created bomb at ({0},{1})", 
                    new Object[]{x, y});
            }
            
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error creating bomb", e);
            return Response.serverError().build();
        }
    }
    
    private BombsValues getValues() {
        if (context == null) {
            return null;
        }
        
        String key = BombsValues.class.getSimpleName();
        BombsValues values = (BombsValues) context.getAttribute(key);
        
        if (values == null) {
            values = new BombsValues();
            context.setAttribute(key, values);
        }
        
        return values;
    }
    
    private void resetValues() {
        if (context != null) {
            context.setAttribute(
                BombsValues.class.getSimpleName(),
                new BombsValues()
            );
            LOGGER.info("Bomb values reset");
        }
    }
}
```

### 3.3 Modernize BombsValues.java

**File**: [`bomb/src/main/java/com/ibm/space/bombs/BombsValues.java`](bomb/src/main/java/com/ibm/space/bombs/BombsValues.java)

```java
package com.ibm.space.bombs;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Thread-safe collection of bombs in the game.
 * Uses CopyOnWriteArrayList for concurrent access.
 */
public class BombsValues implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 1L;
    
    private final List<OneBomb> bombs;
    private byte[] imageUp;
    private byte[] imageDown;
    private byte[] blank;
    private volatile boolean hasFinished;
    
    public BombsValues() {
        this.bombs = new CopyOnWriteArrayList<>();
        this.hasFinished = false;
    }
    
    // Getters and setters with proper encapsulation
    public List<OneBomb> getBombs() {
        return bombs;
    }
    
    public byte[] getImageUp() {
        return imageUp != null ? imageUp.clone() : null;
    }
    
    public void setImageUp(byte[] imageUp) {
        this.imageUp = imageUp != null ? imageUp.clone() : null;
    }
    
    public byte[] getImageDown() {
        return imageDown != null ? imageDown.clone() : null;
    }
    
    public void setImageDown(byte[] imageDown) {
        this.imageDown = imageDown != null ? imageDown.clone() : null;
    }
    
    public byte[] getBlank() {
        return blank != null ? blank.clone() : null;
    }
    
    public void setBlank(byte[] blank) {
        this.blank = blank != null ? blank.clone() : null;
    }
    
    public boolean isHasFinished() {
        return hasFinished;
    }
    
    public void setHasFinished(boolean hasFinished) {
        this.hasFinished = hasFinished;
    }
}
```

### 3.4 Modernize OneBomb.java

```java
package com.ibm.space.bombs;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a single bomb in the game.
 * Immutable except for position and destroyed state.
 */
public class OneBomb implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 1L;
    
    private final long id;
    private final boolean fromPlayer;
    private volatile int x;
    private volatile int y;
    private volatile boolean destroyed;
    
    public OneBomb(long id, int x, int y, boolean fromPlayer) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.fromPlayer = fromPlayer;
        this.destroyed = false;
    }
    
    // Getters
    public long getId() { return id; }
    public int getX() { return x; }
    public int getY() { return y; }
    public boolean isFromPlayer() { return fromPlayer; }
    public boolean isDestroyed() { return destroyed; }
    
    // Setters for mutable fields
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setDestroyed(boolean destroyed) { this.destroyed = destroyed; }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OneBomb oneBomb = (OneBomb) o;
        return id == oneBomb.id;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    @Override
    public String toString() {
        return "OneBomb{id=%d, x=%d, y=%d, fromPlayer=%b, destroyed=%b}"
            .formatted(id, x, y, fromPlayer, destroyed);
    }
}
```

### 3.5 Modernize Space.java with MicroProfile REST Client

**File**: [`space/src/main/java/com/ibm/space/space/Space.java`](space/src/main/java/com/ibm/space/space/Space.java)

```java
package com.ibm.space.space;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;

@Path("/")
@ApplicationScoped
public class Space {
    
    private static final Logger LOGGER = Logger.getLogger(Space.class.getName());
    private final Random random = new Random();
    
    @Inject
    @RestClient
    private EnemyServiceClient enemyClient;
    
    @Inject
    @RestClient
    private PlayerServiceClient playerClient;
    
    @Inject
    @RestClient
    private BombServiceClient bombClient;
    
    @Inject
    @RestClient
    private CollisionServiceClient collisionClient;
    
    @Inject
    @ConfigProperty(name = "game.bomb.spawn.chance", defaultValue = "30")
    private int bombSpawnChance;
    
    @GET
    @Path("/position")
    @Produces("application/json")
    public Response position() {
        try {
            // Parallel async calls for better performance
            CompletableFuture<JsonArray> enemyFuture = 
                CompletableFuture.supplyAsync(() -> enemyClient.getPositions());
            CompletableFuture<JsonArray> playerFuture = 
                CompletableFuture.supplyAsync(() -> playerClient.getPositions());
            CompletableFuture<JsonArray> bombFuture = 
                CompletableFuture.supplyAsync(() -> bombClient.getPositions());
            CompletableFuture<JsonArray> collisionFuture = 
                CompletableFuture.supplyAsync(() -> collisionClient.getPositions());
            
            // Wait for all and combine
            JsonArrayBuilder allElements = Json.createArrayBuilder();
            
            Stream.of(enemyFuture, playerFuture, bombFuture, collisionFuture)
                .map(CompletableFuture::join)
                .flatMap(array -> array.stream())
                .forEach(allElements::add);
            
            return Response.ok(allElements.build())
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                .header("Access-Control-Allow-Headers", "Content-Type")
                .build();
                
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error getting positions", e);
            return Response.serverError()
                .entity(Json.createObjectBuilder()
                    .add("error", "Failed to retrieve positions")
                    .build())
                .build();
        }
    }
    
    @GET
    @Path("/run")
    public Response run() {
        try {
            // Run all services
            List.of(enemyClient, playerClient, bombClient, collisionClient)
                .forEach(client -> {
                    try {
                        client.run();
                    } catch (Exception e) {
                        LOGGER.log(Level.WARNING, "Service run failed", e);
                    }
                });
            
            // Create enemy bombs
            createEnemyBombs();
            
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error in game loop", e);
            return Response.serverError().build();
        }
    }
    
    private void createEnemyBombs() {
        try {
            JsonArray enemies = enemyClient.getPositions();
            
            if (enemies.isEmpty()) {
                return;
            }
            
            // Find enemy bounds
            int maxX = 0, minX = Integer.MAX_VALUE, maxY = 0;
            
            for (var element : enemies) {
                JsonObject enemy = element.asJsonObject();
                int x = enemy.getInt("x");
                int y = enemy.getInt("y");
                maxX = Math.max(maxX, x);
                minX = Math.min(minX, x);
                maxY = Math.max(maxY, y);
            }
            
            // Random bomb spawn
            if (random.nextInt(100) < bombSpawnChance && maxX > minX) {
                int posX = minX + random.nextInt(maxX - minX + 1);
                int posY = maxY + 1;
                bombClient.create(posX, posY, false);
                LOGGER.log(Level.FINE, "Enemy bomb created at ({0},{1})", 
                    new Object[]{posX, posY});
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to create enemy bombs", e);
        }
    }
    
    @GET
    @Path("/destroy/{id}")
    public Response destroy(@PathParam("id") int id) {
        try {
            List.of(enemyClient, playerClient, bombClient, collisionClient)
                .forEach(client -> {
                    try {
                        client.destroy(id);
                    } catch (Exception e) {
                        LOGGER.log(Level.FINE, "Destroy call failed for service", e);
                    }
                });
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error destroying entity: " + id, e);
            return Response.serverError().build();
        }
    }
    
    @GET
    @Path("/move/{key}")
    public Response move(@PathParam("key") int key) {
        try {
            List.of(enemyClient, playerClient, bombClient, collisionClient)
                .forEach(client -> {
                    try {
                        client.move(key);
                    } catch (Exception e) {
                        LOGGER.log(Level.FINE, "Move call failed for service", e);
                    }
                });
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error processing move: " + key, e);
            return Response.serverError().build();
        }
    }
    
    @GET
    @Path("/create/{x}/{y}/{fromPlayer}")
    public Response create(
            @PathParam("x") int x,
            @PathParam("y") int y,
            @PathParam("fromPlayer") boolean fromPlayer) {
        try {
            bombClient.create(x, y, fromPlayer);
            return Response.ok().build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error creating bomb", e);
            return Response.serverError().build();
        }
    }
    
    @GET
    @Path("/isFinished")
    @Produces("application/json")
    public Response isFinished() {
        try {
            boolean finished = Stream.of(
                    enemyClient.isFinished(),
                    playerClient.isFinished(),
                    bombClient.isFinished(),
                    collisionClient.isFinished()
                )
                .anyMatch(response -> response.getBoolean("finished"));
            
            return Response.ok(
                Json.createObjectBuilder()
                    .add("finished", finished)
                    .build()
            ).build();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error checking game status", e);
            return Response.serverError().build();
        }
    }
}
```

### 3.6 Create MicroProfile REST Client Interfaces

**New File**: `space/src/main/java/com/ibm/space/space/GameServiceClient.java`

```java
package com.ibm.space.space;

import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.ws.rs.*;

/**
 * Base interface for game service clients
 */
public interface GameServiceClient {
    
    @GET
    @Path("/position")
    @Produces("application/json")
    JsonArray getPositions();
    
    @GET
    @Path("/run")
    void run();
    
    @GET
    @Path("/destroy/{id}")
    void destroy(@PathParam("id") int id);
    
    @GET
    @Path("/move/{key}")
    void move(@PathParam("key") int key);
    
    @GET
    @Path("/isFinished")
    @Produces("application/json")
    JsonObject isFinished();
}
```

**New File**: `space/src/main/java/com/ibm/space/space/EnemyServiceClient.java`

```java
package com.ibm.space.space;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "enemy-service")
public interface EnemyServiceClient extends GameServiceClient {
}
```

**Similar interfaces for**: `PlayerServiceClient`, `BombServiceClient`, `CollisionServiceClient`

### 3.7 Configuration File

**New File**: `space/src/main/resources/META-INF/microprofile-config.properties`

```properties
# Game Configuration
game.grid.size=20
game.bomb.spawn.chance=30
game.tick.interval.ms=400

# Service URLs
enemy-service/mp-rest/url=http://localhost:9081/enemy-1.0
enemy-service/mp-rest/scope=jakarta.inject.Singleton

player-service/mp-rest/url=http://localhost:9081/player-1.0
player-service/mp-rest/scope=jakarta.inject.Singleton

bomb-service/mp-rest/url=http://localhost:9081/bomb-1.0
bomb-service/mp-rest/scope=jakarta.inject.Singleton

collision-service/mp-rest/url=http://localhost:9081/collision-1.0
collision-service/mp-rest/scope=jakarta.inject.Singleton

# Timeouts
mp.rest.connectTimeout=5000
mp.rest.readTimeout=10000
```

---

## 4. Modern Java Features to Adopt

### 4.1 Records (Java 16+)

```java
// Replace simple data classes with records
public record BombPosition(long id, int x, int y, boolean fromPlayer, boolean destroyed) {
    // Compact constructor for validation
    public BombPosition {
        if (x < 0 || x > 19 || y < 0 || y > 19) {
            throw new IllegalArgumentException("Invalid coordinates");
        }
    }
}
```

### 4.2 Pattern Matching (Java 17+)

```java
// Modern switch expressions
public String getEntityType(Object entity) {
    return switch (entity) {
        case OneBomb bomb -> "bomb";
        case OneTie tie -> "enemy";
        case PlayerValues player -> "player";
        case null -> "unknown";
        default -> throw new IllegalArgumentException("Unknown entity type");
    };
}
```

### 4.3 Text Blocks (Java 15+)

```java
// For JSON templates or multi-line strings
private static final String ERROR_RESPONSE = """
    {
        "error": "Service unavailable",
        "timestamp": "%s",
        "details": "%s"
    }
    """;
```

### 4.4 Sealed Classes (Java 17+)

```java
// For game entities
public sealed interface GameEntity 
    permits Bomb, Enemy, Player {
    int getX();
    int getY();
    boolean isDestroyed();
}
```

### 4.5 Stream API Enhancements

```java
// Use modern stream operations
public List<OneBomb> getActiveBombs() {
    return bombs.stream()
        .filter(bomb -> !bomb.isDestroyed())
        .toList(); // Java 16+ - returns immutable list
}
```

---

## 5. Testing Strategy

### 5.1 Unit Tests with JUnit 5

```java
package com.ibm.space.bombs;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Bomb Service Tests")
class BombsTest {
    
    private Bombs bombService;
    
    @BeforeEach
    void setUp() {
        bombService = new Bombs();
    }
    
    @Test
    @DisplayName("Should create bomb with valid coordinates")
    void testCreateBomb() {
        Response response = bombService.create(10, 10, true);
        assertEquals(200, response.getStatus());
    }
    
    @ParameterizedTest
    @CsvSource({
        "-1, 10, false",
        "10, -1, false",
        "20, 10, false",
        "10, 20, false"
    })
    @DisplayName("Should reject invalid coordinates")
    void testInvalidCoordinates(int x, int y, boolean expected) {
        assertThrows(ValidationException.class, 
            () -> bombService.create(x, y, true));
    }
    
    @Test
    @DisplayName("Should update bomb position correctly")
    void testBombMovement() {
        // Test implementation
    }
}
```

---

## 6. Liberty Server Configuration

**File**: [`src/main/liberty/config/server.xml`](src/main/liberty/config/server.xml)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<server description="MicroInvader Game Server">

    <featureManager>
        <!-- Jakarta EE 10 -->
        <feature>jakartaee-10.0</feature>
        
        <!-- MicroProfile 6.0 -->
        <feature>microProfile-6.0</feature>
        
        <!-- Additional features -->
        <feature>mpHealth-4.0</feature>
        <feature>mpMetrics-5.0</feature>
        <feature>mpOpenAPI-3.1</feature>
        <feature>mpConfig-3.0</feature>
        <feature>mpRestClient-3.0</feature>
    </featureManager>
    
    <!-- HTTP Endpoint -->
    <httpEndpoint 
        id="defaultHttpEndpoint"
        host="*"
        httpPort="${default.http.port}"
        httpsPort="${default.https.port}">
        <tcpOptions soReuseAddr="true"/>
    </httpEndpoint>
    
    <!-- Application Manager -->
    <applicationManager autoExpand="true"/>
    
    <!-- Logging -->
    <logging 
        traceSpecification="*=info:com.ibm.space.*=fine"
        maxFileSize="20"
        maxFiles="10"/>
    
    <!-- CORS Configuration -->
    <cors 
        domain="/"
        allowedOrigins="*"
        allowedMethods="GET, POST, PUT, DELETE, OPTIONS"
        allowedHeaders="*"
        maxAge="3600"/>
    
</server>
```

---

## 7. Migration Checklist

### Phase 1: Preparation
- [ ] Backup current codebase
- [ ] Create feature branch for modernization
- [ ] Update Maven to 3.9.x
- [ ] Install Java 17 JDK

### Phase 2: Dependency Updates
- [ ] Update parent POM with Java 17 and Jakarta EE 10
- [ ] Update all module POMs
- [ ] Update Liberty version
- [ ] Add MicroProfile dependencies

### Phase 3: Code Migration
- [ ] Replace `javax.*` with `jakarta.*` imports
- [ ] Update Bombs service
- [ ] Update Enemy service
- [ ] Update Player service
- [ ] Update Collision service
- [ ] Update Space orchestrator
- [ ] Create REST client interfaces

### Phase 4: Modernization
- [ ] Replace Vector with CopyOnWriteArrayList
- [ ] Add proper exception handling
- [ ] Implement logging
- [ ] Add input validation
- [ ] Extract constants
- [ ] Use modern Java features (records, pattern matching, etc.)

### Phase 5: Configuration
- [ ] Create microprofile-config.properties
- [ ] Update server.xml
- [ ] Configure REST clients
- [ ] Set up CORS properly

### Phase 6: Testing
- [ ] Write unit tests for all services
- [ ] Write integration tests
- [ ] Performance testing
- [ ] Security testing

### Phase 7: Documentation
- [ ] Update README
- [ ] Add API documentation (OpenAPI)
- [ ] Document configuration options
- [ ] Create deployment guide

---

## 8. Expected Benefits

### Performance
- **Faster startup**: Modern JVM optimizations
- **Better throughput**: Improved garbage collection (G1GC, ZGC)
- **Lower memory**: Compact strings, better heap management

### Security
- **Updated dependencies**: No known CVEs
- **Better TLS**: Modern cipher suites
- **Input validation**: Built-in validation framework

### Maintainability
- **Modern syntax**: Cleaner, more readable code
- **Better tooling**: Enhanced IDE support
- **Type safety**: Records and sealed classes

### Scalability
- **Async operations**: CompletableFuture, reactive streams
- **Better concurrency**: Virtual threads (Java 21)
- **Cloud-native**: MicroProfile for containerization

---

## 9. Rollback Plan

If issues arise during migration:

1. **Immediate rollback**: Revert to feature branch
2. **Partial rollback**: Keep dependency updates, revert code changes
3. **Gradual migration**: Migrate one service at a time
4. **Compatibility mode**: Run Java 17 in Java 8 compatibility mode temporarily

---

## 10. Timeline Estimate

| Phase | Duration | Effort |
|-------|----------|--------|
| Preparation | 1 day | Low |
| Dependency Updates | 2 days | Medium |
| Code Migration | 1 week | High |
| Modernization | 1 week | High |
| Configuration | 2 days | Medium |
| Testing | 1 week | High |
| Documentation | 3 days | Medium |
| **Total** | **4 weeks** | **High** |

---

## Conclusion

This modernization plan provides a comprehensive path to upgrade MicroInvader from Java 8 to Java 17+ with Jakarta EE 10. The migration will significantly improve security, performance, maintainability, and prepare the codebase for future enhancements.

**Next Steps:**
1. Review and approve this plan
2. Set up development environment with Java 17
3. Begin Phase 1: Preparation
4. Execute migration in controlled phases
5. Validate each phase before proceeding