# Code Improvement Plan - Detailed Analysis

## Overview
This document provides comprehensive improvements for the identified issues in the MicroInvader game codebase, focusing on input validation, error handling, and best practices.

---

## 1. Issues Identified

### Issue 1: [`Bombs.java:97-103`](bomb/src/main/java/com/ibm/space/bombs/Bombs.java:97)
**Current Code:**
```java
@GET
@Path("/create/{x}/{y}/{fromPlayer}")
public void create(@PathParam("x") String x, @PathParam("y") String y, @PathParam("fromPlayer") String up) throws Exception {
    int valuex = Integer.parseInt(x);
    int valuey = Integer.parseInt(y);
    boolean fromPlayer = Boolean.parseBoolean(up);
    OneBomb b = new OneBomb((int)(Math.random() * Integer.MAX_VALUE), valuex, valuey, fromPlayer); 
    if (getValues() != null)  getValues().getBombs().add(b);
}
```

**Problems:**
- No validation on x, y coordinates (should be 0-19 based on game grid)
- No error handling for `NumberFormatException`
- No HTTP response returned (void method)
- Magic numbers without constants
- Throws generic `Exception`
- No logging for debugging
- Weak random ID generation could cause collisions

### Issue 2: [`Player.java:56-62`](player/src/main/java/com/ibm/space/player/Player.java:56)
**Current Code:**
```java
@GET
@Path("/move/{key}")
public void move(@PathParam("key") int key) throws Exception {
    if (key == 48) resetValues();
    if (key == 111)
        if (getValues().getX() > 0) getValues().setX(getValues().getX()-1);
    if (key== 112)
        if (getValues().getX() < 19) getValues().setX(getValues().getX()+1);
}
```

**Problems:**
- No bounds checking before parsing path parameter
- Magic numbers (48, 111, 112, 19) without constants
- No validation on key parameter
- No HTTP response returned
- Throws generic `Exception`
- No logging
- Inconsistent spacing and formatting

---

## 2. Improvement Categories

### A. Input Validation
- Validate all path parameters before parsing
- Check coordinate bounds (0-19 for game grid)
- Validate key codes against expected values

### B. Error Handling
- Replace generic `Exception` with specific exceptions
- Return proper HTTP status codes (400 for bad requests, 500 for server errors)
- Provide meaningful error messages in JSON format

### C. Constants & Configuration
- Define constants for magic numbers
- Create configuration class for game boundaries
- Use enums for key codes

### D. Code Quality
- Add comprehensive JavaDoc comments
- Improve method naming and structure
- Add logging for debugging and monitoring
- Follow consistent code formatting

### E. Performance & Security
- Use `SecureRandom` for ID generation
- Add input sanitization
- Consider rate limiting for API endpoints

---

## 3. Improved Code

### 3.1 Create Constants Class

**File:** `bomb/src/main/java/com/ibm/space/bombs/BombConstants.java`

```java
package com.ibm.space.bombs;

/**
 * Constants for bomb management in the game.
 */
public final class BombConstants {
    
    // Grid boundaries
    public static final int MIN_COORDINATE = 0;
    public static final int MAX_COORDINATE = 19;
    public static final int GRID_SIZE = 20;
    
    // Error messages
    public static final String ERROR_INVALID_X = "X coordinate must be between 0 and 19";
    public static final String ERROR_INVALID_Y = "Y coordinate must be between 0 and 19";
    public static final String ERROR_INVALID_NUMBER = "Coordinate must be a valid integer";
    public static final String ERROR_INVALID_BOOLEAN = "fromPlayer must be 'true' or 'false'";
    public static final String ERROR_BOMB_CREATION = "Failed to create bomb";
    
    private BombConstants() {
        // Prevent instantiation
        throw new AssertionError("Cannot instantiate constants class");
    }
}
```

### 3.2 Improved Bombs.java

**File:** `bomb/src/main/java/com/ibm/space/bombs/Bombs.java`

```java
package com.ibm.space.bombs;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.security.SecureRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/")
public class Bombs {
    
    private static final Logger LOGGER = Logger.getLogger(Bombs.class.getName());
    private static final SecureRandom RANDOM = new SecureRandom();
    
    @Context 
    ServletContext context;
    
    // ... existing position() and hasEnded() methods ...
    
    /**
     * Creates a new bomb at the specified coordinates.
     * 
     * @param x The x-coordinate (0-19)
     * @param y The y-coordinate (0-19)
     * @param up String representation of bomb direction ("true" for player, "false" for enemy)
     * @return Response with status 201 (Created) on success, 400 (Bad Request) on validation error,
     *         or 500 (Internal Server Error) on creation failure
     */
    @GET
    @Path("/create/{x}/{y}/{fromPlayer}")
    @Produces("application/json")
    public Response create(
            @PathParam("x") String x, 
            @PathParam("y") String y, 
            @PathParam("fromPlayer") String up) {
        
        try {
            // Validate and parse coordinates
            ValidationResult<Integer> xResult = validateAndParseCoordinate(x, "x");
            if (!xResult.isValid()) {
                return createErrorResponse(Response.Status.BAD_REQUEST, xResult.getErrorMessage());
            }
            
            ValidationResult<Integer> yResult = validateAndParseCoordinate(y, "y");
            if (!yResult.isValid()) {
                return createErrorResponse(Response.Status.BAD_REQUEST, yResult.getErrorMessage());
            }
            
            // Validate and parse boolean
            ValidationResult<Boolean> fromPlayerResult = validateAndParseBoolean(up);
            if (!fromPlayerResult.isValid()) {
                return createErrorResponse(Response.Status.BAD_REQUEST, fromPlayerResult.getErrorMessage());
            }
            
            // Create bomb with validated values
            int valuex = xResult.getValue();
            int valuey = yResult.getValue();
            boolean fromPlayer = fromPlayerResult.getValue();
            
            // Generate secure random ID
            int bombId = RANDOM.nextInt(Integer.MAX_VALUE);
            OneBomb bomb = new OneBomb(bombId, valuex, valuey, fromPlayer);
            
            // Add bomb to collection
            BombsValues values = getValues();
            if (values == null) {
                LOGGER.log(Level.SEVERE, "BombsValues is null, cannot create bomb");
                return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, 
                    "Game state not initialized");
            }
            
            values.getBombs().add(bomb);
            
            LOGGER.log(Level.INFO, "Bomb created: id={0}, x={1}, y={2}, fromPlayer={3}", 
                new Object[]{bombId, valuex, valuey, fromPlayer});
            
            // Return success response with bomb details
            JsonObject response = Json.createObjectBuilder()
                .add("status", "success")
                .add("message", "Bomb created successfully")
                .add("bomb", Json.createObjectBuilder()
                    .add("id", bombId)
                    .add("x", valuex)
                    .add("y", valuey)
                    .add("fromPlayer", fromPlayer))
                .build();
            
            return Response.status(Response.Status.CREATED)
                .entity(response)
                .build();
                
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error creating bomb", e);
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, 
                "An unexpected error occurred: " + e.getMessage());
        }
    }
    
    /**
     * Validates and parses a coordinate string.
     * 
     * @param coordinate The coordinate string to validate
     * @param coordinateName The name of the coordinate (for error messages)
     * @return ValidationResult containing the parsed value or error message
     */
    private ValidationResult<Integer> validateAndParseCoordinate(String coordinate, String coordinateName) {
        if (coordinate == null || coordinate.trim().isEmpty()) {
            return ValidationResult.error(coordinateName + " coordinate cannot be empty");
        }
        
        try {
            int value = Integer.parseInt(coordinate.trim());
            
            if (value < BombConstants.MIN_COORDINATE || value > BombConstants.MAX_COORDINATE) {
                return ValidationResult.error(
                    coordinateName + " coordinate must be between " + 
                    BombConstants.MIN_COORDINATE + " and " + BombConstants.MAX_COORDINATE + 
                    ", got: " + value);
            }
            
            return ValidationResult.success(value);
            
        } catch (NumberFormatException e) {
            return ValidationResult.error(
                coordinateName + " coordinate must be a valid integer, got: " + coordinate);
        }
    }
    
    /**
     * Validates and parses a boolean string.
     * 
     * @param value The boolean string to validate
     * @return ValidationResult containing the parsed value or error message
     */
    private ValidationResult<Boolean> validateAndParseBoolean(String value) {
        if (value == null || value.trim().isEmpty()) {
            return ValidationResult.error("fromPlayer parameter cannot be empty");
        }
        
        String trimmed = value.trim().toLowerCase();
        if (!trimmed.equals("true") && !trimmed.equals("false")) {
            return ValidationResult.error(
                "fromPlayer must be 'true' or 'false', got: " + value);
        }
        
        return ValidationResult.success(Boolean.parseBoolean(trimmed));
    }
    
    /**
     * Creates a JSON error response.
     * 
     * @param status The HTTP status code
     * @param message The error message
     * @return Response object with error details
     */
    private Response createErrorResponse(Response.Status status, String message) {
        JsonObject error = Json.createObjectBuilder()
            .add("status", "error")
            .add("message", message)
            .add("code", status.getStatusCode())
            .build();
        
        return Response.status(status)
            .entity(error)
            .build();
    }
    
    private BombsValues getValues() {
        if (context != null) {
            if (context.getAttribute(BombsValues.class.getSimpleName()) == null) {
                BombsValues values = new BombsValues();
                context.setAttribute(BombsValues.class.getSimpleName(), values);
            }
            return (BombsValues) context.getAttribute(BombsValues.class.getSimpleName());
        }
        return null;
    }
    
    /**
     * Generic validation result wrapper.
     * 
     * @param <T> The type of the validated value
     */
    private static class ValidationResult<T> {
        private final T value;
        private final String errorMessage;
        private final boolean valid;
        
        private ValidationResult(T value, String errorMessage, boolean valid) {
            this.value = value;
            this.errorMessage = errorMessage;
            this.valid = valid;
        }
        
        public static <T> ValidationResult<T> success(T value) {
            return new ValidationResult<>(value, null, true);
        }
        
        public static <T> ValidationResult<T> error(String errorMessage) {
            return new ValidationResult<>(null, errorMessage, false);
        }
        
        public boolean isValid() {
            return valid;
        }
        
        public T getValue() {
            return value;
        }
        
        public String getErrorMessage() {
            return errorMessage;
        }
    }
}
```

### 3.3 Create Player Constants Class

**File:** `player/src/main/java/com/ibm/space/player/PlayerConstants.java`

```java
package com.ibm.space.player;

/**
 * Constants for player management in the game.
 */
public final class PlayerConstants {
    
    // Grid boundaries
    public static final int MIN_X = 0;
    public static final int MAX_X = 19;
    public static final int FIXED_Y = 19;
    public static final int GRID_WIDTH = 20;
    
    // Key codes
    public static final int KEY_RESET = 48;   // '0' key
    public static final int KEY_LEFT = 111;   // 'o' key
    public static final int KEY_RIGHT = 112;  // 'p' key
    
    // Movement
    public static final int MOVE_STEP = 1;
    
    // Error messages
    public static final String ERROR_INVALID_KEY = "Invalid key code";
    public static final String ERROR_OUT_OF_BOUNDS = "Movement would place player out of bounds";
    public static final String ERROR_PLAYER_STATE = "Player state not initialized";
    
    private PlayerConstants() {
        // Prevent instantiation
        throw new AssertionError("Cannot instantiate constants class");
    }
}
```

### 3.4 Improved Player.java

**File:** `player/src/main/java/com/ibm/space/player/Player.java`

```java
package com.ibm.space.player;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/")
public class Player {
    
    private static final Logger LOGGER = Logger.getLogger(Player.class.getName());
    
    @Context 
    ServletContext context;
    
    // ... existing position() and hasEnded() methods ...
    
    /**
     * Moves the player based on the provided key code.
     * Supported keys:
     * - 48 ('0'): Reset player position
     * - 111 ('o'): Move left
     * - 112 ('p'): Move right
     * 
     * @param key The key code representing the desired action
     * @return Response with status 200 (OK) on success, 400 (Bad Request) on invalid key,
     *         or 500 (Internal Server Error) on state error
     */
    @GET
    @Path("/move/{key}")
    @Produces("application/json")
    public Response move(@PathParam("key") int key) {
        
        try {
            PlayerValues values = getValues();
            if (values == null) {
                LOGGER.log(Level.SEVERE, "PlayerValues is null, cannot move player");
                return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, 
                    PlayerConstants.ERROR_PLAYER_STATE);
            }
            
            int currentX = values.getX();
            String action;
            
            // Process key input
            if (key == PlayerConstants.KEY_RESET) {
                resetValues();
                action = "reset";
                LOGGER.log(Level.INFO, "Player position reset");
                
            } else if (key == PlayerConstants.KEY_LEFT) {
                if (currentX > PlayerConstants.MIN_X) {
                    values.setX(currentX - PlayerConstants.MOVE_STEP);
                    action = "moved_left";
                    LOGGER.log(Level.FINE, "Player moved left: x={0}", values.getX());
                } else {
                    return createErrorResponse(Response.Status.BAD_REQUEST, 
                        "Cannot move left: already at minimum position");
                }
                
            } else if (key == PlayerConstants.KEY_RIGHT) {
                if (currentX < PlayerConstants.MAX_X) {
                    values.setX(currentX + PlayerConstants.MOVE_STEP);
                    action = "moved_right";
                    LOGGER.log(Level.FINE, "Player moved right: x={0}", values.getX());
                } else {
                    return createErrorResponse(Response.Status.BAD_REQUEST, 
                        "Cannot move right: already at maximum position");
                }
                
            } else {
                LOGGER.log(Level.WARNING, "Invalid key code received: {0}", key);
                return createErrorResponse(Response.Status.BAD_REQUEST, 
                    "Invalid key code: " + key + ". Valid keys are: " + 
                    PlayerConstants.KEY_RESET + " (reset), " + 
                    PlayerConstants.KEY_LEFT + " (left), " + 
                    PlayerConstants.KEY_RIGHT + " (right)");
            }
            
            // Return success response with updated position
            JsonObject response = Json.createObjectBuilder()
                .add("status", "success")
                .add("action", action)
                .add("position", Json.createObjectBuilder()
                    .add("x", values.getX())
                    .add("y", values.getY()))
                .build();
            
            return Response.status(Response.Status.OK)
                .entity(response)
                .build();
                
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error moving player", e);
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, 
                "An unexpected error occurred: " + e.getMessage());
        }
    }
    
    /**
     * Creates a JSON error response.
     * 
     * @param status The HTTP status code
     * @param message The error message
     * @return Response object with error details
     */
    private Response createErrorResponse(Response.Status status, String message) {
        JsonObject error = Json.createObjectBuilder()
            .add("status", "error")
            .add("message", message)
            .add("code", status.getStatusCode())
            .build();
        
        return Response.status(status)
            .entity(error)
            .build();
    }
    
    private PlayerValues getValues() {
        if (context != null) {
            if (context.getAttribute(PlayerValues.class.getSimpleName()) == null) {
                PlayerValues values = new PlayerValues();
                context.setAttribute(PlayerValues.class.getSimpleName(), values);
            }
            return (PlayerValues) context.getAttribute(PlayerValues.class.getSimpleName());
        }
        return null;
    }
    
    private void resetValues() {
        if (context != null) {
            PlayerValues values = new PlayerValues();
            context.setAttribute(PlayerValues.class.getSimpleName(), values);
        }
    }
}
```

---

## 4. Key Improvements Summary

### 4.1 Input Validation
✅ **Before:** No validation on coordinates or parameters  
✅ **After:** Comprehensive validation with specific error messages

- Coordinate bounds checking (0-19)
- Number format validation with try-catch
- Boolean string validation
- Null and empty string checks

### 4.2 Error Handling
✅ **Before:** Generic `Exception` throws, void methods  
✅ **After:** Proper HTTP responses with status codes

- 200 OK for successful operations
- 201 Created for bomb creation
- 400 Bad Request for invalid input
- 500 Internal Server Error for system issues
- JSON error responses with detailed messages

### 4.3 Constants & Configuration
✅ **Before:** Magic numbers scattered throughout code  
✅ **After:** Centralized constants in dedicated classes

- `BombConstants` for bomb-related values
- `PlayerConstants` for player-related values
- Clear, self-documenting constant names
- Easy to modify game parameters

### 4.4 Code Quality
✅ **Before:** Minimal documentation, inconsistent formatting  
✅ **After:** Professional-grade code with comprehensive documentation

- JavaDoc comments for all public methods
- Descriptive parameter and variable names
- Consistent code formatting
- Logging at appropriate levels (INFO, WARNING, SEVERE)

### 4.5 Performance & Security
✅ **Before:** Weak random number generation  
✅ **After:** Secure random ID generation

- `SecureRandom` instead of `Math.random()`
- Input sanitization (trim, lowercase for booleans)
- Validation before processing

### 4.6 Maintainability
✅ **Before:** Tightly coupled validation logic  
✅ **After:** Reusable validation methods

- `ValidationResult<T>` generic wrapper
- Separate validation methods
- DRY principle applied
- Easy to add new validations

---

## 5. Testing Recommendations

### 5.1 Unit Tests for Bombs.create()

```java
@Test
public void testCreateBomb_ValidInput() {
    Response response = bombs.create("10", "5", "true");
    assertEquals(201, response.getStatus());
}

@Test
public void testCreateBomb_InvalidX_TooLow() {
    Response response = bombs.create("-1", "5", "true");
    assertEquals(400, response.getStatus());
}

@Test
public void testCreateBomb_InvalidX_TooHigh() {
    Response response = bombs.create("20", "5", "true");
    assertEquals(400, response.getStatus());
}

@Test
public void testCreateBomb_InvalidX_NotNumber() {
    Response response = bombs.create("abc", "5", "true");
    assertEquals(400, response.getStatus());
}

@Test
public void testCreateBomb_InvalidBoolean() {
    Response response = bombs.create("10", "5", "maybe");
    assertEquals(400, response.getStatus());
}
```

### 5.2 Unit Tests for Player.move()

```java
@Test
public void testMove_Left_Success() {
    player.getValues().setX(10);
    Response response = player.move(111);
    assertEquals(200, response.getStatus());
    assertEquals(9, player.getValues().getX());
}

@Test
public void testMove_Left_AtBoundary() {
    player.getValues().setX(0);
    Response response = player.move(111);
    assertEquals(400, response.getStatus());
}

@Test
public void testMove_Right_Success() {
    player.getValues().setX(10);
    Response response = player.move(112);
    assertEquals(200, response.getStatus());
    assertEquals(11, player.getValues().getX());
}

@Test
public void testMove_InvalidKey() {
    Response response = player.move(999);
    assertEquals(400, response.getStatus());
}
```

---

## 6. Migration Guide

### Step 1: Create Constants Classes
1. Create `BombConstants.java` in bomb package
2. Create `PlayerConstants.java` in player package

### Step 2: Update Bombs.java
1. Add imports for logging and SecureRandom
2. Replace `create()` method with improved version
3. Add validation helper methods
4. Add `ValidationResult` inner class

### Step 3: Update Player.java
1. Add imports for logging
2. Replace `move()` method with improved version
3. Add error response helper method

### Step 4: Test Thoroughly
1. Run unit tests
2. Test API endpoints manually
3. Verify error responses
4. Check logs for proper output

### Step 5: Update Documentation
1. Update API documentation with new response formats
2. Document error codes and messages
3. Update client code to handle new responses

---

## 7. Additional Recommendations

### 7.1 Consider Adding
- Request rate limiting to prevent abuse
- Input sanitization for XSS prevention
- API versioning for future changes
- Metrics collection for monitoring
- Circuit breaker pattern for resilience

### 7.2 Future Enhancements
- Move validation to a separate validator class
- Create custom exception types
- Add request/response DTOs
- Implement caching for frequently accessed data
- Add integration tests

### 7.3 Configuration Management
- Externalize grid size to configuration file
- Make key codes configurable
- Add environment-specific settings
- Use dependency injection for better testability

---

## Conclusion

These improvements transform the code from a basic implementation to a production-ready, maintainable solution. The changes focus on:

1. **Robustness** - Comprehensive validation and error handling
2. **Maintainability** - Clear constants, documentation, and structure
3. **Observability** - Logging for debugging and monitoring
4. **Security** - Secure random generation and input validation
5. **User Experience** - Meaningful error messages and proper HTTP responses

The improved code follows Java best practices, RESTful API conventions, and enterprise-grade standards while maintaining backward compatibility with the existing game logic.