# MicroInvader - System Architecture Documentation

## Overview

MicroInvader is a microservices-based space invader game built with Java EE, JAX-RS, and AngularJS. The system follows a distributed architecture pattern where each game entity (player, enemies, bombs) is managed by an independent microservice.

---

## Architecture Diagram

### High-Level System Architecture

```mermaid
graph TB
    subgraph Client["Client Layer"]
        Browser[Web Browser]
        HTML[game.html]
        Angular[AngularJS Controller]
    end

    subgraph Gateway["Gateway Service"]
        Space[Space Service<br/>Port 9081<br/>/space-1.0]
    end

    subgraph GameServices["Game Entity Services"]
        Player[Player Service<br/>/player-1.0]
        Enemy[Enemy Service<br/>/enemy-1.0]
        Bomb[Bomb Service<br/>/bomb-1.0]
    end

    subgraph GameLogic["Game Logic Services"]
        Collision[Collision Service<br/>/collision-1.0]
    end

    subgraph Infrastructure["Infrastructure"]
        Liberty[IBM Liberty Server<br/>WebProfile 7]
        Maven[Maven Build System]
    end

    Browser --> HTML
    HTML --> Angular
    Angular -->|HTTP/REST| Space
    
    Space -->|Aggregate| Player
    Space -->|Aggregate| Enemy
    Space -->|Aggregate| Bomb
    Space -->|Coordinate| Collision
    
    Collision -->|Check| Player
    Collision -->|Check| Enemy
    Collision -->|Check| Bomb
    
    Player -.->|Deployed on| Liberty
    Enemy -.->|Deployed on| Liberty
    Bomb -.->|Deployed on| Liberty
    Collision -.->|Deployed on| Liberty
    Space -.->|Deployed on| Liberty
    
    Maven -.->|Build & Package| Liberty

    style Browser fill:#e1f5ff
    style Space fill:#fff4e1
    style Player fill:#e8f5e9
    style Enemy fill:#e8f5e9
    style Bomb fill:#e8f5e9
    style Collision fill:#f3e5f5
    style Liberty fill:#fce4ec
```

### Component Interaction Flow

```mermaid
sequenceDiagram
    participant Browser
    participant Angular
    participant Space
    participant Player
    participant Enemy
    participant Bomb
    participant Collision

    Note over Browser,Collision: Game Initialization
    Browser->>Angular: Load game.html
    Angular->>Space: GET /rest/position
    Space->>Player: GET /position
    Space->>Enemy: GET /position
    Space->>Bomb: GET /position
    Space-->>Angular: Aggregated positions JSON
    Angular->>Browser: Render 20x20 grid

    Note over Browser,Collision: Game Loop (every 400ms)
    Angular->>Space: GET /rest/run
    Space->>Player: GET /run
    Space->>Enemy: GET /run
    Space->>Bomb: GET /run
    Space->>Collision: GET /run
    
    Note over Collision: Detect collisions
    Collision->>Player: GET /position
    Collision->>Enemy: GET /position
    Collision->>Bomb: GET /position
    Collision->>Collision: Compare positions
    
    alt Collision Detected
        Collision->>Player: GET /destroy/{id}
        Collision->>Enemy: GET /destroy/{id}
        Collision->>Bomb: GET /destroy/{id}
    end
    
    Space-->>Angular: OK
    Angular->>Space: GET /rest/position
    Space-->>Angular: Updated positions
    Angular->>Browser: Update grid display

    Note over Browser,Collision: Player Input
    Browser->>Angular: Keypress event
    Angular->>Space: GET /rest/move/{key}
    Space->>Player: GET /move/{key}
    
    alt Space key pressed
        Angular->>Space: GET /rest/create/{x}/{y}/true
        Space->>Bomb: GET /create/{x}/{y}/true
    end
```

### Microservices Architecture Pattern

```mermaid
graph LR
    subgraph "Presentation Layer"
        UI[Web UI<br/>AngularJS]
    end

    subgraph "API Gateway Pattern"
        Gateway[Space Service<br/>Orchestrator]
    end

    subgraph "Service Layer"
        S1[Player<br/>Microservice]
        S2[Enemy<br/>Microservice]
        S3[Bomb<br/>Microservice]
        S4[Collision<br/>Microservice]
    end

    subgraph "Data Layer"
        D1[ServletContext<br/>Player State]
        D2[ServletContext<br/>Enemy State]
        D3[ServletContext<br/>Bomb State]
    end

    UI -->|REST API| Gateway
    Gateway -->|Orchestrate| S1
    Gateway -->|Orchestrate| S2
    Gateway -->|Orchestrate| S3
    Gateway -->|Orchestrate| S4
    
    S1 -.->|Store| D1
    S2 -.->|Store| D2
    S3 -.->|Store| D3
    
    S4 -->|Query| S1
    S4 -->|Query| S2
    S4 -->|Query| S3

    style UI fill:#e1f5ff
    style Gateway fill:#fff4e1
    style S1 fill:#e8f5e9
    style S2 fill:#e8f5e9
    style S3 fill:#e8f5e9
    style S4 fill:#f3e5f5
    style D1 fill:#fce4ec
    style D2 fill:#fce4ec
    style D3 fill:#fce4ec
```

### Deployment Architecture

```mermaid
graph TB
    subgraph "IBM Liberty Server - Port 9081"
        subgraph "WAR Deployments"
            W1[space-1.0.war]
            W2[player-1.0.war]
            W3[enemy-1.0.war]
            W4[bomb-1.0.war]
            W5[collision-1.0.war]
        end
        
        subgraph "Runtime Environment"
            JAX[JAX-RS 2.0<br/>REST Services]
            JSON[JSON-P 1.0<br/>JSON Processing]
            Servlet[Servlet 3.1]
        end
    end

    subgraph "Build Process"
        POM[Parent POM]
        M1[bomb/pom.xml]
        M2[enemy/pom.xml]
        M3[player/pom.xml]
        M4[collision/pom.xml]
        M5[space/pom.xml]
    end

    POM --> M1
    POM --> M2
    POM --> M3
    POM --> M4
    POM --> M5

    M1 -.->|Build| W4
    M2 -.->|Build| W3
    M3 -.->|Build| W2
    M4 -.->|Build| W5
    M5 -.->|Build| W1

    W1 --> JAX
    W2 --> JAX
    W3 --> JAX
    W4 --> JAX
    W5 --> JAX

    style W1 fill:#fff4e1
    style W2 fill:#e8f5e9
    style W3 fill:#e8f5e9
    style W4 fill:#e8f5e9
    style W5 fill:#f3e5f5
```

---

## System Components

### 1. Client Layer

#### Web Browser
- **Technology**: HTML5, AngularJS 1.x
- **File**: [`game.html`](space/src/main/webapp/game.html:1)
- **Controller**: [`controller.js`](space/src/main/webapp/scripts/controller.js:1)

**Responsibilities:**
- Render 20x20 game grid
- Handle keyboard input (o=left, p=right, 0=reset, space=fire)
- Poll game state every 400ms
- Display game entities (player, enemies, bombs)

**Key Features:**
- Real-time grid updates
- Image-based sprite rendering
- Event-driven input handling

---

### 2. Gateway Service

#### Space Service
- **Path**: `/space-1.0`
- **Port**: 9081
- **Implementation**: [`Space.java`](space/src/main/java/com/ibm/space/space/Space.java:1)

**Responsibilities:**
- API Gateway pattern implementation
- Aggregate data from all microservices
- Coordinate game loop execution
- Generate enemy bombs randomly
- CORS header management

**REST Endpoints:**
- `GET /rest/position` - Aggregate all entity positions
- `GET /rest/run` - Execute game loop across all services
- `GET /rest/move/{key}` - Forward player movement
- `GET /rest/create/{x}/{y}/{fromPlayer}` - Create bombs
- `GET /rest/isFinished` - Check game end condition

**Design Patterns:**
- API Gateway
- Service Orchestration
- Aggregator Pattern

---

### 3. Game Entity Services

#### Player Service
- **Path**: `/player-1.0`
- **Implementation**: [`Player.java`](player/src/main/java/com/ibm/space/player/Player.java:1)
- **State**: [`PlayerValues.java`](player/src/main/java/com/ibm/space/player/PlayerValues.java:1)

**Responsibilities:**
- Manage player position (x: 0-19, y: fixed at 19)
- Handle movement commands
- Track destruction state
- Serve player sprite image

**REST Endpoints:**
- `GET /position` - Return player position and state
- `GET /move/{key}` - Move player left/right or reset
- `GET /destroy` - Mark player as destroyed
- `GET /isFinished` - Return player destruction status
- `GET /image/{id}` - Serve player sprite

**State Management:**
- ServletContext-based state storage
- X coordinate: 0-19 (horizontal movement)
- Y coordinate: 19 (fixed at bottom)

---

#### Enemy Service
- **Path**: `/enemy-1.0`
- **Implementation**: [`Enemies.java`](enemy/src/main/java/com/ibm/space/enemies/Enemies.java:1)
- **Entity**: [`OneTie.java`](enemy/src/main/java/com/ibm/space/enemies/OneTie.java:1)

**Responsibilities:**
- Manage multiple enemy entities
- Move enemies in formation
- Track individual enemy states
- Serve enemy sprite images

**REST Endpoints:**
- `GET /position` - Return all enemy positions
- `GET /run` - Update enemy positions (move down and sideways)
- `GET /destroy/{id}` - Destroy specific enemy
- `GET /isFinished` - Check if all enemies destroyed
- `GET /image/{id}` - Serve enemy sprite

**Movement Logic:**
- Horizontal movement with direction changes
- Vertical descent
- Formation-based movement

---

#### Bomb Service
- **Path**: `/bomb-1.0`
- **Implementation**: [`Bombs.java`](bomb/src/main/java/com/ibm/space/bombs/Bombs.java:1)
- **Entity**: [`OneBomb.java`](bomb/src/main/java/com/ibm/space/bombs/OneBomb.java:1)

**Responsibilities:**
- Manage bomb entities (player and enemy bombs)
- Move bombs vertically
- Track bomb states
- Serve bomb sprite images

**REST Endpoints:**
- `GET /position` - Return all bomb positions
- `GET /run` - Update bomb positions (move up/down)
- `GET /create/{x}/{y}/{fromPlayer}` - Create new bomb
- `GET /destroy/{id}` - Destroy specific bomb
- `GET /image/{id}` - Serve bomb sprite

**Bomb Types:**
- Player bombs: move upward (fromPlayer=true)
- Enemy bombs: move downward (fromPlayer=false)

---

### 4. Game Logic Services

#### Collision Service
- **Path**: `/collision-1.0`
- **Implementation**: [`Collision.java`](collision/src/main/java/com/ibm/space/collision/Collision.java:1)

**Responsibilities:**
- Detect collisions between entities
- Coordinate destruction of colliding entities
- Stateless collision detection logic

**REST Endpoints:**
- `GET /run` - Execute collision detection algorithm
- `GET /position` - Return empty array (stateless)
- `GET /destroy/{id}` - No-op (stateless)

**Collision Detection Algorithm:**
1. Aggregate all entity positions from all services
2. Compare each entity pair for position overlap
3. If collision detected:
   - Mark both entities as destroyed
   - Call destroy endpoint on respective services
4. Handle multiple simultaneous collisions

**Design Patterns:**
- Stateless service
- Coordinator pattern
- Event-driven processing

---

## Communication Patterns

### 1. Request-Response Pattern
- **Protocol**: HTTP/REST
- **Format**: JSON
- **Client**: JAX-RS Client API
- **Synchronous**: All service calls are blocking

### 2. Polling Pattern
- **Interval**: 400ms
- **Client-side**: AngularJS $interval
- **Endpoints**: `/rest/position`, `/rest/isFinished`

### 3. Aggregation Pattern
- **Orchestrator**: Space Service
- **Aggregates**: Position data from all services
- **Response**: Combined JSON array

### 4. Broadcast Pattern
- **Orchestrator**: Space Service
- **Commands**: `/run`, `/move`, `/destroy`
- **Target**: All registered services

---

## Data Flow

### Game Loop Execution Flow

```mermaid
flowchart TD
    Start[Game Loop Start<br/>Every 400ms] --> CallRun[Angular calls<br/>Space /rest/run]
    CallRun --> SpaceRun[Space broadcasts<br/>run to all services]
    
    SpaceRun --> PlayerRun[Player /run<br/>No action]
    SpaceRun --> EnemyRun[Enemy /run<br/>Move enemies]
    SpaceRun --> BombRun[Bomb /run<br/>Move bombs]
    SpaceRun --> CollisionRun[Collision /run<br/>Detect collisions]
    
    CollisionRun --> GetPositions[Get all positions]
    GetPositions --> Compare[Compare positions]
    Compare --> Collide{Collision?}
    
    Collide -->|Yes| Destroy[Call destroy on<br/>colliding entities]
    Collide -->|No| Continue[Continue]
    
    Destroy --> Continue
    Continue --> EnemyBomb{Random<br/>enemy bomb?}
    
    EnemyBomb -->|Yes| CreateBomb[Create enemy bomb]
    EnemyBomb -->|No| GetPos[Get positions]
    CreateBomb --> GetPos
    
    GetPos --> Render[Render grid]
    Render --> CheckEnd{Game<br/>finished?}
    
    CheckEnd -->|No| Wait[Wait 400ms]
    CheckEnd -->|Yes| End[Game Over]
    Wait --> Start

    style Start fill:#e1f5ff
    style CallRun fill:#fff4e1
    style CollisionRun fill:#f3e5f5
    style Render fill:#e8f5e9
    style End fill:#ffebee
```

### Player Input Flow

```mermaid
flowchart LR
    Input[Keyboard Input] --> Angular[AngularJS<br/>keyPressed]
    Angular --> Check{Key Type?}
    
    Check -->|o/p/0| Move[Space /rest/move]
    Check -->|space| Bomb[Space /rest/create]
    
    Move --> PlayerMove[Player /move<br/>Update position]
    Bomb --> BombCreate[Bomb /create<br/>New bomb entity]
    
    PlayerMove --> Update[Update display]
    BombCreate --> Update

    style Input fill:#e1f5ff
    style Angular fill:#fff4e1
    style PlayerMove fill:#e8f5e9
    style BombCreate fill:#e8f5e9
```

---

## Technology Stack

### Backend
- **Runtime**: IBM Liberty Server (WebProfile 7)
- **Java Version**: 1.8
- **Framework**: JAX-RS 2.0 (RESTful Web Services)
- **JSON Processing**: JSON-P 1.0
- **Servlet**: 3.1
- **Build Tool**: Maven 3.x

### Frontend
- **Framework**: AngularJS 1.x
- **HTTP Client**: $http service
- **Rendering**: HTML5 + CSS
- **Images**: PNG sprites

### Infrastructure
- **Server**: IBM WebSphere Liberty
- **Port**: 9081 (HTTP)
- **Deployment**: WAR files in dropins directory
- **State Management**: ServletContext (in-memory)

---

## Design Patterns

### 1. Microservices Architecture
- **Independent Services**: Each game entity is a separate service
- **Loose Coupling**: Services communicate via REST APIs
- **Single Responsibility**: Each service manages one entity type

### 2. API Gateway Pattern
- **Gateway**: Space Service
- **Aggregation**: Combines data from multiple services
- **Routing**: Forwards requests to appropriate services

### 3. Stateless Services
- **Collision Service**: No state storage
- **Computation Only**: Pure collision detection logic

### 4. Stateful Services
- **Player, Enemy, Bomb**: Maintain state in ServletContext
- **Session Management**: Per-service state isolation

### 5. Polling Pattern
- **Client-side Polling**: Regular interval requests
- **Real-time Updates**: Simulated via frequent polling

---

## State Management

### ServletContext Storage
Each service maintains state in ServletContext:

```java
// Example from Player Service
context.setAttribute(PlayerValues.class.getSimpleName(), values);
PlayerValues values = (PlayerValues) context.getAttribute(PlayerValues.class.getSimpleName());
```

**Characteristics:**
- In-memory storage
- Per-service isolation
- No persistence
- Lost on server restart

### State Objects

#### PlayerValues
- `x`: 0-19 (horizontal position)
- `y`: 19 (fixed vertical position)
- `destroyed`: boolean flag
- `image`: byte array (sprite)

#### OneTie (Enemy)
- `id`: unique identifier
- `x`, `y`: position coordinates
- `destroyed`: boolean flag

#### OneBomb
- `id`: unique identifier
- `x`, `y`: position coordinates
- `fromPlayer`: boolean (direction)
- `destroyed`: boolean flag

---

## API Specifications

### Common Response Format

**Position Response:**
```json
[
  {
    "type": "player|enemy|bomb",
    "x": 0-19,
    "y": 0-19,
    "id": integer,
    "destroyed": boolean,
    "ip": "http://host:port"
  }
]
```

**Finished Response:**
```json
{
  "finished": boolean
}
```

### CORS Configuration
Space Service enables CORS:
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

---

## Build and Deployment

### Maven Multi-Module Structure
```
microinvader/
├── pom.xml (parent)
├── bomb/pom.xml
├── collision/pom.xml
├── enemy/pom.xml
├── player/pom.xml
└── space/pom.xml
```

### Build Process
1. **Compile**: Java 1.8 source/target
2. **Package**: WAR files for each module
3. **Install**: Liberty server installation
4. **Deploy**: Copy WARs to dropins directory
5. **Start**: Liberty server startup

### Maven Commands
```bash
mvn clean install          # Build all modules
mvn liberty:start-server   # Start Liberty server
mvn liberty:stop-server    # Stop Liberty server
```

---

## Game Mechanics

### Grid System
- **Size**: 20x20 cells
- **Cell Size**: 32x32 pixels
- **Coordinates**: (0,0) top-left, (19,19) bottom-right

### Entity Positions
- **Player**: Bottom row (y=19), moves horizontally
- **Enemies**: Top rows, move in formation
- **Bombs**: Move vertically (up for player, down for enemies)

### Game Rules
1. Player can move left (o) or right (p)
2. Player fires bombs upward (space key)
3. Enemies move in formation and fire bombs downward
4. Collision destroys both entities
5. Game ends when player is destroyed or all enemies eliminated

### Key Bindings
- `o` (111): Move left
- `p` (112): Move right
- `0` (48): Reset game
- `space` (32): Fire bomb

---

## Performance Considerations

### Polling Overhead
- **Frequency**: 400ms interval
- **Requests per cycle**: 2-3 (run, position, isFinished)
- **Network calls**: Multiple service-to-service calls

### Optimization Opportunities
1. **Caching**: Cache position data between cycles
2. **Batch Operations**: Combine multiple REST calls
3. **WebSockets**: Replace polling with push notifications
4. **Connection Pooling**: Reuse HTTP connections
5. **Async Processing**: Non-blocking service calls

---

## Security Considerations

### Current State
- No authentication/authorization
- Open CORS policy
- No input validation (see improvement plan)
- No rate limiting

### Recommended Improvements
1. Add input validation (see [`CODE_IMPROVEMENTS_DETAILED.md`](CODE_IMPROVEMENTS_DETAILED.md:1))
2. Implement authentication
3. Restrict CORS origins
4. Add rate limiting
5. Sanitize user inputs

---

## Scalability Analysis

### Current Limitations
- **Single Server**: All services on one Liberty instance
- **In-Memory State**: No persistence or replication
- **Synchronous Calls**: Blocking service communication
- **No Load Balancing**: Single point of failure

### Scaling Strategies
1. **Horizontal Scaling**: Deploy services on separate servers
2. **Service Discovery**: Implement dynamic service registration
3. **Load Balancing**: Distribute requests across instances
4. **State Externalization**: Use Redis or database for state
5. **Async Messaging**: Replace REST with message queues

---

## Monitoring and Observability

### Current Logging
- Java Util Logging (JUL)
- Log levels: INFO, WARNING, SEVERE, FINE
- Service-specific loggers

### Recommended Additions
1. **Metrics**: Response times, error rates
2. **Tracing**: Distributed request tracing
3. **Health Checks**: Service availability endpoints
4. **Dashboards**: Real-time monitoring UI

---

## Future Enhancements

### Architecture Improvements
1. **Service Mesh**: Istio or Linkerd for service communication
2. **API Gateway**: Kong or Apigee for advanced routing
3. **Event Sourcing**: Track game state changes
4. **CQRS**: Separate read/write models

### Feature Additions
1. **Multiplayer**: Multiple players in same game
2. **Leaderboard**: Score tracking and persistence
3. **Power-ups**: Special abilities and items
4. **Levels**: Progressive difficulty

### Technology Upgrades
1. **Java 17+**: Modern Java features
2. **Spring Boot**: Simplified configuration
3. **React/Vue**: Modern frontend framework
4. **WebSockets**: Real-time communication
5. **Docker/Kubernetes**: Container orchestration

---

## Conclusion

MicroInvader demonstrates a clean microservices architecture with clear separation of concerns. Each service is independently deployable and maintainable. The API Gateway pattern provides a unified interface for the client, while the collision service implements stateless game logic.

The architecture is well-suited for learning microservices concepts but would benefit from the improvements outlined in the security, scalability, and monitoring sections for production use.

---

## Related Documentation

- [`CODE_IMPROVEMENT_PLAN.md`](CODE_IMPROVEMENT_PLAN.md:1) - Code quality improvements
- [`CODE_IMPROVEMENTS_DETAILED.md`](CODE_IMPROVEMENTS_DETAILED.md:1) - Detailed improvement implementations
- [`README.TXT`](README.TXT:1) - Project overview