package com.ibm.space.bombs;

import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.json.Json;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

@Path("/")
public class Bombs {
	
	private static final Logger LOGGER = Logger.getLogger(Bombs.class.getName());
	private static final int GRID_SIZE = 20;
	private static final int KEY_RESET = 48; // '0' key
	
	@Context
	private ServletContext context;
		
		@GET
		@Path("/position")
		@Produces("application/json")
		public Response position(@Context HttpServletRequest request) {
			try {
				JsonArrayBuilder arr = Json.createArrayBuilder();
				BombsValues values = getValues();
				
				if (values != null) {
					for (OneBomb bomb : values.getBombs()) {
						JsonObject obj = Json.createObjectBuilder()
							.add("type", "bomb")
							.add("x", bomb.getX())
							.add("y", bomb.getY())
							.add("up", bomb.isFromPlayer())
							.add("id", bomb.getId())
							.add("destroyed", bomb.isDestroyed())
							.add("ip", "http://" + request.getLocalAddr() + ":" + request.getLocalPort())
							.build();
						arr.add(obj);
					}
				}
				return Response.ok(arr.build()).build();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Error getting bomb positions", e);
				return Response.serverError()
					.entity(Json.createObjectBuilder()
						.add("error", "Failed to retrieve positions")
						.build())
					.build();
			}
		}
 
		@GET
		@Path("/run")
		public Response run() {
			try {
				BombsValues values = getValues();
				if (values == null || values.isHasFinished()) {
					return Response.ok().build();
				}
				
				for (OneBomb bomb : values.getBombs()) {
					if (bomb.isDestroyed()) {
						continue; // Skip destroyed bombs
					}
					
					if (bomb.isFromPlayer()) {
						// Player bomb moves up
						if (bomb.getY() <= 0) {
							bomb.setDestroyed(true);
						} else {
							bomb.setY(bomb.getY() - 1);
						}
					} else {
						// Enemy bomb moves down
						if (bomb.getY() >= GRID_SIZE) {
							bomb.setDestroyed(true);
						} else {
							bomb.setY(bomb.getY() + 1);
						}
					}
				}
				return Response.ok().build();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Error updating bomb positions", e);
				return Response.serverError().build();
			}
		}
		
		@GET
		@Path("/destroy/{id}")
		public Response destroy(@PathParam("id") long id) {
			try {
				BombsValues values = getValues();
				if (values != null) {
					for (OneBomb bomb : values.getBombs()) {
						if (bomb.getId() == id) {
							bomb.setDestroyed(true);
							LOGGER.log(Level.FINE, "Bomb destroyed: {0}", id);
							return Response.ok().build();
						}
					}
				}
				return Response.status(Response.Status.NOT_FOUND).build();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Error destroying bomb: " + id, e);
				return Response.serverError().build();
			}
		}
		
		   @GET
		@Path("/move/{key}")
		public Response move(@PathParam("key") int key) {
			try {
				if (key == KEY_RESET) {
					resetValues();
					LOGGER.info("Bomb values reset");
				}
				return Response.ok().build();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Error processing move", e);
				return Response.serverError().build();
			}
		   }

		@GET
		@Path("/isFinished")
		   @Produces("application/json")
		   public Response hasEnded() {
		   	return Response.ok(
				Json.createObjectBuilder()
					.add("finished", false)
					.build()
			).build();
		   }
		   
		@GET
		@Path("/create/{x}/{y}/{fromPlayer}")
		public Response create(@PathParam("x") String x, @PathParam("y") String y, @PathParam("fromPlayer") String fromPlayerStr) {
			try {
				// Input validation
				int valueX = Integer.parseInt(x);
				int valueY = Integer.parseInt(y);
				boolean fromPlayer = Boolean.parseBoolean(fromPlayerStr);
				
				if (valueX < 0 || valueX >= GRID_SIZE || valueY < 0 || valueY >= GRID_SIZE) {
					LOGGER.log(Level.WARNING, "Invalid bomb coordinates: ({0},{1})", new Object[]{valueX, valueY});
					return Response.status(Response.Status.BAD_REQUEST)
						.entity(Json.createObjectBuilder()
							.add("error", "Invalid coordinates")
							.build())
						.build();
				}
				
				OneBomb bomb = new OneBomb(
					(int)(ThreadLocalRandom.current().nextDouble() * Integer.MAX_VALUE),
					valueX, valueY, fromPlayer
				);
				
				BombsValues values = getValues();
				if (values != null) {
					values.getBombs().add(bomb);
					LOGGER.log(Level.FINE, "Bomb created at ({0},{1})", new Object[]{valueX, valueY});
				}
				
				return Response.ok().build();
			} catch (NumberFormatException e) {
				LOGGER.log(Level.WARNING, "Invalid number format in create bomb request", e);
				return Response.status(Response.Status.BAD_REQUEST)
					.entity(Json.createObjectBuilder()
						.add("error", "Invalid number format")
						.build())
					.build();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Error creating bomb", e);
				return Response.serverError().build();
			}
		}
	    
		private BombsValues getValues()
		{
			if (context != null) {
				if (context.getAttribute(BombsValues.class.getSimpleName()) == null) {
					BombsValues values = new BombsValues();
					context.setAttribute(BombsValues.class.getSimpleName(), values);			
				}
				return (BombsValues) context.getAttribute(BombsValues.class.getSimpleName());
			}
			else {
				return null;
			}
		}
		
		private void resetValues()
		{
			BombsValues values = new BombsValues();
			context.setAttribute(BombsValues.class.getSimpleName(), values);
		}
}
