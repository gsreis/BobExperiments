#!/bin/bash

# MicroInvader OpenShift Deployment Script
# This script deploys the MicroInvader application to OpenShift

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="${OPENSHIFT_PROJECT:-microinvader}"
GIT_REPO="${GIT_REPOSITORY_URL:-https://github.com/YOUR_USERNAME/microinvader.git}"
GIT_BRANCH="${GIT_BRANCH:-main}"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}MicroInvader OpenShift Deployment${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if oc is installed
if ! command -v oc &> /dev/null; then
    echo -e "${RED}Error: OpenShift CLI (oc) is not installed${NC}"
    echo "Please install it from: https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html"
    exit 1
fi

# Check if logged in to OpenShift
if ! oc whoami &> /dev/null; then
    echo -e "${RED}Error: Not logged in to OpenShift${NC}"
    echo "Please login using: oc login <your-openshift-cluster-url>"
    exit 1
fi

echo -e "${YELLOW}Current OpenShift user:${NC} $(oc whoami)"
echo -e "${YELLOW}Current OpenShift server:${NC} $(oc whoami --show-server)"
echo ""

# Create or switch to project
echo -e "${YELLOW}Creating/switching to project: ${PROJECT_NAME}${NC}"
if oc get project ${PROJECT_NAME} &> /dev/null; then
    echo "Project ${PROJECT_NAME} already exists, switching to it..."
    oc project ${PROJECT_NAME}
else
    echo "Creating new project ${PROJECT_NAME}..."
    oc new-project ${PROJECT_NAME} --display-name="MicroInvader Game" --description="A microservices-based space invader game"
fi
echo ""

# Deploy using template
echo -e "${YELLOW}Deploying MicroInvader using template...${NC}"
oc process -f microinvader-template.yaml \
    -p GIT_REPOSITORY_URL="${GIT_REPO}" \
    -p GIT_BRANCH="${GIT_BRANCH}" \
    -p REPLICAS=1 \
    -p MEMORY_REQUEST=512Mi \
    -p MEMORY_LIMIT=1Gi \
    -p CPU_REQUEST=250m \
    -p CPU_LIMIT=1000m \
    -p LOG_LEVEL=info \
    | oc apply -f -
echo ""

# Wait for build to complete
echo -e "${YELLOW}Waiting for build to complete...${NC}"
echo "This may take several minutes as Maven downloads dependencies and builds the application..."
oc logs -f bc/microinvader || true
echo ""

# Wait for deployment to be ready
echo -e "${YELLOW}Waiting for deployment to be ready...${NC}"
oc rollout status deployment/microinvader --timeout=10m
echo ""

# Get the route URL
ROUTE_URL=$(oc get route microinvader -o jsonpath='{.spec.host}')
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Deployment Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Application URL:${NC} https://${ROUTE_URL}/space-1.0/game.html"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo "  View pods:        oc get pods"
echo "  View logs:        oc logs -f deployment/microinvader"
echo "  View route:       oc get route microinvader"
echo "  Scale app:        oc scale deployment/microinvader --replicas=2"
echo "  Delete app:       oc delete all -l app=microinvader"
echo ""

# Made with Bob
