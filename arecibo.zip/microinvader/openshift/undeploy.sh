#!/bin/bash

# MicroInvader OpenShift Undeployment Script
# This script removes the MicroInvader application from OpenShift

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="${OPENSHIFT_PROJECT:-microinvader}"

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}MicroInvader OpenShift Undeployment${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# Check if oc is installed
if ! command -v oc &> /dev/null; then
    echo -e "${RED}Error: OpenShift CLI (oc) is not installed${NC}"
    exit 1
fi

# Check if logged in to OpenShift
if ! oc whoami &> /dev/null; then
    echo -e "${RED}Error: Not logged in to OpenShift${NC}"
    exit 1
fi

# Check if project exists
if ! oc get project ${PROJECT_NAME} &> /dev/null; then
    echo -e "${RED}Error: Project ${PROJECT_NAME} does not exist${NC}"
    exit 1
fi

# Switch to project
oc project ${PROJECT_NAME}

echo -e "${YELLOW}Deleting all MicroInvader resources...${NC}"
oc delete all,configmap,route,imagestream,buildconfig -l app=microinvader

echo ""
echo -e "${GREEN}MicroInvader application has been removed from OpenShift${NC}"
echo ""
echo -e "${YELLOW}To delete the entire project, run:${NC}"
echo "  oc delete project ${PROJECT_NAME}"
echo ""

# Made with Bob
