# MicroInvader OpenShift - Quick Start Guide

Get your MicroInvader game running on OpenShift in minutes!

## Prerequisites Checklist

- [ ] OpenShift cluster access (v4.x+)
- [ ] OpenShift CLI (`oc`) installed
- [ ] Git repository with your code
- [ ] Logged into OpenShift cluster

## 5-Minute Deployment

### Step 1: Login to OpenShift (30 seconds)

```bash
oc login https://your-openshift-cluster.com
```

Enter your credentials when prompted.

### Step 2: Clone and Navigate (30 seconds)

```bash
git clone https://github.com/YOUR_USERNAME/microinvader.git
cd microinvader/openshift
```

### Step 3: Deploy (3-4 minutes)

```bash
./deploy.sh
```

The script will:
- ✅ Create the project
- ✅ Build the container image
- ✅ Deploy all resources
- ✅ Display the game URL

### Step 4: Play! (immediately)

Open the URL displayed by the script:
```
https://microinvader-microinvader.apps.your-cluster.com/space-1.0/game.html
```

## That's It! 🎮

Your game is now running on OpenShift with:
- ✅ Automatic health checks
- ✅ TLS encryption
- ✅ Scalability
- ✅ Production-ready configuration

## Common Commands

### View Status
```bash
oc get pods
oc get route microinvader
```

### View Logs
```bash
oc logs -f deployment/microinvader
```

### Scale Up
```bash
oc scale deployment/microinvader --replicas=3
```

### Rebuild
```bash
oc start-build microinvader --follow
```

### Remove
```bash
./undeploy.sh
```

## Troubleshooting

### Build Failed?
```bash
oc logs -f bc/microinvader
oc start-build microinvader
```

### Can't Access Game?
```bash
oc get route microinvader
oc describe route microinvader
```

### Pod Not Starting?
```bash
oc get pods
oc describe pod <pod-name>
oc logs <pod-name>
```

## Next Steps

- 📖 Read the [detailed guide](README.md)
- 🔧 Customize [configuration](configmaps/microinvader-config.yaml)
- 📊 Set up monitoring
- 🚀 Configure CI/CD

## Need Help?

- **Detailed Documentation**: [README.md](README.md)
- **Main Project Docs**: [../OPENSHIFT_DEPLOYMENT.md](../OPENSHIFT_DEPLOYMENT.md)
- **OpenShift Docs**: https://docs.openshift.com

## Manual Deployment (Alternative)

If you prefer manual steps:

```bash
# 1. Create project
oc new-project microinvader

# 2. Deploy using template
oc process -f microinvader-template.yaml \
  -p GIT_REPOSITORY_URL=https://github.com/YOUR_USERNAME/microinvader.git \
  | oc apply -f -

# 3. Wait for build
oc logs -f bc/microinvader

# 4. Get URL
oc get route microinvader
```

## Deployment Verification

After deployment, verify everything is working:

```bash
# Check pods are running
oc get pods -l app=microinvader

# Check health endpoint
ROUTE=$(oc get route microinvader -o jsonpath='{.spec.host}')
curl -k https://$ROUTE/health

# Expected output:
# {"status":"UP","checks":[...]}
```

## Resource Usage

Default configuration:
- **Memory**: 512Mi request, 1Gi limit
- **CPU**: 250m request, 1000m limit
- **Replicas**: 1 (can scale to 5)

## Security Notes

The deployment includes:
- 🔒 TLS encryption (automatic)
- 🔒 Non-root container
- 🔒 Dropped capabilities
- 🔒 Seccomp profile

## Performance Tips

For better performance:
1. Increase replicas: `oc scale deployment/microinvader --replicas=2`
2. Increase resources in [deployment.yaml](deployments/microinvader-deployment.yaml)
3. Enable HPA: `oc autoscale deployment/microinvader --min=1 --max=5 --cpu-percent=80`

---

**Ready to play?** Run `./deploy.sh` and start gaming! 🎮