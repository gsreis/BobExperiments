# MicroInvader - OpenShift Deployment Guide

This guide explains how to deploy the MicroInvader game application to OpenShift.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Deployment Options](#deployment-options)
- [Configuration](#configuration)
- [Accessing the Application](#accessing-the-application)
- [Monitoring and Troubleshooting](#monitoring-and-troubleshooting)
- [Scaling](#scaling)
- [Undeployment](#undeployment)

## Prerequisites

1. **OpenShift Cluster Access**: You need access to an OpenShift cluster (v4.x or later)
2. **OpenShift CLI (oc)**: Install from [OpenShift CLI Downloads](https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html)
3. **Git Repository**: Your code should be in a Git repository accessible by OpenShift

## Quick Start

### 1. Login to OpenShift

```bash
oc login <your-openshift-cluster-url>
```

### 2. Deploy Using the Automated Script

```bash
cd openshift
./deploy.sh
```

The script will:
- Create a new project (or use existing)
- Deploy all resources using the template
- Start the build process
- Wait for deployment to complete
- Display the application URL

### 3. Access the Game

Once deployed, access the game at:
```
https://<route-url>/space-1.0/game.html
```

The deployment script will display the exact URL.

## Deployment Options

### Option 1: Using the Template (Recommended)

Deploy using the OpenShift template with custom parameters:

```bash
oc new-project microinvader

oc process -f microinvader-template.yaml \
  -p GIT_REPOSITORY_URL=https://github.com/YOUR_USERNAME/microinvader.git \
  -p GIT_BRANCH=main \
  -p REPLICAS=1 \
  -p MEMORY_REQUEST=512Mi \
  -p MEMORY_LIMIT=1Gi \
  -p CPU_REQUEST=250m \
  -p CPU_LIMIT=1000m \
  -p LOG_LEVEL=info \
  | oc apply -f -
```

### Option 2: Using Individual YAML Files

Deploy resources individually:

```bash
oc new-project microinvader

# Create ImageStream
oc apply -f buildconfigs/microinvader-imagestream.yaml

# Create BuildConfig
oc apply -f buildconfigs/microinvader-buildconfig.yaml

# Create ConfigMap
oc apply -f configmaps/microinvader-config.yaml

# Create Deployment
oc apply -f deployments/microinvader-deployment.yaml

# Create Service
oc apply -f services/microinvader-service.yaml

# Create Route
oc apply -f routes/microinvader-route.yaml
```

### Option 3: Using OpenShift Web Console

1. Login to OpenShift Web Console
2. Click **+Add** → **Import from Git**
3. Enter your Git repository URL
4. Select **Dockerfile** as the import strategy
5. Configure resources and create

## Configuration

### Environment Variables

The application can be configured using the ConfigMap (`microinvader-config`):

| Variable | Description | Default |
|----------|-------------|---------|
| `HTTP_PORT` | HTTP port for Liberty | `9080` |
| `HTTPS_PORT` | HTTPS port for Liberty | `9443` |
| `WLP_LOGGING_CONSOLE_FORMAT` | Log format (json/simple) | `json` |
| `WLP_LOGGING_CONSOLE_LOGLEVEL` | Log level | `info` |
| `JAVA_OPTS` | JVM options | `-Xmx512m -Xms256m` |

### Modifying Configuration

Edit the ConfigMap:

```bash
oc edit configmap microinvader-config
```

Then restart the pods:

```bash
oc rollout restart deployment/microinvader
```

## Accessing the Application

### Get the Route URL

```bash
oc get route microinvader
```

### Access Endpoints

- **Game**: `https://<route-url>/space-1.0/game.html`
- **Health Check**: `https://<route-url>/health`
- **Liveness**: `https://<route-url>/health/live`
- **Readiness**: `https://<route-url>/health/ready`
- **Metrics**: `https://<route-url>/metrics`

## Monitoring and Troubleshooting

### View Pods

```bash
oc get pods
```

### View Logs

```bash
# Follow logs
oc logs -f deployment/microinvader

# View specific pod logs
oc logs <pod-name>

# View build logs
oc logs -f bc/microinvader
```

### Check Deployment Status

```bash
oc rollout status deployment/microinvader
```

### Describe Resources

```bash
oc describe deployment microinvader
oc describe pod <pod-name>
oc describe route microinvader
```

### Common Issues

#### Build Fails

Check build logs:
```bash
oc logs -f bc/microinvader
```

Restart build:
```bash
oc start-build microinvader
```

#### Pods Not Starting

Check pod events:
```bash
oc describe pod <pod-name>
```

Check resource limits:
```bash
oc get resourcequota
oc get limitrange
```

#### Application Not Accessible

Check route:
```bash
oc get route microinvader
oc describe route microinvader
```

Check service:
```bash
oc get svc microinvader
oc describe svc microinvader
```

## Scaling

### Manual Scaling

Scale up:
```bash
oc scale deployment/microinvader --replicas=3
```

Scale down:
```bash
oc scale deployment/microinvader --replicas=1
```

### Horizontal Pod Autoscaler (HPA)

Create an HPA:
```bash
oc autoscale deployment/microinvader \
  --min=1 \
  --max=5 \
  --cpu-percent=80
```

View HPA status:
```bash
oc get hpa
```

## Resource Management

### Update Resource Limits

Edit the deployment:
```bash
oc edit deployment microinvader
```

Or patch it:
```bash
oc patch deployment microinvader -p '
{
  "spec": {
    "template": {
      "spec": {
        "containers": [{
          "name": "microinvader",
          "resources": {
            "requests": {
              "memory": "768Mi",
              "cpu": "500m"
            },
            "limits": {
              "memory": "1.5Gi",
              "cpu": "1500m"
            }
          }
        }]
      }
    }
  }
}'
```

## Undeployment

### Using the Script

```bash
cd openshift
./undeploy.sh
```

### Manual Cleanup

Delete all resources:
```bash
oc delete all,configmap,route,imagestream,buildconfig -l app=microinvader
```

Delete the project:
```bash
oc delete project microinvader
```

## Advanced Topics

### Using a Private Git Repository

Create a secret with Git credentials:
```bash
oc create secret generic git-credentials \
  --from-literal=username=<your-username> \
  --from-literal=password=<your-token>
```

Update BuildConfig to use the secret:
```bash
oc set build-secret --source bc/microinvader git-credentials
```

### Using a Private Container Registry

Create a pull secret:
```bash
oc create secret docker-registry registry-credentials \
  --docker-server=<registry-url> \
  --docker-username=<username> \
  --docker-password=<password> \
  --docker-email=<email>
```

Link the secret to the service account:
```bash
oc secrets link default registry-credentials --for=pull
```

### Persistent Storage

If you need persistent storage (not required for this application):
```bash
oc set volume deployment/microinvader \
  --add \
  --name=data \
  --type=persistentVolumeClaim \
  --claim-name=microinvader-data \
  --mount-path=/data
```

## Architecture

The MicroInvader application consists of 5 microservices running in a single Liberty server:

- **space**: Main game interface and coordination
- **player**: Player ship management
- **enemy**: Enemy ship management
- **bomb**: Bomb/projectile management
- **collision**: Collision detection service

All services are packaged as WAR files and deployed to a single Open Liberty instance.

## Health Checks

The application includes three types of health checks:

1. **Startup Probe**: Checks if the application has started (30 attempts, 5s interval)
2. **Liveness Probe**: Checks if the application is alive (every 10s)
3. **Readiness Probe**: Checks if the application is ready to serve traffic (every 5s)

## Security

The deployment includes several security best practices:

- Runs as non-root user
- Drops all capabilities
- Uses seccomp profile
- TLS termination at the route level
- No privilege escalation

## Support

For issues and questions:
- GitHub Issues: https://github.com/YOUR_USERNAME/microinvader/issues
- Documentation: See main README.md

## License

See the main project LICENSE file.