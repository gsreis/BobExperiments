# Code Improvement Plan for MicroInvader

## Executive Summary

This document outlines comprehensive improvements for the MicroInvader game - a microservices-based Space Invaders implementation using Java, JAX-RS, and AngularJS. The analysis identified critical issues across security, code quality, architecture, and maintainability.

---

## 1. Critical Security Issues

### 1.1 Outdated Dependencies (HIGH PRIORITY)
**Current State:**
- Java 8 (EOL for public updates)
- Apache CXF 3.1.1 (2015, multiple CVEs)
- AngularJS 1.x (EOL, security vulnerabilities)
- Liberty WebProfile 7 (outdated)

**Recommendations:**
- Upgrade to Java 17 LTS or Java 21 LTS
- Update Apache CXF to 3.6.x or 4.x
- Migrate from AngularJS to modern framework (React, Vue, or Angular 17+)
- Update Liberty to latest version with Jakarta EE 10

### 1.2 Missing Input Validation
**Issues:**
- [`Bombs.java:97-103`](bomb/src/main/java/com/ibm/space/bombs/Bombs.java:97) - No validation on x, y coordinates
- [`Player.java:56-62`](player/src/main/java/com/ibm/space/player/Player.java:56) - No bounds checking before parsing
- [`Collision.java:68`](collision/src/main/java/com/ibm/space/collision/Collision.java:68) - No validation on destroy operations

**Recommendations:**
```java
// Add validation annotations
@PathParam("x") @Min(0) @Max(19) int x
// Or manual validation
if (x < 0 || x > 19 || y < 0 || y > 19) {
    throw new IllegalArgumentException("Invalid coordinates");
}
```

### 1.3 CORS Configuration
**Issue:** Hardcoded wildcard CORS in [`Space.java:41-43`](space/src/main/java/com/ibm/space/space/Space.java:41)

**Recommendation:**
- Configure CORS properly in server.xml
- Restrict origins to specific domains
- Remove inline CORS headers

---

## 2. Code Quality & Best Practices

### 2.1 Exception Handling (CRITICAL)

**Issues:**
- [`Space.java:119`](space/src/main/java/com/ibm/space/space/Space.java:119) - Empty catch block swallows exceptions
- [`Collision.java:109-112`](collision/src/main/java/com/ibm/space/collision/Collision.java:109) - No error handling
- No logging throughout the application

**Recommendations:**
```java
// Add proper logging
private static final Logger logger = Logger.getLogger(Space.class.getName());

private String callRest(String urlin) {
    try {
        Client client = ClientBuilder.newClient();
        return client.target(urlin).request(MediaType.APPLICATION_JSON).get(String.class);
    } catch (Exception e) {
        logger.log(Level.SEVERE, "Failed to call REST endpoint: " + urlin, e);
        throw new ServiceException("Service unavailable", e);
    }
}
```

### 2.2 Resource Management

**Issues:**
- [`Space.java:117`](space/src/main/java/com/ibm/space/space/Space.java:117) - JAX-RS Client never closed (resource leak)
- [`Collision.java:110`](collision/src/main/java/com/ibm/space/collision/Collision.java:110) - Same issue

**Recommendations:**
```java
// Use try-with-resources
private String callRest(String urlin) {
    try (Client client = ClientBuilder.newClient()) {
        return client.target(urlin)
            .request(MediaType.APPLICATION_JSON)
            .get(String.class);
    }
}

// Or use a singleton client with connection pooling
private static final Client CLIENT = ClientBuilder.newBuilder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build();
```

### 2.3 Deprecated Collections

**Issue:** [`BombsValues.java:10`](bomb/src/main/java/com/ibm/space/bombs/BombsValues.java:10) uses `Vector` (thread-safe but outdated)

**Recommendation:**
```java
// Replace with modern alternatives
private List<OneBomb> bombs = new ArrayList<>(); // If single-threaded
// OR
private List<OneBomb> bombs = new CopyOnWriteArrayList<>(); // If concurrent access needed
```

### 2.4 Magic Numbers

**Issues:**
- Hardcoded values throughout: 20, 19, 40, 30, etc.
- [`controller.js:6`](space/src/main/webapp/scripts/controller.js:6) - 400ms interval
- [`Space.java:70`](space/src/main/java/com/ibm/space/space/Space.java:70) - 30% bomb chance

**Recommendations:**
```java
// Create constants class
public class GameConstants {
    public static final int GRID_SIZE = 20;
    public static final int PLAYER_Y_POSITION = 19;
    public static final int ENEMY_COUNT = 40;
    public static final int BOMB_SPAWN_CHANCE = 30;
    public static final int GAME_TICK_MS = 400;
}
```

---

## 3. Architecture & Design Issues

### 3.1 Hardcoded Service URLs

**Issue:** URLs hardcoded in [`Space.java:24-27`](space/src/main/java/com/ibm/space/space/Space.java:24) and [`Collision.java:21-24`](collision/src/main/java/com/ibm/space/collision/Collision.java:21)

**Recommendations:**
```java
// Use service discovery or configuration
@Inject
@ConfigProperty(name = "enemy.service.url")
private String enemyServiceUrl;

// Or implement service registry pattern
public interface ServiceRegistry {
    String getServiceUrl(String serviceName);
}
```

### 3.2 Inconsistent State Management

**Issue:** Using ServletContext for state storage is not scalable or cloud-native

**Recommendations:**
- Implement proper session management
- Use Redis or similar for distributed state
- Consider event-driven architecture with message queues

### 3.3 Synchronous REST Calls

**Issue:** All microservice calls are synchronous, blocking threads

**Recommendations:**
```java
// Use CompletableFuture for async calls
CompletableFuture<String> enemyData = CompletableFuture.supplyAsync(() -> 
    callRest(urls[0] + "position")
);

// Or use reactive programming with MicroProfile Reactive Messaging
@Incoming("game-events")
public void processGameEvent(GameEvent event) {
    // Process asynchronously
}
```

### 3.4 Missing API Versioning

**Issue:** No versioning strategy for REST APIs

**Recommendation:**
```java
@Path("/api/v1/position")  // Add version to path
// Or use header-based versioning
```

---

## 4. Maven Configuration Issues

### 4.1 Duplicate Plugin Declarations

**Issue:** [`maven-compiler-plugin`](pom.xml:36) declared multiple times in each POM

**Recommendation:**
```xml
<!-- In parent pom.xml -->
<build>
    <pluginManagement>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <release>17</release>
                </configuration>
            </plugin>
        </plugins>
    </pluginManagement>
</build>
```

### 4.2 Missing Dependency Management

**Recommendation:**
```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>jakarta.platform</groupId>
            <artifactId>jakarta.jakartaee-bom</artifactId>
            <version>10.0.0</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>
```

---

## 5. Frontend Issues

### 5.1 AngularJS EOL

**Issue:** AngularJS 1.x reached end-of-life in 2022

**Recommendations:**
- Migrate to modern framework (React, Vue 3, or Angular 17+)
- Or use vanilla JavaScript with Web Components
- Implement proper build pipeline (Webpack, Vite)

### 5.2 Hardcoded URLs

**Issue:** [`controller.js:12`](space/src/main/webapp/scripts/controller.js:12) hardcodes localhost

**Recommendation:**
```javascript
// Use environment configuration
const API_BASE_URL = window.ENV?.API_URL || 'http://127.0.0.1:9081/space-1.0';
```

### 5.3 Alert Dialog

**Issue:** [`controller.js:31`](space/src/main/webapp/scripts/controller.js:31) uses blocking `alert()`

**Recommendation:**
```javascript
// Use modal dialog or toast notification
$scope.showWelcomeModal = true;
```

---

## 6. Testing & Quality Assurance

### 6.1 Missing Tests

**Issue:** No unit tests, integration tests, or test dependencies

**Recommendations:**
```xml
<dependencies>
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.10.1</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <version>5.8.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

### 6.2 Code Coverage

**Recommendation:**
```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.11</version>
</plugin>
```

---

## 7. Documentation Issues

### 7.1 Missing Documentation

**Issues:**
- No API documentation (Swagger/OpenAPI)
- Minimal code comments
- Poor README

**Recommendations:**
```java
// Add OpenAPI annotations
@OpenAPIDefinition(
    info = @Info(
        title = "MicroInvader API",
        version = "1.0",
        description = "Space Invaders Microservices Game"
    )
)

@Operation(summary = "Get all bomb positions")
@APIResponse(responseCode = "200", description = "Success")
@GET
@Path("/position")
public Response position() { ... }
```

---

## 8. Performance Optimizations

### 8.1 Caching

**Recommendation:**
```java
// Add caching for frequently accessed data
@CacheResult(cacheName = "positions")
public Response position() { ... }
```

### 8.2 Connection Pooling

**Recommendation:**
```java
// Configure connection pool for JAX-RS client
ClientBuilder.newBuilder()
    .property("jersey.config.client.connectTimeout", 5000)
    .property("jersey.config.client.readTimeout", 10000)
    .build();
```

---

## 9. Monitoring & Observability

### 9.1 Add Health Checks

**Recommendation:**
```java
@Health
@ApplicationScoped
public class ServiceHealthCheck implements HealthCheck {
    @Override
    public HealthCheckResponse call() {
        return HealthCheckResponse
            .named("service-check")
            .up()
            .build();
    }
}
```

### 9.2 Add Metrics

**Recommendation:**
```java
@Counted(name = "bomb_created", description = "Number of bombs created")
@Timed(name = "position_timer", description = "Time to get positions")
public Response position() { ... }
```

---

## 10. Implementation Priority

### Phase 1 (Critical - Week 1-2)
1. Fix security vulnerabilities (update dependencies)
2. Add proper exception handling and logging
3. Fix resource leaks (JAX-RS client management)
4. Add input validation

### Phase 2 (High - Week 3-4)
5. Implement service discovery/configuration
6. Add unit and integration tests
7. Replace Vector with modern collections
8. Extract magic numbers to constants

### Phase 3 (Medium - Week 5-6)
9. Add API documentation (OpenAPI)
10. Implement health checks and metrics
11. Add caching layer
12. Improve error responses

### Phase 4 (Low - Week 7-8)
13. Migrate frontend to modern framework
14. Implement async REST calls
15. Add CI/CD pipeline
16. Performance optimization

---

## Conclusion

The MicroInvader project demonstrates good microservices architecture concepts but requires significant modernization. The most critical issues are security vulnerabilities from outdated dependencies and poor error handling. Addressing these systematically will result in a production-ready, maintainable application.

**Estimated Effort:** 6-8 weeks for full implementation
**Risk Level:** Medium (breaking changes required)
**Business Impact:** High (improved security, reliability, maintainability)