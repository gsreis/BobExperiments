# MicroInvader - OpenShift Deployment

This document provides a quick overview of deploying MicroInvader to OpenShift. For detailed instructions, see [openshift/README.md](openshift/README.md).

## What's New for OpenShift

The project has been enhanced with OpenShift support:

### Added Files

```
├── Dockerfile                          # Multi-stage Docker build
├── .dockerignore                       # Docker build optimization
└── openshift/
    ├── README.md                       # Detailed deployment guide
    ├── deploy.sh                       # Automated deployment script
    ├── undeploy.sh                     # Cleanup script
    ├── microinvader-template.yaml      # Complete OpenShift template
    ├── buildconfigs/
    │   ├── microinvader-buildconfig.yaml
    │   └── microinvader-imagestream.yaml
    ├── configmaps/
    │   └── microinvader-config.yaml
    ├── deployments/
    │   └── microinvader-deployment.yaml
    ├── services/
    │   └── microinvader-service.yaml
    └── routes/
        └── microinvader-route.yaml
```

## Quick Start

### Prerequisites

1. OpenShift cluster access (v4.x or later)
2. OpenShift CLI (`oc`) installed
3. Git repository with your code

### Deploy in 3 Steps

```bash
# 1. Login to OpenShift
oc login <your-openshift-cluster-url>

# 2. Run deployment script
cd openshift
./deploy.sh

# 3. Access the game
# The script will display the URL, typically:
# https://<route-url>/space-1.0/game.html
```

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    OpenShift Cluster                     │
│                                                          │
│  ┌────────────────────────────────────────────────┐    │
│  │              microinvader Project               │    │
│  │                                                 │    │
│  │  ┌──────────────────────────────────────────┐  │    │
│  │  │         Route (TLS Edge)                 │  │    │
│  │  │  https://microinvader-xxx.apps.xxx       │  │    │
│  │  └──────────────┬───────────────────────────┘  │    │
│  │                 │                               │    │
│  │  ┌──────────────▼───────────────────────────┐  │    │
│  │  │         Service (ClusterIP)              │  │    │
│  │  │         Port: 9080, 9443                 │  │    │
│  │  └──────────────┬───────────────────────────┘  │    │
│  │                 │                               │    │
│  │  ┌──────────────▼───────────────────────────┐  │    │
│  │  │         Deployment                       │  │    │
│  │  │         Replicas: 1-5 (scalable)         │  │    │
│  │  │                                          │  │    │
│  │  │  ┌────────────────────────────────────┐ │  │    │
│  │  │  │  Pod: microinvader                 │ │  │    │
│  │  │  │                                    │ │  │    │
│  │  │  │  Container: Open Liberty          │ │  │    │
│  │  │  │  - space-1.0.war                  │ │  │    │
│  │  │  │  - player-1.0.war                 │ │  │    │
│  │  │  │  - enemy-1.0.war                  │ │  │    │
│  │  │  │  - bomb-1.0.war                   │ │  │    │
│  │  │  │  - collision-1.0.war              │ │  │    │
│  │  │  │                                    │ │  │    │
│  │  │  │  Health Checks:                   │ │  │    │
│  │  │  │  - Startup: /health/started       │ │  │    │
│  │  │  │  - Liveness: /health/live         │ │  │    │
│  │  │  │  - Readiness: /health/ready       │ │  │    │
│  │  │  └────────────────────────────────────┘ │  │    │
│  │  └──────────────────────────────────────────┘  │    │
│  │                                                 │    │
│  │  ┌──────────────────────────────────────────┐  │    │
│  │  │         ConfigMap                        │  │    │
│  │  │         microinvader-config              │  │    │
│  │  └──────────────────────────────────────────┘  │    │
│  │                                                 │    │
│  │  ┌──────────────────────────────────────────┐  │    │
│  │  │         BuildConfig                      │  │    │
│  │  │         Source: Git                      │  │    │
│  │  │         Strategy: Docker                 │  │    │
│  │  └──────────────────────────────────────────┘  │    │
│  │                                                 │    │
│  │  ┌──────────────────────────────────────────┐  │    │
│  │  │         ImageStream                      │  │    │
│  │  │         microinvader:latest              │  │    │
│  │  └──────────────────────────────────────────┘  │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

## Key Features

### 🐳 Containerization
- Multi-stage Docker build for optimized image size
- Based on official Open Liberty runtime
- Java 17 with OpenJ9 JVM

### 🔧 Configuration
- ConfigMap for environment variables
- Externalized configuration
- Easy to modify without rebuilding

### 🏥 Health Checks
- Startup probe for initialization
- Liveness probe for container health
- Readiness probe for traffic routing

### 📊 Monitoring
- JSON-formatted logs for easy parsing
- MicroProfile Metrics endpoint
- MicroProfile Health endpoints

### 🔒 Security
- Non-root container execution
- Dropped capabilities
- Seccomp profile
- TLS termination at route

### 📈 Scalability
- Horizontal Pod Autoscaler support
- Session affinity for game state
- Resource requests and limits

## Deployment Options

### Option 1: Automated Script (Easiest)
```bash
cd openshift && ./deploy.sh
```

### Option 2: OpenShift Template
```bash
oc process -f openshift/microinvader-template.yaml | oc apply -f -
```

### Option 3: Individual Resources
```bash
oc apply -f openshift/buildconfigs/
oc apply -f openshift/configmaps/
oc apply -f openshift/deployments/
oc apply -f openshift/services/
oc apply -f openshift/routes/
```

### Option 4: Web Console
Use the OpenShift Web Console to import from Git

## Common Operations

### View Application Status
```bash
oc get pods
oc get route microinvader
```

### View Logs
```bash
oc logs -f deployment/microinvader
```

### Scale Application
```bash
oc scale deployment/microinvader --replicas=3
```

### Update Configuration
```bash
oc edit configmap microinvader-config
oc rollout restart deployment/microinvader
```

### Rebuild Application
```bash
oc start-build microinvader
```

### Remove Application
```bash
cd openshift && ./undeploy.sh
```

## Resource Requirements

### Minimum
- Memory: 512Mi
- CPU: 250m

### Recommended
- Memory: 1Gi
- CPU: 1000m

### For Production
- Memory: 1.5Gi
- CPU: 1500m
- Replicas: 2-3

## Troubleshooting

### Build Fails
```bash
oc logs -f bc/microinvader
oc start-build microinvader
```

### Pods Not Starting
```bash
oc describe pod <pod-name>
oc get events
```

### Application Not Accessible
```bash
oc get route microinvader
oc describe route microinvader
oc get svc microinvader
```

## Next Steps

1. **Customize**: Edit the template parameters for your environment
2. **Monitor**: Set up monitoring and alerting
3. **Scale**: Configure HPA for automatic scaling
4. **Secure**: Add network policies and additional security measures
5. **CI/CD**: Integrate with your CI/CD pipeline

## Documentation

- **Detailed Guide**: [openshift/README.md](openshift/README.md)
- **Architecture**: [ARCHITECTURE_DOCUMENTATION.md](ARCHITECTURE_DOCUMENTATION.md)
- **Original README**: [README.TXT](README.TXT)

## Support

For issues and questions:
- Check the detailed guide: [openshift/README.md](openshift/README.md)
- Review OpenShift logs: `oc logs -f deployment/microinvader`
- Check pod status: `oc describe pod <pod-name>`

## Comparison: Local vs OpenShift

| Aspect | Local Development | OpenShift |
|--------|------------------|-----------|
| **Deployment** | `mvn install && ./server start` | `./deploy.sh` |
| **Access** | http://localhost:9081 | https://route-url |
| **Scaling** | Single instance | Auto-scaling (1-5 pods) |
| **Monitoring** | Local logs | Centralized logging |
| **Security** | Development mode | Production-ready |
| **High Availability** | No | Yes (multiple replicas) |
| **TLS** | Optional | Automatic (edge termination) |

## License

See the main project LICENSE file.