#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para gerar apresentação PowerPoint sobre produtos IBM Automation
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

def create_title_slide(prs, title, subtitle):
    """Cria slide de título"""
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    title_shape = slide.shapes.title
    subtitle_shape = slide.placeholders[1]
    
    title_shape.text = title
    subtitle_shape.text = subtitle
    
    # Formatação
    title_shape.text_frame.paragraphs[0].font.size = Pt(44)
    title_shape.text_frame.paragraphs[0].font.bold = True
    title_shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 0, 139)
    
    return slide

def create_content_slide(prs, title, content_items):
    """Cria slide de conteúdo com bullets"""
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    title_shape = slide.shapes.title
    body_shape = slide.placeholders[1]
    
    title_shape.text = title
    title_shape.text_frame.paragraphs[0].font.size = Pt(32)
    title_shape.text_frame.paragraphs[0].font.bold = True
    title_shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 0, 139)
    
    text_frame = body_shape.text_frame
    text_frame.clear()
    
    for item in content_items:
        p = text_frame.add_paragraph()
        p.text = item
        p.level = 0
        p.font.size = Pt(18)
        p.space_after = Pt(12)
    
    return slide

def create_product_slide(prs, product_name, description, features, use_cases, benefits):
    """Cria slide detalhado de produto"""
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Blank layout
    
    # Título
    left = Inches(0.5)
    top = Inches(0.3)
    width = Inches(9)
    height = Inches(0.8)
    title_box = slide.shapes.add_textbox(left, top, width, height)
    title_frame = title_box.text_frame
    title_frame.text = product_name
    title_frame.paragraphs[0].font.size = Pt(32)
    title_frame.paragraphs[0].font.bold = True
    title_frame.paragraphs[0].font.color.rgb = RGBColor(0, 0, 139)
    
    # Descrição
    left = Inches(0.5)
    top = Inches(1.2)
    width = Inches(9)
    height = Inches(0.6)
    desc_box = slide.shapes.add_textbox(left, top, width, height)
    desc_frame = desc_box.text_frame
    desc_frame.text = description
    desc_frame.paragraphs[0].font.size = Pt(16)
    desc_frame.paragraphs[0].font.italic = True
    
    # Funcionalidades
    left = Inches(0.5)
    top = Inches(2.0)
    width = Inches(4.2)
    height = Inches(3.5)
    features_box = slide.shapes.add_textbox(left, top, width, height)
    features_frame = features_box.text_frame
    features_frame.word_wrap = True
    
    p = features_frame.paragraphs[0]
    p.text = "Principais Funcionalidades:"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = RGBColor(0, 100, 0)
    
    for feature in features:
        p = features_frame.add_paragraph()
        p.text = f"• {feature}"
        p.font.size = Pt(12)
        p.space_after = Pt(6)
    
    # Casos de Uso e Benefícios
    left = Inches(5.2)
    top = Inches(2.0)
    width = Inches(4.3)
    height = Inches(3.5)
    right_box = slide.shapes.add_textbox(left, top, width, height)
    right_frame = right_box.text_frame
    right_frame.word_wrap = True
    
    p = right_frame.paragraphs[0]
    p.text = "Casos de Uso:"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = RGBColor(139, 0, 0)
    
    for use_case in use_cases:
        p = right_frame.add_paragraph()
        p.text = f"✓ {use_case}"
        p.font.size = Pt(12)
        p.space_after = Pt(6)
    
    if benefits:
        p = right_frame.add_paragraph()
        p.text = "\nBenefícios:"
        p.font.size = Pt(14)
        p.font.bold = True
        p.font.color.rgb = RGBColor(0, 100, 0)
        
        for benefit in benefits:
            p = right_frame.add_paragraph()
            p.text = f"★ {benefit}"
            p.font.size = Pt(12)
            p.space_after = Pt(6)
    
    return slide

def main():
    """Função principal"""
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    # Slide 1: Capa
    create_title_slide(
        prs,
        "IBM Automation Portfolio",
        "Guia Completo de Produtos para Vendedores\n2026"
    )
    
    # Slide 2: Visão Geral
    create_content_slide(
        prs,
        "O que é IBM Automation?",
        [
            "Plataforma integrada para automatizar processos de negócio end-to-end",
            "Combina IA, automação de processos, RPA e integração",
            "Reduz custos operacionais em até 60% e aumenta eficiência",
            "Acelera a transformação digital das empresas",
            "",
            "Principais Benefícios:",
            "  ⚡ Redução de até 80% no tempo de processos",
            "  💰 ROI médio de 200-300% no primeiro ano",
            "  🎯 Maior precisão e redução de erros humanos",
            "  📈 Escalabilidade empresarial"
        ]
    )
    
    # Slide 3: Cloud Pak for Business Automation
    create_product_slide(
        prs,
        "IBM Cloud Pak for Business Automation",
        "Plataforma unificada de automação empresarial baseada em contêineres (Kubernetes/OpenShift)",
        [
            "Gestão de Documentos e Conteúdo (ECM)",
            "Automação de Processos (BPM/Workflow)",
            "Captura Inteligente de Documentos (AI)",
            "Automação de Decisões (Business Rules)",
            "RPA - Robotic Process Automation",
            "Process Mining e Analytics"
        ],
        [
            "Processamento de pedidos",
            "Gestão de contratos",
            "Onboarding de clientes",
            "Processamento de sinistros",
            "Aprovações financeiras"
        ],
        [
            "Plataforma All-in-One",
            "Deploy em qualquer cloud",
            "Integração nativa entre componentes"
        ]
    )
    
    # Slide 4: IBM RPA (Robotic Process Automation)
    create_product_slide(
        prs,
        "IBM Robotic Process Automation (RPA)",
        "Robôs de software que automatizam tarefas repetitivas e baseadas em regras",
        [
            "Bots que imitam ações humanas em sistemas",
            "Interface low-code/no-code para criação",
            "Integração com sistemas legados (sem APIs)",
            "Trabalha 24/7 sem erros ou fadiga",
            "Orquestração de múltiplos bots",
            "Analytics e monitoramento em tempo real"
        ],
        [
            "Extração de dados de emails/PDFs",
            "Preenchimento automático de formulários",
            "Migração de dados entre sistemas",
            "Geração de relatórios automáticos",
            "Atualização de múltiplos sistemas"
        ],
        [
            "ROI típico: 200-300% ano 1",
            "Implementação rápida (semanas)",
            "Não requer mudanças em sistemas"
        ]
    )
    
    # Slide 5: Business Automation Workflow
    create_product_slide(
        prs,
        "IBM Business Automation Workflow",
        "Plataforma BPM para desenhar, executar e otimizar processos de negócio complexos",
        [
            "Designer visual de processos (BPMN 2.0)",
            "Orquestração de workflows complexos",
            "Dashboards e analytics em tempo real",
            "Gestão de tarefas e aprovações",
            "Notificações e alertas automáticos",
            "APIs REST para integração"
        ],
        [
            "Processos com múltiplas aprovações",
            "Workflows interdepartamentais",
            "Gestão de exceções e escalações",
            "Processos regulatórios (compliance)",
            "Onboarding de funcionários"
        ],
        [
            "Visibilidade end-to-end",
            "Redução de gargalos",
            "Auditoria completa",
            "Melhoria contínua"
        ]
    )
    
    # Slide 6: Operational Decision Manager (ODM)
    create_product_slide(
        prs,
        "IBM Operational Decision Manager (ODM)",
        "Sistema de gestão de regras de negócio e decisões automatizadas em tempo real",
        [
            "Motor de regras de negócio (BRMS)",
            "Decisões em milissegundos",
            "Simulação e teste de cenários",
            "Interface para usuários de negócio",
            "Versionamento de regras",
            "Atualização sem deploy de código"
        ],
        [
            "Aprovação de crédito automática",
            "Precificação dinâmica",
            "Detecção de fraudes",
            "Roteamento inteligente de chamados",
            "Cálculo de descontos e promoções"
        ],
        [
            "Usuários de negócio alteram regras",
            "Time-to-market reduzido",
            "Consistência nas decisões"
        ]
    )
    
    # Slide 7: FileNet Content Manager
    create_product_slide(
        prs,
        "IBM FileNet Content Manager",
        "Plataforma enterprise de gestão de conteúdo e documentos (ECM) de alta performance",
        [
            "Repositório centralizado de documentos",
            "Busca avançada e indexação full-text",
            "Segurança granular e compliance",
            "Gestão de ciclo de vida de documentos",
            "Versionamento e check-in/check-out",
            "Suporte a bilhões de documentos"
        ],
        [
            "Eliminação de arquivos físicos",
            "Gestão de contratos corporativos",
            "Documentação regulatória",
            "Prontuários médicos eletrônicos",
            "Gestão de correspondências"
        ],
        [
            "Redução de custos de armazenamento",
            "Acesso rápido à informação",
            "Conformidade (LGPD, SOX, HIPAA)",
            "Integra com Office 365, SAP"
        ]
    )
    
    # Slide 8: IBM Datacap
    create_product_slide(
        prs,
        "IBM Datacap",
        "Solução de captura inteligente de documentos com IA e OCR avançado",
        [
            "OCR de alta precisão (99%+)",
            "IA para classificação automática",
            "Extração de dados estruturados",
            "Validação automática de dados",
            "Processamento de lotes",
            "Integração com sistemas backend"
        ],
        [
            "Processamento de faturas (AP)",
            "Digitalização de formulários",
            "Extração de dados de contratos",
            "Processamento de pedidos",
            "Captura de documentos de identidade"
        ],
        [
            "Redução de 90% no tempo manual",
            "Precisão superior a digitação",
            "ROI em 6-12 meses"
        ]
    )
    
    # Slide 9: Process Mining
    create_product_slide(
        prs,
        "IBM Process Mining",
        "Ferramenta de análise e descoberta de processos reais baseada em dados de sistemas",
        [
            "Análise de logs de sistemas (event logs)",
            "Visualização de processos reais",
            "Identificação de gargalos e desvios",
            "Simulação de melhorias",
            "Monitoramento contínuo (real-time)",
            "Dashboards executivos"
        ],
        [
            "Descoberta de processos ocultos",
            "Análise de conformidade",
            "Otimização de processos existentes",
            "Identificação de automações",
            "Benchmarking de performance"
        ],
        [
            "Mostra realidade vs. teoria",
            "Decisões baseadas em dados",
            "Melhoria contínua",
            "ROI mensurável"
        ]
    )
    
    # Slide 10: Automation Decision Services
    create_product_slide(
        prs,
        "IBM Automation Decision Services",
        "Plataforma moderna para automação de decisões com Machine Learning integrado",
        [
            "Machine Learning nativo",
            "Decisões baseadas em dados históricos",
            "Otimização contínua automática",
            "Cloud-native (containers)",
            "APIs REST modernas",
            "Interface low-code"
        ],
        [
            "Recomendações personalizadas",
            "Otimização de recursos",
            "Previsão de demanda",
            "Gestão de riscos",
            "Pricing inteligente"
        ],
        [
            "Evolução do ODM",
            "Mais IA, mais automação",
            "Aprendizado contínuo"
        ]
    )
    
    # Slide 11: App Connect
    create_product_slide(
        prs,
        "IBM App Connect",
        "Plataforma de integração de aplicações (iPaaS) e sincronização de dados",
        [
            "Conectores pré-construídos (150+)",
            "Sincronização em tempo real",
            "Transformação de dados",
            "Interface visual (low-code)",
            "APIs REST e eventos",
            "Deploy em cloud ou on-premise"
        ],
        [
            "Integração Salesforce + SAP",
            "Sincronização CRM + ERP",
            "Integração com SaaS (Office 365, etc)",
            "Migração de dados",
            "Automação de workflows entre apps"
        ],
        [
            "Elimina silos de dados",
            "Implementação rápida",
            "Reduz desenvolvimento custom"
        ]
    )
    
    # Slide 12: Cloud Pak for Integration
    create_product_slide(
        prs,
        "IBM Cloud Pak for Integration",
        "Plataforma completa de integração empresarial em contêineres",
        [
            "API Management (API Connect)",
            "Application Integration (App Connect)",
            "Messaging (MQ)",
            "Event Streaming (Kafka)",
            "High-Speed Transfer (Aspera)",
            "Gateway de segurança"
        ],
        [
            "Arquitetura de microserviços",
            "Integração híbrida (cloud + on-prem)",
            "Modernização de aplicações",
            "Exposição segura de APIs",
            "Event-driven architecture"
        ],
        [
            "Plataforma unificada",
            "Deploy em qualquer cloud",
            "Escalabilidade enterprise"
        ]
    )
    
    # Slide 13: IBM MQ (Message Queue)
    create_product_slide(
        prs,
        "IBM MQ (Message Queue)",
        "Middleware de mensageria enterprise para comunicação confiável entre aplicações",
        [
            "Garantia de entrega de mensagens",
            "Suporte a múltiplos protocolos",
            "Alta disponibilidade (99.999%)",
            "Segurança enterprise",
            "Performance extrema (milhões msg/seg)",
            "Suporte a transações distribuídas"
        ],
        [
            "Integração de sistemas críticos",
            "Processamento de transações",
            "Comunicação assíncrona",
            "Desacoplamento de aplicações",
            "Arquiteturas event-driven"
        ],
        [
            "Líder de mercado há 30+ anos",
            "Confiabilidade comprovada",
            "Suporte a mainframe e cloud"
        ]
    )
    
    # Slide 14: API Connect
    create_product_slide(
        prs,
        "IBM API Connect",
        "Plataforma completa de gestão de APIs (API Management) para criar, expor e monetizar APIs",
        [
            "Gateway de APIs de alta performance",
            "Portal do desenvolvedor",
            "Analytics e monitoramento",
            "Segurança (OAuth, JWT, etc)",
            "Planos e monetização",
            "Versionamento de APIs"
        ],
        [
            "Exposição de APIs para parceiros",
            "Monetização de dados/serviços",
            "Arquitetura de microserviços",
            "API economy",
            "Integração B2B"
        ],
        [
            "Líder no Gartner Magic Quadrant",
            "Deploy híbrido",
            "Escalabilidade comprovada"
        ]
    )
    
    # Slide 15: Aspera (High-Speed Transfer)
    create_product_slide(
        prs,
        "IBM Aspera",
        "Tecnologia patenteada de transferência de arquivos em alta velocidade (até 100x mais rápido)",
        [
            "Protocolo FASP (patenteado)",
            "Velocidade máxima da rede",
            "Transferência de arquivos grandes (TB)",
            "Segurança end-to-end",
            "Retomada automática",
            "Independente de latência/distância"
        ],
        [
            "Transferência de vídeos 4K/8K",
            "Distribuição de conteúdo global",
            "Backup e disaster recovery",
            "Migração de dados para cloud",
            "Colaboração em arquivos grandes"
        ],
        [
            "Usado por Hollywood",
            "Economia de tempo e custos",
            "Confiabilidade comprovada"
        ]
    )
    
    # Slide 16: Event Streams (Kafka)
    create_product_slide(
        prs,
        "IBM Event Streams",
        "Plataforma de streaming de eventos baseada em Apache Kafka enterprise-ready",
        [
            "Apache Kafka gerenciado",
            "Alta disponibilidade e durabilidade",
            "Geo-replicação",
            "Segurança enterprise",
            "Monitoramento e alertas",
            "Suporte 24/7"
        ],
        [
            "Event-driven architecture",
            "Real-time analytics",
            "IoT data streaming",
            "Log aggregation",
            "Change Data Capture (CDC)"
        ],
        [
            "Kafka sem complexidade",
            "Deploy em qualquer cloud",
            "Escalabilidade automática"
        ]
    )
    
    # Slide 17: Comparação - Quando usar cada produto
    create_content_slide(
        prs,
        "Guia Rápido: Quando Usar Cada Produto",
        [
            "RPA: Tarefas repetitivas em sistemas sem APIs (quick wins)",
            "Workflow: Processos complexos com aprovações e orquestrações",
            "ODM/ADS: Decisões automatizadas baseadas em regras ou ML",
            "FileNet: Gestão de grandes volumes de documentos (ECM)",
            "Datacap: Digitalização e extração de dados de documentos",
            "Process Mining: Descobrir e otimizar processos existentes",
            "App Connect: Integração rápida entre aplicações SaaS/cloud",
            "MQ: Mensageria confiável para sistemas críticos",
            "API Connect: Expor e gerenciar APIs para parceiros/clientes",
            "Event Streams: Arquiteturas event-driven e real-time"
        ]
    )
    
    # Slide 18: Arquitetura Típica
    create_content_slide(
        prs,
        "Arquitetura de Referência IBM Automation",
        [
            "Camada de Apresentação:",
            "  • Portais web, mobile apps, chatbots",
            "",
            "Camada de Processos:",
            "  • Workflow + RPA + Decisões (ODM/ADS)",
            "",
            "Camada de Integração:",
            "  • App Connect + API Connect + MQ + Event Streams",
            "",
            "Camada de Dados:",
            "  • FileNet (documentos) + Databases + Data Lakes",
            "",
            "Camada de Analytics:",
            "  • Process Mining + Business Intelligence + AI/ML"
        ]
    )
    
    # Slide 19: Casos de Sucesso
    create_content_slide(
        prs,
        "Casos de Sucesso - Resultados Reais",
        [
            "Banco Global:",
            "  • 70% redução no tempo de aprovação de crédito com ODM",
            "  • ROI de 250% em 18 meses",
            "",
            "Seguradora:",
            "  • 80% redução no processamento de sinistros com RPA + Datacap",
            "  • 2 milhões de documentos processados/ano",
            "",
            "Telecom:",
            "  • 60% redução no tempo de onboarding com Workflow",
            "  • Satisfação do cliente aumentou 40%",
            "",
            "Varejo:",
            "  • 90% automação de pedidos com App Connect + RPA",
            "  • Economia de $5M/ano em custos operacionais"
        ]
    )
    
    # Slide 20: Modelos de Licenciamento
    create_content_slide(
        prs,
        "Modelos de Licenciamento e Pricing",
        [
            "Cloud Paks (Subscription):",
            "  • Virtual Processor Core (VPC) - baseado em CPU",
            "  • Usuários Autorizados - por usuário nomeado",
            "  • Instâncias - por ambiente/cluster",
            "",
            "SaaS (IBM Cloud):",
            "  • Pay-as-you-go - uso mensal",
            "  • Subscription - compromisso anual com desconto",
            "",
            "Perpétuo (On-Premise):",
            "  • Licença perpétua + manutenção anual (S&S)",
            "",
            "Flex Points:",
            "  • Créditos flexíveis para múltiplos produtos",
            "  • Ideal para portfólios grandes"
        ]
    )
    
    # Slide 21: Diferenciais Competitivos
    create_content_slide(
        prs,
        "Por Que Escolher IBM Automation?",
        [
            "✓ Plataforma Completa: Única vendor com solução end-to-end",
            "✓ Integração Nativa: Produtos trabalham juntos out-of-the-box",
            "✓ Enterprise-Ready: Segurança, escalabilidade e confiabilidade",
            "✓ Híbrido: Deploy em qualquer cloud ou on-premise",
            "✓ IA Integrada: Watson AI em toda a plataforma",
            "✓ Suporte Global: 24/7 em português",
            "✓ Ecossistema: Milhares de parceiros e integradores",
            "✓ Inovação: Investimento contínuo em R&D",
            "✓ Compliance: Certificações globais (ISO, SOC2, etc)",
            "✓ ROI Comprovado: Casos de sucesso em todos os setores"
        ]
    )
    
    # Slide 22: Próximos Passos
    create_content_slide(
        prs,
        "Próximos Passos para Iniciar",
        [
            "1. Assessment Gratuito:",
            "   • Análise de processos e identificação de oportunidades",
            "   • Workshop de 2-3 dias com especialistas IBM",
            "",
            "2. Proof of Concept (PoC):",
            "   • Implementação piloto em 4-8 semanas",
            "   • Demonstração de valor com dados reais",
            "",
            "3. Treinamento:",
            "   • Certificações IBM para equipe técnica",
            "   • Workshops para usuários de negócio",
            "",
            "4. Implementação:",
            "   • Metodologia ágil com entregas incrementais",
            "   • Suporte de parceiros certificados IBM"
        ]
    )
    
    # Slide 23: Recursos e Contatos
    create_content_slide(
        prs,
        "Recursos e Contatos",
        [
            "Documentação e Trials:",
            "  • ibm.com/automation",
            "  • ibm.com/cloud/automation",
            "",
            "Comunidade e Suporte:",
            "  • IBM Community (community.ibm.com)",
            "  • IBM Support (ibm.com/support)",
            "  • IBM Training (ibm.com/training)",
            "",
            "Contatos IBM Brasil:",
            "  • Email: automation@br.ibm.com",
            "  • Telefone: 0800-xxx-xxxx",
            "  • Portal de Parceiros: ibm.com/partnerworld",
            "",
            "Siga-nos:",
            "  • LinkedIn: IBM Automation",
            "  • YouTube: IBM Technology"
        ]
    )
    
    # Slide 24: Encerramento
    create_title_slide(
        prs,
        "Obrigado!",
        "IBM Automation - Transformando Negócios\n\nPerguntas?"
    )
    
    # Salvar apresentação
    filename = "IBM_Automation_Portfolio_2026.pptx"
    prs.save(filename)
    print(f"✅ Apresentação criada com sucesso: {filename}")
    print(f"📊 Total de slides: {len(prs.slides)}")
    print(f"📁 Arquivo salvo em: {filename}")

if __name__ == "__main__":
    main()

# Made with Bob
