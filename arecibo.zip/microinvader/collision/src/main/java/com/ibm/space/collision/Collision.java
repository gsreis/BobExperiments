package com.ibm.space.collision;

import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.core.MediaType;


@Path("/")
public class Collision {
	
	private static final Logger LOGGER = Logger.getLogger(Collision.class.getName());
	
	// Singleton JAX-RS client for reuse (prevents resource leaks)
	private static final Client REST_CLIENT = ClientBuilder.newClient();
	
	// Service URLs - externalized via system properties
	private static final String[] SERVICE_URLS = {
		"http://" + System.getProperty("enemyip", "127.0.0.1:9081") + "/enemy-1.0/",
		"http://" + System.getProperty("playerip", "127.0.0.1:9081") + "/player-1.0/",
		"http://" + System.getProperty("bombip", "127.0.0.1:9081") + "/bomb-1.0/",
		"http://" + System.getProperty("collisionip", "127.0.0.1:9081") + "/collision-1.0/"
	};

	@GET
	@Path("/position")
	   @Produces("application/json")
	public String position() {
	   	return "[]";
	   }
	
	/**
	 * Compare all bombs with all Enemies and Player's position.
	 * If at the same position, destroy bomb and Enemies or Player.
	 * Compare Player with all Enemies Position. If same position destroy Player.
	 */
	@GET
	@Path("/run")
	public void run() {
		try {
			JsonArrayBuilder allelements = Json.createArrayBuilder();
			// Join all elements together
			for (int i = 0; i < SERVICE_URLS.length; i++) {
				String json = callRest(SERVICE_URLS[i] + "position");
				JsonArray array = Json.createReader(new StringReader(json)).readArray();
				for (int j = 0; j < array.size(); j++) {
					allelements.add(array.get(j));
				}
			}
			
			// Check if two elements match same position
			JsonArray array = allelements.build();
			boolean[] sprites = new boolean[array.size()];
			for (int i = 0; i < sprites.length; i++) {
				sprites[i] = ((JsonObject)array.get(i)).getBoolean("destroyed");
			}
			
			// Detect collisions
			for (int i = 0; i < array.size(); i++) {
				for (int j = i + 1; j < array.size(); j++) {
					JsonObject obj1 = (JsonObject)array.get(i);
					JsonObject obj2 = (JsonObject)array.get(j);
					
					if (obj1.getInt("x") == obj2.getInt("x") &&
						obj1.getInt("y") == obj2.getInt("y") &&
						obj1.getInt("id") != obj2.getInt("id") &&
						!obj1.getBoolean("destroyed") &&
						!obj2.getBoolean("destroyed") &&
						!sprites[i] &&
						!sprites[j]) {
						
						sprites[i] = sprites[j] = true;
						
						String resturl1 = findRest(obj1.getString("type"));
						if (resturl1 != null) {
							callRest(resturl1 + "destroy/" + obj1.getInt("id"));
							LOGGER.log(Level.FINE, "Destroyed {0} with id {1}",
								new Object[]{obj1.getString("type"), obj1.getInt("id")});
						}
						
						String resturl2 = findRest(obj2.getString("type"));
						if (resturl2 != null) {
							callRest(resturl2 + "destroy/" + obj2.getInt("id"));
							LOGGER.log(Level.FINE, "Destroyed {0} with id {1}",
								new Object[]{obj2.getString("type"), obj2.getInt("id")});
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Error during collision detection", e);
		}
	}
	
	@GET
	@Path("/destroy/{id}")
	public void destroy(@PathParam("id") int id) {
		// No-op: collision service doesn't maintain state
	}
	
	   @GET
	@Path("/move/{key}")
	public void move(@PathParam("key") String key) {
		// No-op: collision service doesn't maintain state
	   }

	   @GET
	@Path("/isFinished")
	   @Produces("application/json")
	   public String hasEnded() {
	   	return "{\"finished\" : false}";
	   }

	/**
	 * Finds service URL by entity type name.
	 */
	   private String findRest(String typeName) {
		for (int i = 0; i < SERVICE_URLS.length; i++) {
			if (SERVICE_URLS[i].indexOf(typeName) != -1) {
				return SERVICE_URLS[i];
			}
		}
		LOGGER.log(Level.WARNING, "Service URL not found for type: " + typeName);
		return null;
	}

	/**
	 * Calls a REST endpoint using the singleton client.
	 * Proper exception handling with logging.
	 */
	private String callRest(String urlin) {
		try {
			return REST_CLIENT.target(urlin)
					.request(MediaType.APPLICATION_JSON)
					.get(String.class);
		} catch (Exception e) {
			LOGGER.log(Level.WARNING, "Failed to call REST endpoint: " + urlin, e);
			return "[]";
		}
	}
}
