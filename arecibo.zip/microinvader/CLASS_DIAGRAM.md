# MicroInvader - Class Diagram Documentation

## Overview

This document provides comprehensive UML class diagrams for the MicroInvader application, showing the object-oriented structure, relationships, and responsibilities of all classes across the microservices.

---

## Complete System Class Diagram

```mermaid
classDiagram
    %% JAX-RS Service Classes
    class Space {
        -Logger LOGGER$
        -Client REST_CLIENT$
        -Random random
        -String[] SERVICE_URLS$
        +position() Response
        +run() Response
        +destroy(int id) Response
        +move(String key) Response
        +createBomb(String x, String y, String up) Response
        +isFinished() Response
        -callRest(String url) String
        -getURLFromName(String name) String
    }

    class Player {
        -Logger LOGGER$
        -ServletContext context
        +position(HttpServletRequest) Response
        +move(int key) Response
        +destroy() void
        +hasEnded() Response
        -getValues() PlayerValues
        -resetValues() void
    }

    class Enemies {
        -Logger LOGGER$
        -int GRID_MAX_X$
        -int GRID_MAX_Y$
        -int KEY_RESET$
        -ServletContext context
        +position(HttpServletRequest) Response
        +run() Response
        +destroy(int id) Response
        +move(int key) Response
        +hasEnded() Response
        -incrementAllX() void
        -incrementAllY() void
        -returnAllXtoBegin() void
        -destroyAllEnemies() void
        -getValues() EnemiesValues
        -resetValues() void
    }

    class Bombs {
        -Logger LOGGER$
        -SecureRandom RANDOM$
        -ServletContext context
        +position(HttpServletRequest) Response
        +run() Response
        +create(String x, String y, String up) Response
        +destroy(int id) Response
        +hasEnded() Response
        -getValues() BombsValues
    }

    class Collision {
        -Logger LOGGER$
        -Client REST_CLIENT$
        -String[] SERVICE_URLS$
        +position() String
        +run() void
        +destroy(int id) void
        +move(String key) void
        +hasEnded() String
        -findRest(String typeName) String
        -callRest(String url) String
    }

    %% Value Objects / State Classes
    class PlayerValues {
        -int x
        -int y
        -boolean destroyed
        -byte[] image
        -byte[] blank
        +getX() int
        +setX(int x) void
        +getY() int
        +isDestroyed() boolean
        +setDestroyed(boolean) void
        +getImage() byte[]
        +setImage(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
    }

    class EnemiesValues {
        -OneTie[] ties
        -byte[] image
        -byte[] blank
        +getTies() OneTie[]
        +setTies(OneTie[]) void
        +getImage() byte[]
        +setImage(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
        +isFinished() boolean
    }

    class BombsValues {
        -List~OneBomb~ bombs
        -byte[] imageup
        -byte[] imagedown
        -byte[] blank
        -boolean hasFinished
        +getBombs() List~OneBomb~
        +setBombs(List~OneBomb~) void
        +getImageUp() byte[]
        +setImageUp(byte[]) void
        +getImageDown() byte[]
        +setImageDown(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
        +isHasFinished() boolean
        +setHasFinished(boolean) void
    }

    %% Entity Classes
    class OneTie {
        -int id
        -int x
        -int y
        -boolean destroyed
        +OneTie(int id)
        +getId() int
        +getX() int
        +setX(int) void
        +getY() int
        +setY(int) void
        +isDestroyed() boolean
        +setDestroyed(boolean) void
    }

    class OneBomb {
        -int id
        -boolean fromPlayer
        -int x
        -int y
        -boolean destroyed
        +OneBomb(int id, int x, int y, boolean fromPlayer)
        +getId() int
        +setId(int) void
        +isFromPlayer() boolean
        +setFromPlayer(boolean) void
        +getX() int
        +setX(int) void
        +getY() int
        +setY(int) void
        +isDestroyed() boolean
        +setDestroyed(boolean) void
    }

    %% Servlet Classes
    class ImageServlet_Player {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) PlayerValues
    }

    class ImageServlet_Enemy {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) EnemiesValues
    }

    class ImageServlet_Bomb {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) BombsValues
    }

    class ImageServlet_Space {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
    }

    %% Constants Classes
    class GameConstants {
        <<utility>>
        +int BOMB_SPAWN_CHANCE_PERCENT$
        +int GRID_SIZE$
        +int MIN_COORDINATE$
        +int MAX_COORDINATE$
    }

    %% Interfaces
    class Serializable {
        <<interface>>
    }

    %% Relationships - Service to State
    Player --> PlayerValues : manages
    Enemies --> EnemiesValues : manages
    Bombs --> BombsValues : manages
    
    %% Relationships - State to Entity
    EnemiesValues *-- "40" OneTie : contains
    BombsValues *-- "*" OneBomb : contains
    
    %% Relationships - Servlet to State
    ImageServlet_Player ..> PlayerValues : uses
    ImageServlet_Enemy ..> EnemiesValues : uses
    ImageServlet_Bomb ..> BombsValues : uses
    
    %% Relationships - Service Orchestration
    Space ..> Player : calls REST API
    Space ..> Enemies : calls REST API
    Space ..> Bombs : calls REST API
    Space ..> Collision : calls REST API
    
    Collision ..> Player : calls REST API
    Collision ..> Enemies : calls REST API
    Collision ..> Bombs : calls REST API
    
    %% Relationships - Constants
    Space ..> GameConstants : uses
    
    %% Serializable Implementation
    PlayerValues ..|> Serializable : implements
    EnemiesValues ..|> Serializable : implements
    BombsValues ..|> Serializable : implements
    OneTie ..|> Serializable : implements
    OneBomb ..|> Serializable : implements

    %% JAX-RS Context
    Player --> ServletContext : uses
    Enemies --> ServletContext : uses
    Bombs --> ServletContext : uses
```

---

## Service Layer Class Diagrams

### Space Service (Gateway/Orchestrator)

```mermaid
classDiagram
    class Space {
        -Logger LOGGER$
        -Client REST_CLIENT$
        -Random random
        -String[] SERVICE_URLS$
        +position() Response
        +run() Response
        +destroy(int id) Response
        +move(String key) Response
        +createBomb(String x, String y, String up) Response
        +isFinished() Response
        -callRest(String url) String
        -getURLFromName(String name) String
    }

    class GameConstants {
        <<utility>>
        +int BOMB_SPAWN_CHANCE_PERCENT$
        +int GRID_SIZE$
        +int MIN_COORDINATE$
        +int MAX_COORDINATE$
    }

    class ImageServlet_Space {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
    }

    class Client {
        <<JAX-RS>>
    }

    class Logger {
        <<java.util.logging>>
    }

    Space ..> GameConstants : uses
    Space --> Client : uses
    Space --> Logger : uses
    ImageServlet_Space --|> HttpServlet : extends

    note for Space "API Gateway Pattern\nOrchestrates all microservices\nAggregates responses\nGenerates enemy bombs"
```

### Player Service

```mermaid
classDiagram
    class Player {
        -Logger LOGGER$
        -ServletContext context
        +position(HttpServletRequest) Response
        +move(int key) Response
        +destroy() void
        +hasEnded() Response
        -getValues() PlayerValues
        -resetValues() void
    }

    class PlayerValues {
        -int x
        -int y
        -boolean destroyed
        -byte[] image
        -byte[] blank
        +getX() int
        +setX(int x) void
        +getY() int
        +isDestroyed() boolean
        +setDestroyed(boolean) void
        +getImage() byte[]
        +setImage(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
    }

    class ImageServlet_Player {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) PlayerValues
    }

    class Serializable {
        <<interface>>
    }

    Player --> PlayerValues : manages
    Player --> ServletContext : stores state in
    ImageServlet_Player ..> PlayerValues : retrieves
    PlayerValues ..|> Serializable : implements
    ImageServlet_Player --|> HttpServlet : extends

    note for Player "Manages player position\nX: 0-19 (horizontal)\nY: 19 (fixed at bottom)\nHandles movement and destruction"
    
    note for PlayerValues "State object stored in ServletContext\nContains position and sprite data"
```

### Enemy Service

```mermaid
classDiagram
    class Enemies {
        -Logger LOGGER$
        -int GRID_MAX_X$
        -int GRID_MAX_Y$
        -int KEY_RESET$
        -ServletContext context
        +position(HttpServletRequest) Response
        +run() Response
        +destroy(int id) Response
        +move(int key) Response
        +hasEnded() Response
        -incrementAllX() void
        -incrementAllY() void
        -returnAllXtoBegin() void
        -destroyAllEnemies() void
        -getValues() EnemiesValues
        -resetValues() void
    }

    class EnemiesValues {
        -OneTie[] ties
        -byte[] image
        -byte[] blank
        +getTies() OneTie[]
        +setTies(OneTie[]) void
        +getImage() byte[]
        +setImage(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
        +isFinished() boolean
    }

    class OneTie {
        -int id
        -int x
        -int y
        -boolean destroyed
        +OneTie(int id)
        +getId() int
        +getX() int
        +setX(int) void
        +getY() int
        +setY(int) void
        +isDestroyed() boolean
        +setDestroyed(boolean) void
    }

    class ImageServlet_Enemy {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) EnemiesValues
    }

    class Serializable {
        <<interface>>
    }

    Enemies --> EnemiesValues : manages
    EnemiesValues *-- "40" OneTie : contains
    Enemies --> ServletContext : stores state in
    ImageServlet_Enemy ..> EnemiesValues : retrieves
    EnemiesValues ..|> Serializable : implements
    OneTie ..|> Serializable : implements
    ImageServlet_Enemy --|> HttpServlet : extends

    note for Enemies "Manages 40 enemy entities\nFormation-based movement\nHorizontal and vertical movement"
    
    note for OneTie "Individual enemy entity\nID: 0-39\n0-9: first row\n10-19: second row\n20-29: third row\n30-39: fourth row"
```

### Bomb Service

```mermaid
classDiagram
    class Bombs {
        -Logger LOGGER$
        -SecureRandom RANDOM$
        -ServletContext context
        +position(HttpServletRequest) Response
        +run() Response
        +create(String x, String y, String up) Response
        +destroy(int id) Response
        +hasEnded() Response
        -getValues() BombsValues
    }

    class BombsValues {
        -List~OneBomb~ bombs
        -byte[] imageup
        -byte[] imagedown
        -byte[] blank
        -boolean hasFinished
        +getBombs() List~OneBomb~
        +setBombs(List~OneBomb~) void
        +getImageUp() byte[]
        +setImageUp(byte[]) void
        +getImageDown() byte[]
        +setImageDown(byte[]) void
        +getBlank() byte[]
        +setBlank(byte[]) void
        +isHasFinished() boolean
        +setHasFinished(boolean) void
    }

    class OneBomb {
        -int id
        -boolean fromPlayer
        -int x
        -int y
        -boolean destroyed
        +OneBomb(int id, int x, int y, boolean fromPlayer)
        +getId() int
        +setId(int) void
        +isFromPlayer() boolean
        +setFromPlayer(boolean) void
        +getX() int
        +setX(int) void
        +getY() int
        +setY(int) void
        +isDestroyed() boolean
        +setDestroyed(boolean) void
    }

    class ImageServlet_Bomb {
        <<HttpServlet>>
        -long serialVersionUID$
        +doGet(HttpServletRequest, HttpServletResponse) void
        +doPost(HttpServletRequest, HttpServletResponse) void
        -getValues(HttpServletRequest) BombsValues
    }

    class Serializable {
        <<interface>>
    }

    Bombs --> BombsValues : manages
    BombsValues *-- "*" OneBomb : contains
    Bombs --> ServletContext : stores state in
    ImageServlet_Bomb ..> BombsValues : retrieves
    BombsValues ..|> Serializable : implements
    OneBomb ..|> Serializable : implements
    ImageServlet_Bomb --|> HttpServlet : extends

    note for Bombs "Manages dynamic bomb collection\nPlayer bombs move up\nEnemy bombs move down"
    
    note for OneBomb "Individual bomb entity\nfromPlayer=true: moves up\nfromPlayer=false: moves down"
```

### Collision Service

```mermaid
classDiagram
    class Collision {
        -Logger LOGGER$
        -Client REST_CLIENT$
        -String[] SERVICE_URLS$
        +position() String
        +run() void
        +destroy(int id) void
        +move(String key) void
        +hasEnded() String
        -findRest(String typeName) String
        -callRest(String url) String
    }

    class Client {
        <<JAX-RS>>
    }

    class Logger {
        <<java.util.logging>>
    }

    Collision --> Client : uses
    Collision --> Logger : uses

    note for Collision "Stateless collision detection\nCompares all entity positions\nCoordinates destruction\nNo state storage"
```

---

## Entity Relationship Diagram

```mermaid
erDiagram
    PLAYER ||--|| PLAYER_VALUES : has
    ENEMIES ||--|| ENEMIES_VALUES : has
    BOMBS ||--|| BOMBS_VALUES : has
    
    ENEMIES_VALUES ||--o{ ONE_TIE : contains
    BOMBS_VALUES ||--o{ ONE_BOMB : contains
    
    PLAYER_VALUES {
        int x
        int y
        boolean destroyed
        byte_array image
        byte_array blank
    }
    
    ENEMIES_VALUES {
        OneTie_array ties
        byte_array image
        byte_array blank
    }
    
    BOMBS_VALUES {
        List bombs
        byte_array imageup
        byte_array imagedown
        byte_array blank
        boolean hasFinished
    }
    
    ONE_TIE {
        int id
        int x
        int y
        boolean destroyed
    }
    
    ONE_BOMB {
        int id
        int x
        int y
        boolean fromPlayer
        boolean destroyed
    }
    
    SERVLET_CONTEXT ||--o{ PLAYER_VALUES : stores
    SERVLET_CONTEXT ||--o{ ENEMIES_VALUES : stores
    SERVLET_CONTEXT ||--o{ BOMBS_VALUES : stores
```

---

## Class Responsibilities

### Service Classes (JAX-RS Resources)

#### Space
**Responsibility**: API Gateway and Game Orchestrator
- Aggregates position data from all services
- Coordinates game loop execution
- Generates random enemy bombs
- Routes commands to appropriate services
- Manages CORS headers

**Key Methods**:
- `position()`: Aggregates all entity positions
- `run()`: Executes game loop across all services
- `createBomb()`: Creates new bomb entities
- `isFinished()`: Checks game end conditions

#### Player
**Responsibility**: Player Entity Management
- Manages single player position
- Handles movement commands (left/right)
- Tracks player destruction state
- Provides player sprite image

**Key Methods**:
- `position()`: Returns player position
- `move(int key)`: Processes movement input
- `destroy()`: Marks player as destroyed
- `hasEnded()`: Returns destruction status

#### Enemies
**Responsibility**: Enemy Formation Management
- Manages 40 enemy entities in formation
- Implements formation movement logic
- Tracks individual enemy states
- Provides enemy sprite images

**Key Methods**:
- `position()`: Returns all enemy positions
- `run()`: Updates enemy formation
- `destroy(int id)`: Destroys specific enemy
- `hasEnded()`: Checks if all enemies destroyed

#### Bombs
**Responsibility**: Bomb Entity Management
- Manages dynamic collection of bombs
- Handles bomb creation and movement
- Tracks bomb states (player vs enemy)
- Provides bomb sprite images

**Key Methods**:
- `position()`: Returns all bomb positions
- `run()`: Updates bomb positions
- `create()`: Creates new bomb
- `destroy(int id)`: Destroys specific bomb

#### Collision
**Responsibility**: Collision Detection Logic
- Stateless collision detection
- Compares all entity positions
- Coordinates entity destruction
- No state management

**Key Methods**:
- `run()`: Executes collision detection algorithm
- `findRest()`: Locates service by entity type
- `callRest()`: Makes REST calls to services

---

### State Classes (Value Objects)

#### PlayerValues
**Responsibility**: Player State Storage
- Stores player position (x: 0-19, y: 19)
- Tracks destruction state
- Caches player sprite image
- Serializable for session storage

#### EnemiesValues
**Responsibility**: Enemy Collection State
- Contains array of 40 OneTie entities
- Initializes enemy formation
- Caches enemy sprite image
- Provides game completion check

#### BombsValues
**Responsibility**: Bomb Collection State
- Contains dynamic list of bombs
- Caches bomb sprite images (up/down)
- Tracks game finished state
- Manages bomb lifecycle

---

### Entity Classes

#### OneTie
**Responsibility**: Individual Enemy Entity
- Represents single enemy
- Stores position and state
- ID determines initial position (0-39)
- Serializable entity

#### OneBomb
**Responsibility**: Individual Bomb Entity
- Represents single bomb
- Stores position and direction
- fromPlayer flag determines movement
- Serializable entity

---

### Servlet Classes

#### ImageServlet (Player/Enemy/Bomb/Space)
**Responsibility**: Sprite Image Serving
- Loads PNG images from resources
- Caches images in state objects
- Serves images via HTTP
- Handles GET/POST requests

---

### Utility Classes

#### GameConstants
**Responsibility**: Game Configuration
- Defines grid boundaries
- Bomb spawn probability
- Coordinate limits
- Centralized configuration

---

## Design Patterns Used

### 1. API Gateway Pattern
**Class**: `Space`
- Single entry point for client
- Aggregates multiple service calls
- Simplifies client interaction

### 2. Value Object Pattern
**Classes**: `PlayerValues`, `EnemiesValues`, `BombsValues`
- Immutable-like state objects
- Serializable for storage
- Encapsulate related data

### 3. Entity Pattern
**Classes**: `OneTie`, `OneBomb`
- Represent domain entities
- Have identity (id field)
- Mutable state

### 4. Singleton Pattern
**Fields**: `REST_CLIENT`, `RANDOM`, `LOGGER`
- Static final instances
- Shared across requests
- Resource efficiency

### 5. Repository Pattern (Implicit)
**Methods**: `getValues()`, `resetValues()`
- Abstract state storage
- ServletContext as storage
- Consistent access pattern

### 6. Facade Pattern
**Class**: `Space`
- Simplifies complex subsystem
- Unified interface
- Hides service complexity

---

## Class Relationships Summary

### Composition (Strong Ownership)
- `EnemiesValues` **contains** 40 `OneTie` objects
- `BombsValues` **contains** List of `OneBomb` objects

### Association (Uses)
- `Space` **uses** `GameConstants`
- `Player` **manages** `PlayerValues`
- `Enemies` **manages** `EnemiesValues`
- `Bombs` **manages** `BombsValues`

### Dependency (Calls)
- `Space` **calls** `Player`, `Enemies`, `Bombs`, `Collision`
- `Collision` **calls** `Player`, `Enemies`, `Bombs`
- `ImageServlet` **retrieves** corresponding Values objects

### Implementation
- All Values and Entity classes **implement** `Serializable`
- All ImageServlet classes **extend** `HttpServlet`

---

## State Management Architecture

```mermaid
graph TB
    subgraph "ServletContext Storage"
        SC[ServletContext]
    end
    
    subgraph "Service Layer"
        P[Player Service]
        E[Enemies Service]
        B[Bombs Service]
    end
    
    subgraph "State Objects"
        PV[PlayerValues]
        EV[EnemiesValues]
        BV[BombsValues]
    end
    
    subgraph "Entity Objects"
        OT[OneTie x40]
        OB[OneBomb xN]
    end
    
    P -->|stores/retrieves| SC
    E -->|stores/retrieves| SC
    B -->|stores/retrieves| SC
    
    SC -->|contains| PV
    SC -->|contains| EV
    SC -->|contains| BV
    
    EV -->|owns| OT
    BV -->|owns| OB
    
    style SC fill:#fce4ec
    style P fill:#e8f5e9
    style E fill:#e8f5e9
    style B fill:#e8f5e9
    style PV fill:#fff4e1
    style EV fill:#fff4e1
    style BV fill:#fff4e1
```

---

## Thread Safety Considerations

### ServletContext Access
- **Shared State**: All state objects stored in ServletContext
- **Concurrent Access**: Multiple requests can access simultaneously
- **No Synchronization**: Current implementation not thread-safe
- **Risk**: Race conditions in state updates

### Recommendations
1. Add synchronization to state access methods
2. Use concurrent collections for bomb lists
3. Consider atomic operations for position updates
4. Implement optimistic locking for collision detection

---

## Memory Management

### State Object Lifecycle
1. **Creation**: On first request to service
2. **Storage**: In ServletContext (in-memory)
3. **Persistence**: None (lost on restart)
4. **Cleanup**: On application shutdown

### Image Caching
- Images loaded once per service
- Cached in state objects
- Reduces file I/O
- Memory trade-off for performance

---

## Extensibility Points

### Adding New Entity Types
1. Create new Entity class (e.g., `PowerUp`)
2. Create Values class (e.g., `PowerUpValues`)
3. Create Service class with JAX-RS endpoints
4. Create ImageServlet for sprites
5. Register in `Space` SERVICE_URLS
6. Update `Collision` logic if needed

### Adding New Game Mechanics
1. Extend entity classes with new properties
2. Add methods to service classes
3. Update collision detection logic
4. Modify client-side rendering

---

## Conclusion

The MicroInvader class structure demonstrates a clean separation between:
- **Service Layer**: JAX-RS resources handling HTTP requests
- **State Layer**: Value objects managing game state
- **Entity Layer**: Domain objects representing game entities
- **Presentation Layer**: Servlets serving sprite images

The architecture uses composition for entity collections, dependency injection for context, and the API Gateway pattern for service orchestration. While the current implementation is suitable for learning, production use would require thread-safety improvements and state persistence.

---

## Related Documentation

- [`MICROINVADER_ARCHITECTURE.md`](MICROINVADER_ARCHITECTURE.md:1) - System architecture overview
- [`CODE_IMPROVEMENTS_DETAILED.md`](CODE_IMPROVEMENTS_DETAILED.md:1) - Code improvement recommendations
- [`CODE_IMPROVEMENT_PLAN.md`](CODE_IMPROVEMENT_PLAN.md:1) - Improvement planning