package com.ibm.space.player;

import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.json.Json;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;


@Path("/")
public class Player {
	
	private static final Logger LOGGER = Logger.getLogger(Player.class.getName());
	private static final int GRID_SIZE = 20;
	private static final int GRID_MAX = 19;
	private static final int KEY_RESET = 48;      // '0' key
	private static final int KEY_MOVE_LEFT = 111; // 'o' key
	private static final int KEY_MOVE_RIGHT = 112; // 'p' key
	
	@Context
	private ServletContext context;
 
    @GET
 @Path("/position")
    @Produces("application/json")
 public Response position(@Context HttpServletRequest request) {
  try {
   JsonArrayBuilder arr = Json.createArrayBuilder();
   PlayerValues values = getValues();
   
   if (values != null) {
    JsonObject obj = Json.createObjectBuilder()
    	.add("type", "player")
    	.add("x", values.getX())
    	.add("y", values.getY())
    	.add("destroyed", values.isDestroyed())
    	.add("id", 0)
    	.add("ip", "http://" + request.getLocalAddr() + ":" + request.getLocalPort())
    	.build();
    arr.add(obj);
   }
   return Response.ok(arr.build()).build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error getting player position", e);
   return Response.serverError()
    .entity(Json.createObjectBuilder()
    	.add("error", "Failed to retrieve position")
    	.build())
    .build();
  }
    }
    
    @GET
 @Path("/run")
    public Response run() {
  // Player doesn't auto-move, so this is a no-op
    	return Response.ok().build();
    }

    @GET
    @Path("/destroy/0")
    public Response destroy() {
  try {
   PlayerValues values = getValues();
   if (values != null) {
    values.setDestroyed(true);
    LOGGER.info("Player destroyed");
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error destroying player", e);
   return Response.serverError().build();
  }
    }
    
    @GET
 @Path("/move/{key}")
 public Response move(@PathParam("key") int key) {
  try {
   PlayerValues values = getValues();
   if (values == null) {
    return Response.serverError().build();
   }
   
   if (key == KEY_RESET) {
    resetValues();
    LOGGER.info("Player values reset");
   } else if (key == KEY_MOVE_LEFT) {
    // Move left with boundary check
    if (values.getX() > 0) {
    	values.setX(values.getX() - 1);
    	LOGGER.log(Level.FINE, "Player moved left to x={0}", values.getX());
    }
   } else if (key == KEY_MOVE_RIGHT) {
    // Move right with boundary check
    if (values.getX() < GRID_MAX) {
    	values.setX(values.getX() + 1);
    	LOGGER.log(Level.FINE, "Player moved right to x={0}", values.getX());
    }
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error processing player move: " + key, e);
   return Response.serverError().build();
  }
 }
 
    @GET
 @Path("/isFinished")
    @Produces("application/json")
    public Response hasEnded() {
  try {
   PlayerValues values = getValues();
   boolean finished = (values != null && values.isDestroyed());
   return Response.ok(
    Json.createObjectBuilder()
    	.add("finished", finished)
    	.build()
   ).build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error checking player status", e);
   return Response.serverError().build();
  }
    }
   
	private PlayerValues getValues()
	{
		if (context != null) {
			if (context.getAttribute(PlayerValues.class.getSimpleName()) == null) {
				PlayerValues values = new PlayerValues();
				context.setAttribute(PlayerValues.class.getSimpleName(), values);			
			}
			return (PlayerValues) context.getAttribute(PlayerValues.class.getSimpleName());
		}
		else {
			return null;
		}
	}
	private void resetValues()
	{
		PlayerValues values = new PlayerValues();
		context.setAttribute(PlayerValues.class.getSimpleName(), values);
	}
	
}
