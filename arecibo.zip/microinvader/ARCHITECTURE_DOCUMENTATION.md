# MicroInvader Application Architecture

## Table of Contents
1. [Overview](#overview)
2. [Architecture Style](#architecture-style)
3. [System Components](#system-components)
4. [Communication Patterns](#communication-patterns)
5. [Data Flow](#data-flow)
6. [Deployment Architecture](#deployment-architecture)
7. [Technology Stack](#technology-stack)
8. [Design Patterns](#design-patterns)

---

## 1. Overview

MicroInvader is a **microservices-based Space Invaders game** that demonstrates distributed system architecture using Java EE/Jakarta EE technologies. The application splits game logic into independent, loosely-coupled services that communicate via REST APIs.

### Key Characteristics
- **Architecture**: Microservices
- **Communication**: Synchronous REST (HTTP/JSON)
- **Deployment**: Single Liberty server with multiple WAR files
- **State Management**: In-memory (ServletContext)
- **Frontend**: Single-page application (AngularJS)

---

## 2. Architecture Style

### 2.1 Microservices Architecture

```mermaid
graph TB
    Client[Web Browser<br/>AngularJS SPA]
    
    subgraph "Liberty Application Server"
        Space[Space Service<br/>Orchestrator]
        Player[Player Service<br/>Player Management]
        Enemy[Enemy Service<br/>Enemy Management]
        Bomb[Bomb Service<br/>Projectile Management]
        Collision[Collision Service<br/>Collision Detection]
    end
    
    Client -->|HTTP/JSON| Space
    Space -->|REST API| Player
    Space -->|REST API| Enemy
    Space -->|REST API| Bomb
    Space -->|REST API| Collision
    Collision -->|REST API| Player
    Collision -->|REST API| Enemy
    Collision -->|REST API| Bomb
```

### 2.2 Service Responsibilities

| Service | Responsibility | State |
|---------|---------------|-------|
| **Space** | Game orchestration, coordination | Stateless |
| **Player** | Player position, movement, lifecycle | Stateful |
| **Enemy** | Enemy fleet position, movement, lifecycle | Stateful |
| **Bomb** | Projectile creation, movement, lifecycle | Stateful |
| **Collision** | Detect and resolve entity collisions | Stateless |

---

## 3. System Components

### 3.1 Space Service (Orchestrator)

**Location**: [`space/src/main/java/com/ibm/space/space/Space.java`](space/src/main/java/com/ibm/space/space/Space.java)

**Purpose**: Central coordinator that orchestrates game flow and aggregates data from all services.

**Key Responsibilities**:
- Aggregate positions from all services
- Coordinate game loop execution
- Generate enemy bombs randomly
- Forward user commands to appropriate services
- Determine game end conditions

**API Endpoints**:
```
GET  /space-1.0/rest/position      - Get all entity positions
GET  /space-1.0/rest/run           - Execute game tick
GET  /space-1.0/rest/move/{key}    - Process keyboard input
GET  /space-1.0/rest/create/{x}/{y}/{fromPlayer} - Create bomb
GET  /space-1.0/rest/destroy/{id}  - Destroy entity
GET  /space-1.0/rest/isFinished    - Check game status
```

**Architecture Pattern**: **Orchestrator/Aggregator Pattern**

```mermaid
sequenceDiagram
    participant Client
    participant Space
    participant Player
    participant Enemy
    participant Bomb
    participant Collision
    
    Client->>Space: GET /position
    Space->>Player: GET /position
    Space->>Enemy: GET /position
    Space->>Bomb: GET /position
    Space->>Collision: GET /position
    Player-->>Space: Player data
    Enemy-->>Space: Enemy data
    Bomb-->>Space: Bomb data
    Collision-->>Space: Empty array
    Space-->>Client: Aggregated JSON
```

### 3.2 Player Service

**Location**: [`player/src/main/java/com/ibm/space/player/Player.java`](player/src/main/java/com/ibm/space/player/Player.java)

**Purpose**: Manages the player's spaceship (X-Wing).

**State Management**:
- Position: (x: 0-19, y: 19 - fixed)
- Destroyed flag
- Stored in ServletContext

**Key Logic**:
```java
// Movement boundaries
if (key == 111 && x > 0)  x--;  // 'o' key - move left
if (key == 112 && x < 19) x++;  // 'p' key - move right
```

**API Endpoints**:
```
GET  /player-1.0/position          - Get player position
GET  /player-1.0/run               - No-op (player doesn't auto-move)
GET  /player-1.0/move/{key}        - Move left/right or reset
GET  /player-1.0/destroy/0         - Destroy player
GET  /player-1.0/isFinished        - Check if player destroyed
```

### 3.3 Enemy Service

**Location**: [`enemy/src/main/java/com/ibm/space/enemies/Enemies.java`](enemy/src/main/java/com/ibm/space/enemies/Enemies.java)

**Purpose**: Manages the enemy fleet (TIE Fighters).

**State Management**:
- 40 enemies in 4 rows × 10 columns
- Each enemy: (id, x, y, destroyed)
- Movement pattern: right → down → left → down → repeat

**Movement Algorithm**:
```java
if (x0 <= 9) {
    incrementAllX();  // Move right
} else {
    returnAllXtoBegin();  // Reset to left
    if (y0 <= 15) {
        incrementAllY();  // Move down
    } else {
        destroyAllEnemies();  // Reached bottom - game over
    }
}
```

**API Endpoints**:
```
GET  /enemy-1.0/position           - Get all enemy positions
GET  /enemy-1.0/run                - Execute enemy movement
GET  /enemy-1.0/move/{key}         - Reset on key '0'
GET  /enemy-1.0/destroy/{id}       - Destroy specific enemy
GET  /enemy-1.0/isFinished         - Check if all enemies destroyed
```

### 3.4 Bomb Service

**Location**: [`bomb/src/main/java/com/ibm/space/bombs/Bombs.java`](bomb/src/main/java/com/ibm/space/bombs/Bombs.java)

**Purpose**: Manages all projectiles (bombs/lasers) from both player and enemies.

**State Management**:
- Dynamic list of bombs (Vector)
- Each bomb: (id, x, y, fromPlayer, destroyed)

**Movement Logic**:
```java
if (fromPlayer) {
    y--;  // Move up
    if (y <= 0) destroyed = true;
} else {
    y++;  // Move down
    if (y >= 20) destroyed = true;
}
```

**API Endpoints**:
```
GET  /bomb-1.0/position            - Get all bomb positions
GET  /bomb-1.0/run                 - Update bomb positions
GET  /bomb-1.0/create/{x}/{y}/{fromPlayer} - Create new bomb
GET  /bomb-1.0/destroy/{id}        - Destroy specific bomb
GET  /bomb-1.0/move/{key}          - Reset on key '0'
GET  /bomb-1.0/isFinished          - Always returns false
```

### 3.5 Collision Service

**Location**: [`collision/src/main/java/com/ibm/space/collision/Collision.java`](collision/src/main/java/com/ibm/space/collision/Collision.java)

**Purpose**: Detects and resolves collisions between entities.

**Collision Detection Algorithm**:
```java
1. Fetch all entity positions from all services
2. Compare each entity pair (i, j where j > i)
3. If same position AND different IDs AND both not destroyed:
   - Mark both as destroyed
   - Call destroy endpoint on respective services
```

**Collision Rules**:
- Bomb vs Enemy → Both destroyed
- Bomb vs Player → Both destroyed
- Bomb vs Bomb → Both destroyed
- Player vs Enemy → Both destroyed

**API Endpoints**:
```
GET  /collision-1.0/position       - Returns empty array
GET  /collision-1.0/run            - Execute collision detection
GET  /collision-1.0/destroy/{id}   - No-op
GET  /collision-1.0/move/{key}     - No-op
GET  /collision-1.0/isFinished     - Always returns false
```

---

## 4. Communication Patterns

### 4.1 Request Flow

```mermaid
sequenceDiagram
    participant Browser
    participant Space
    participant Services
    
    Note over Browser: Game Loop (400ms interval)
    
    Browser->>Space: GET /rest/run
    Space->>Services: GET /run (all services)
    Services-->>Space: OK
    Space->>Space: Generate enemy bombs (30% chance)
    Space-->>Browser: OK
    
    Browser->>Space: GET /rest/position
    Space->>Services: GET /position (all services)
    Services-->>Space: JSON arrays
    Space->>Space: Aggregate all positions
    Space-->>Browser: Combined JSON array
    
    Browser->>Browser: Update UI grid
```

### 4.2 User Input Flow

```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant Space
    participant Player
    participant Bomb
    
    User->>Browser: Press 'o' (left)
    Browser->>Space: GET /rest/move/111
    Space->>Player: GET /move/111
    Player->>Player: x = x - 1
    Player-->>Space: OK
    Space-->>Browser: OK
    
    User->>Browser: Press Space (shoot)
    Browser->>Browser: Find player position
    Browser->>Space: GET /rest/create/x/y/true
    Space->>Bomb: GET /create/x/y/true
    Bomb->>Bomb: Add new bomb
    Bomb-->>Space: OK
    Space-->>Browser: OK
```

### 4.3 Collision Detection Flow

```mermaid
sequenceDiagram
    participant Space
    participant Collision
    participant Enemy
    participant Bomb
    
    Space->>Collision: GET /run
    Collision->>Enemy: GET /position
    Collision->>Bomb: GET /position
    Enemy-->>Collision: Enemy positions
    Bomb-->>Collision: Bomb positions
    
    Collision->>Collision: Detect collision at (5,3)
    
    Collision->>Enemy: GET /destroy/12
    Collision->>Bomb: GET /destroy/456
    
    Enemy->>Enemy: Mark enemy 12 destroyed
    Bomb->>Bomb: Mark bomb 456 destroyed
    
    Enemy-->>Collision: OK
    Bomb-->>Collision: OK
    Collision-->>Space: OK
```

---

## 5. Data Flow

### 5.1 Game State

```mermaid
stateDiagram-v2
    [*] --> GameStart
    GameStart --> Running: Initialize
    
    Running --> Running: Game Loop
    Running --> PlayerWins: All enemies destroyed
    Running --> PlayerLoses: Player destroyed
    Running --> PlayerLoses: Enemies reach bottom
    
    PlayerWins --> GameStart: Reset (key '0')
    PlayerLoses --> GameStart: Reset (key '0')
    
    PlayerWins --> [*]
    PlayerLoses --> [*]
```

### 5.2 Entity Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Created
    Created --> Active: Spawn
    Active --> Active: Update position
    Active --> Destroyed: Collision
    Active --> Destroyed: Out of bounds
    Destroyed --> [*]
```

### 5.3 Data Model

**Player Entity**:
```json
{
  "type": "player",
  "id": 0,
  "x": 10,
  "y": 19,
  "destroyed": false,
  "ip": "http://127.0.0.1:9081"
}
```

**Enemy Entity**:
```json
{
  "type": "enemy",
  "id": 15,
  "x": 7,
  "y": 2,
  "destroyed": false,
  "ip": "http://127.0.0.1:9081"
}
```

**Bomb Entity**:
```json
{
  "type": "bomb",
  "id": 1234567,
  "x": 10,
  "y": 15,
  "up": true,
  "destroyed": false,
  "ip": "http://127.0.0.1:9081"
}
```

---

## 6. Deployment Architecture

### 6.1 Current Deployment (Monolithic Liberty)

```mermaid
graph TB
    subgraph "Liberty Server :9081"
        subgraph "Dropins Directory"
            SpaceWAR[space-1.0.war]
            PlayerWAR[player-1.0.war]
            EnemyWAR[enemy-1.0.war]
            BombWAR[bomb-1.0.war]
            CollisionWAR[collision-1.0.war]
        end
        
        subgraph "Runtime"
            SpaceApp[Space App Context]
            PlayerApp[Player App Context]
            EnemyApp[Enemy App Context]
            BombApp[Bomb App Context]
            CollisionApp[Collision App Context]
        end
    end
    
    Browser[Web Browser] -->|:9081/space-1.0| SpaceApp
    
    SpaceWAR --> SpaceApp
    PlayerWAR --> PlayerApp
    EnemyWAR --> EnemyApp
    BombWAR --> BombApp
    CollisionWAR --> CollisionApp
```

**Characteristics**:
- All services in single JVM
- Shared Liberty server
- In-process communication (still via HTTP)
- Single deployment unit

### 6.2 Recommended Deployment (True Microservices)

```mermaid
graph TB
    LB[Load Balancer]
    Browser[Web Browser]
    
    subgraph "Container Orchestration - Kubernetes"
        subgraph "Space Pod"
            SpaceContainer[Space Service<br/>:8080]
        end
        
        subgraph "Player Pod"
            PlayerContainer[Player Service<br/>:8080]
        end
        
        subgraph "Enemy Pod"
            EnemyContainer[Enemy Service<br/>:8080]
        end
        
        subgraph "Bomb Pod"
            BombContainer[Bomb Service<br/>:8080]
        end
        
        subgraph "Collision Pod"
            CollisionContainer[Collision Service<br/>:8080]
        end
        
        subgraph "Data Layer"
            Redis[(Redis<br/>Shared State)]
        end
    end
    
    Browser --> LB
    LB --> SpaceContainer
    
    SpaceContainer --> PlayerContainer
    SpaceContainer --> EnemyContainer
    SpaceContainer --> BombContainer
    SpaceContainer --> CollisionContainer
    
    CollisionContainer --> PlayerContainer
    CollisionContainer --> EnemyContainer
    CollisionContainer --> BombContainer
    
    PlayerContainer -.-> Redis
    EnemyContainer -.-> Redis
    BombContainer -.-> Redis
```

---

## 7. Technology Stack

### 7.1 Current Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Language** | Java | 8 |
| **Application Server** | IBM Liberty | 22.0.0.10 |
| **Java EE Profile** | Web Profile | 7 |
| **REST Framework** | JAX-RS | 2.0 |
| **JSON Processing** | JSON-P | 1.0 |
| **Servlet** | Servlet API | 3.1 |
| **Build Tool** | Maven | 3.x |
| **Frontend Framework** | AngularJS | 1.x |
| **HTTP Client** | Apache CXF | 3.1.1 |

### 7.2 Recommended Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Language** | Java | 17 LTS |
| **Application Server** | Open Liberty | 23.x |
| **Jakarta EE** | Jakarta EE | 10 |
| **REST Framework** | JAX-RS | 3.1 |
| **JSON Processing** | JSON-P/JSON-B | 2.1 |
| **Servlet** | Jakarta Servlet | 6.0 |
| **MicroProfile** | MicroProfile | 6.0 |
| **Build Tool** | Maven | 3.9.x |
| **Frontend** | React/Vue | Latest |
| **Containerization** | Docker | Latest |
| **Orchestration** | Kubernetes | 1.28+ |

---

## 8. Design Patterns

### 8.1 Architectural Patterns

#### Microservices Pattern
- **Implementation**: Each game component is an independent service
- **Benefits**: Separation of concerns, independent deployment
- **Challenges**: Distributed state, network latency

#### Orchestrator Pattern
- **Implementation**: Space service coordinates all other services
- **Location**: [`Space.java`](space/src/main/java/com/ibm/space/space/Space.java)
- **Benefits**: Centralized control, simplified client
- **Challenges**: Single point of failure, orchestrator complexity

#### API Gateway Pattern
- **Implementation**: Space service acts as gateway for frontend
- **Benefits**: Single entry point, simplified client
- **Challenges**: Gateway becomes bottleneck

### 8.2 Code Patterns

#### Singleton Pattern (ServletContext State)
```java
private BombsValues getValues() {
    if (context.getAttribute(KEY) == null) {
        context.setAttribute(KEY, new BombsValues());
    }
    return (BombsValues) context.getAttribute(KEY);
}
```

#### Repository Pattern (Implicit)
- Each service manages its own data
- ServletContext acts as in-memory repository

#### Service Locator Pattern
```java
// Hardcoded service URLs
public static String[] urls = {
    "http://127.0.0.1:9081/enemy-1.0/",
    "http://127.0.0.1:9081/player-1.0/",
    // ...
};
```

### 8.3 Anti-Patterns Present

⚠️ **Distributed Monolith**
- Services deployed together
- Tight coupling through synchronous calls
- Shared deployment lifecycle

⚠️ **Hardcoded Configuration**
- Service URLs hardcoded
- No service discovery
- Difficult to scale

⚠️ **Synchronous Communication**
- Blocking REST calls
- No circuit breakers
- No fallback mechanisms

⚠️ **In-Memory State**
- State lost on restart
- Not horizontally scalable
- No persistence

---

## 9. Game Flow Architecture

### 9.1 Game Loop

```mermaid
graph LR
    A[Browser Timer<br/>400ms] --> B[Call /rest/run]
    B --> C[Update Positions]
    C --> D[Detect Collisions]
    D --> E[Call /rest/position]
    E --> F[Render Grid]
    F --> A
```

### 9.2 Grid System

**Grid Dimensions**: 20×20 cells (0-19 for both x and y)

```
     0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19
  0  [                    ENEMIES                              ]
  1  [                    ENEMIES                              ]
  2  [                    ENEMIES                              ]
  3  [                    ENEMIES                              ]
  4  [                                                          ]
  5  [                                                          ]
  6  [                                                          ]
  7  [                                                          ]
  8  [                                                          ]
  9  [                                                          ]
 10  [                                                          ]
 11  [                                                          ]
 12  [                                                          ]
 13  [                                                          ]
 14  [                                                          ]
 15  [                                                          ]
 16  [                                                          ]
 17  [                                                          ]
 18  [                                                          ]
 19  [                    PLAYER                               ]
```

### 9.3 Rendering Pipeline

```mermaid
sequenceDiagram
    participant Controller
    participant Grid
    participant Services
    
    Controller->>Services: Get all positions
    Services-->>Controller: Entity array
    
    loop For each cell (20x20)
        Controller->>Controller: Find entity at (x,y)
        alt Entity found and not destroyed
            Controller->>Grid: Set image URL
        else No entity
            Controller->>Grid: Set blank image
        end
    end
    
    Grid->>Grid: Render HTML table
```

---

## 10. Scalability Considerations

### 10.1 Current Limitations

| Aspect | Limitation | Impact |
|--------|-----------|--------|
| **State** | In-memory only | Lost on restart |
| **Scaling** | Single instance | No horizontal scaling |
| **Performance** | Synchronous calls | Blocking, slow |
| **Resilience** | No fault tolerance | Single point of failure |
| **Deployment** | Monolithic | All-or-nothing deployment |

### 10.2 Recommended Improvements

```mermaid
graph TB
    subgraph "Improved Architecture"
        API[API Gateway<br/>+ Load Balancer]
        
        subgraph "Service Mesh"
            S1[Space Service<br/>Replicas: 3]
            S2[Player Service<br/>Replicas: 2]
            S3[Enemy Service<br/>Replicas: 2]
            S4[Bomb Service<br/>Replicas: 2]
            S5[Collision Service<br/>Replicas: 2]
        end
        
        subgraph "Data Layer"
            Redis[(Redis Cluster<br/>Shared State)]
            Kafka[Kafka<br/>Event Stream]
        end
        
        subgraph "Observability"
            Prometheus[Prometheus<br/>Metrics]
            Jaeger[Jaeger<br/>Tracing]
            ELK[ELK Stack<br/>Logging]
        end
    end
    
    API --> S1
    S1 --> S2
    S1 --> S3
    S1 --> S4
    S1 --> S5
    
    S2 -.-> Redis
    S3 -.-> Redis
    S4 -.-> Redis
    
    S1 --> Kafka
    S2 --> Kafka
    S3 --> Kafka
    
    S1 --> Prometheus
    S1 --> Jaeger
    S1 --> ELK
```

---

## 11. Security Architecture

### 11.1 Current Security Posture

**Strengths**:
- ✅ CORS headers configured
- ✅ No sensitive data exposure

**Weaknesses**:
- ❌ No authentication/authorization
- ❌ No input validation
- ❌ No rate limiting
- ❌ Outdated dependencies with CVEs
- ❌ No HTTPS enforcement

### 11.2 Recommended Security Layers

```mermaid
graph TB
    Client[Client]
    
    subgraph "Security Layers"
        WAF[Web Application Firewall]
        Auth[Authentication<br/>OAuth2/JWT]
        Gateway[API Gateway<br/>Rate Limiting]
        
        subgraph "Services"
            Service[Microservices<br/>Input Validation]
        end
        
        Secrets[Secret Management<br/>Vault]
    end
    
    Client --> WAF
    WAF --> Auth
    Auth --> Gateway
    Gateway --> Service
    Service -.-> Secrets
```

---

## 12. Summary

### Architecture Strengths
✅ Clear separation of concerns  
✅ RESTful API design  
✅ Microservices foundation  
✅ Simple and understandable  

### Architecture Weaknesses
❌ Distributed monolith (not true microservices)  
❌ No service discovery  
❌ Synchronous communication only  
❌ In-memory state (not persistent)  
❌ No fault tolerance  
❌ Limited scalability  

### Recommended Evolution Path

1. **Phase 1**: Modernize to Jakarta EE 10 + Java 17
2. **Phase 2**: Add service discovery (Consul/Eureka)
3. **Phase 3**: Implement distributed state (Redis)
4. **Phase 4**: Add async messaging (Kafka)
5. **Phase 5**: Containerize with Docker
6. **Phase 6**: Deploy to Kubernetes
7. **Phase 7**: Add observability (metrics, tracing, logging)
8. **Phase 8**: Implement circuit breakers and resilience

This architecture documentation provides a comprehensive understanding of the MicroInvader application's design, components, and communication patterns, along with recommendations for improvement and modernization.