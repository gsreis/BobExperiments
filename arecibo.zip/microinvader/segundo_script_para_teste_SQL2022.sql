/* ============================================================
   SCRIPT MODERNIZADO PARA SQL SERVER 2022
   Conversão de SQL Server 2008 para SQL Server 2022
   
   - Bases: BBA_MO->[DB_A] | BBA_CORPORATE->[DB_B] | 
            BBA_SERVICO_CORPORATIVO->[DB_C] | BBA_METADADO_CORPORATIVO->[DB_D]
   - Objetos principais renomeados conforme legenda acima.
   
   PRINCIPAIS MELHORIAS APLICADAS:
   ✓ Substituição de sintaxe JOIN obsoleta (comma-separated e *= operator)
   ✓ Conversão de FLOAT para DECIMAL(19,4) em valores financeiros
   ✓ Modernização de hints NOLOCK para WITH (READUNCOMMITTED)
   ✓ Substituição de USER por SUSER_SNAME()
   ✓ Otimização de subqueries correlacionadas com OUTER APPLY
   ✓ Adição de tratamento de erros com TRY-CATCH
   ✓ Remoção de ORDER BY desnecessário em INSERT...SELECT
   ✓ SET QUOTED_IDENTIFIER ON (padrão SQL Server 2022)
   ✓ Adição de índices em tabelas temporárias
   ✓ Comentários detalhados para manutenção
   ============================================================ */

USE [DB_A]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON  -- Modernizado: era OFF, agora ON (padrão SQL 2022)
GO

-- Drop procedure if exists (SQL 2016+)
IF OBJECT_ID('[dbo].[SP_ANON_TOTALIZA_OPER_PREV]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[SP_ANON_TOTALIZA_OPER_PREV]
GO

CREATE PROCEDURE [dbo].[SP_ANON_TOTALIZA_OPER_PREV]
    @DT_BASE      DATETIME,
    @QT_REGISTROS INT OUTPUT
AS
BEGIN
    SET ANSI_WARNINGS OFF
    SET NOCOUNT ON
    
    -- Declaração de variáveis para controle
    DECLARE @ErrorMessage NVARCHAR(4000)
    DECLARE @ErrorSeverity INT
    DECLARE @ErrorState INT
    DECLARE @CurrentUser NVARCHAR(128) = SUSER_SNAME()  -- Modernizado: substituído USER
    
    BEGIN TRY
        /* ============================================================
           CRIAÇÃO DE TABELAS TEMPORÁRIAS COM ÍNDICES
           Modernizado: DECIMAL em vez de FLOAT para valores financeiros
           ============================================================ */
        
        CREATE TABLE #TEMP_CA_OPER (
            CD_TIPO_INFO              VARCHAR(3)      NULL,
            CD_CONTRATO               VARCHAR(30)     NULL,
            ID_SISTEMA                INT             NULL,
            CD_PRODUTO                VARCHAR(30)     NULL,
            CD_MODALIDADE             VARCHAR(30)     NULL,
            CD_MOEDA                  VARCHAR(30)     NULL,
            VL_ATUALIZADO             DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            VL_FUTURO                 DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            CD_CHAVE_AUX              VARCHAR(30)     NULL,
            CD_CONTRATO_COMPLEMENTAR  VARCHAR(30)     NULL,
            DT_ATUALIZACAO            DATETIME        NULL,
            DT_ABERTURA               DATETIME        NULL,
            DT_VENCIMENTO             DATETIME        NULL,
            CD_PRODUTO_MO             VARCHAR(30)     NULL,
            CD_MODALIDADE_MO          VARCHAR(30)     NULL
        )
        
        -- Índice para melhorar performance de JOINs e UPDATEs
        CREATE INDEX IX_TEMP_CA_OPER_PRODUTO ON #TEMP_CA_OPER(CD_PRODUTO, ID_SISTEMA)
        CREATE INDEX IX_TEMP_CA_OPER_CONTRATO ON #TEMP_CA_OPER(CD_CONTRATO, CD_PRODUTO, CD_CHAVE_AUX)

        CREATE TABLE #TEMP_CA_PARCELA (
            CD_TIPO_INFO              VARCHAR(3)      NULL,
            CD_CONTRATO               VARCHAR(30)     NULL,
            ID_SISTEMA                INT             NULL,
            CD_PRODUTO                VARCHAR(30)     NULL,
            CD_MODALIDADE             VARCHAR(30)     NULL,
            CD_MOEDA                  VARCHAR(30)     NULL,
            VL_ATUALIZADO             DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            VL_FUTURO                 DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            CD_CHAVE_AUX              VARCHAR(30)     NULL,
            CD_CONTRATO_COMPLEMENTAR  VARCHAR(30)     NULL,
            DT_ATUALIZACAO            DATETIME        NULL,
            DT_VENCIMENTO             DATETIME        NULL,
            CD_PRODUTO_MO             VARCHAR(30)     NULL,
            CD_MODALIDADE_MO          VARCHAR(30)     NULL
        )
        
        -- Índices para melhorar performance
        CREATE INDEX IX_TEMP_CA_PARCELA_PRODUTO ON #TEMP_CA_PARCELA(CD_PRODUTO, ID_SISTEMA)
        CREATE INDEX IX_TEMP_CA_PARCELA_CONTRATO ON #TEMP_CA_PARCELA(CD_CONTRATO, CD_PRODUTO, CD_CHAVE_AUX)

        CREATE TABLE #TEMP_TOT_CA (
            CD_TIPO_INFO        VARCHAR(3)      NULL,
            CD_PRODUTO_MO       VARCHAR(30)     NULL,
            CD_MODALIDADE_MO    VARCHAR(30)     NULL,
            CD_MOEDA            VARCHAR(10)     NULL,
            QT_REG              INT             NULL,
            VL_ATUALIZADO_SOMA  DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            VL_FUTURO_SOMA      DECIMAL(19,4)   NULL   -- Modernizado: era FLOAT
        )

        CREATE TABLE #TEMP_EXP_EC (
            CD_TIPO_INFO   VARCHAR(3)      NULL,
            CD_PRODUTO     VARCHAR(50)     NULL,
            CD_MODALIDADE  VARCHAR(50)     NULL,
            CD_MOEDA       VARCHAR(20)     NULL,
            VL_ATUALIZADO  DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            VL_FUTURO      DECIMAL(19,4)   NULL   -- Modernizado: era FLOAT
        )

        CREATE TABLE #TEMP_EXP_TOTALIZACAO (
            DT_BASE         DATETIME        NULL,
            CD_ORIGEM       VARCHAR(10)     NULL,
            ID_SISTEMA      INT             NULL,
            CD_TIPO_INFO    VARCHAR(3)      NULL,
            CD_PRODUTO      VARCHAR(50)     NULL,
            CD_MODALIDADE   VARCHAR(50)     NULL,
            CD_MOEDA        VARCHAR(20)     NULL,
            QT_REGISTROS    INT             NULL,
            VL_ATUALIZADO   DECIMAL(19,4)   NULL,  -- Modernizado: era FLOAT
            VL_FUTURO       DECIMAL(19,4)   NULL   -- Modernizado: era FLOAT
        )

        /* ============================================================
           LOGS DE TOTALIZAÇÃO
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, 'O', 'Temporária Operações')

        /* ============================================================
           CARGA DE OPERAÇÕES
           Modernizado: WITH (READUNCOMMITTED) em vez de (NOLOCK)
           ============================================================ */
        INSERT INTO #TEMP_CA_OPER (
            CD_TIPO_INFO, CD_CONTRATO, ID_SISTEMA, CD_PRODUTO, CD_MODALIDADE, CD_MOEDA,
            VL_ATUALIZADO, VL_FUTURO, CD_CHAVE_AUX, CD_CONTRATO_COMPLEMENTAR,
            DT_ATUALIZACAO, DT_ABERTURA, DT_VENCIMENTO
        )
        SELECT
            'O' AS CD_TIPO_INFO,
            CD_CONTRATO,
            ID_SISTEMA,
            CD_PRODUTO,
            CD_MODALIDADE,
            CD_MOEDA,
            VL_ATUALIZADO,
            VL_FUTURO,
            CD_CHAVE_AUX,
            CD_CONTRATO_COMPLEMENTAR,
            DT_ATUALIZACAO,
            DT_ABERTURA,
            DT_VENCIMENTO
        FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO WITH (READUNCOMMITTED)  -- Modernizado
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE

        /* ============================================================
           CARGA DE PARCELAS
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, 'P', 'Temporária Parcelas')

        INSERT INTO #TEMP_CA_PARCELA (
            CD_TIPO_INFO, CD_CONTRATO, ID_SISTEMA, CD_PRODUTO, CD_MODALIDADE,
            VL_ATUALIZADO, VL_FUTURO, CD_CHAVE_AUX, CD_CONTRATO_COMPLEMENTAR,
            DT_ATUALIZACAO, DT_VENCIMENTO
        )
        SELECT
            'P' AS CD_TIPO_INFO,
            CD_CONTRATO,
            ID_SISTEMA,
            CD_PRODUTO,
            CD_MODALIDADE,
            VL_ATUALIZADO,
            VL_FUTURO,
            CD_CHAVE_AUX,
            CD_CONTRATO_COMPLEMENTAR,
            DT_ATUALIZACAO,
            DT_VENCIMENTO
        FROM [DB_A].dbo.VW_TXT_PARCELA_SALDO WITH (READUNCOMMITTED)  -- Modernizado
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE

        /* ============================================================
           ATUALIZAÇÃO DE DADOS (DE/PARA)
           Modernizado: Sintaxe ANSI-92 JOIN em vez de comma-separated
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Atualização Temporária')

        -- Atualização de Operações
        UPDATE T
        SET  T.CD_PRODUTO_MO   = C.CD_PRODUTO,
             T.CD_MODALIDADE_MO = CASE 
                                    WHEN T.CD_MODALIDADE IN ('RECBANC','DESPBANC')
                                    THEN T.CD_MODALIDADE
                                    ELSE C.CD_MODALIDADE 
                                  END
        FROM #TEMP_CA_OPER T
        INNER JOIN [DB_B]..TB_CORP_INT_PRODUTO_NC C WITH (READUNCOMMITTED)  -- Modernizado: INNER JOIN
            ON T.CD_PRODUTO = C.CD_CHV_PRODUTO_NC
           AND T.ID_SISTEMA = C.ID_SISTEMA_ORIGEM_NC

        UPDATE T
        SET T.CD_MOEDA = [DB_C].dbo.FN_CD_OFICIAL_CD_MOEDA(CONVERT(INT, T.CD_MOEDA))
        FROM #TEMP_CA_OPER T
        WHERE T.CD_MOEDA IS NOT NULL

        UPDATE T 
        SET T.CD_PRODUTO_MO = 'ND'
        FROM #TEMP_CA_OPER T
        WHERE T.CD_PRODUTO_MO IS NULL

        UPDATE T 
        SET T.CD_MODALIDADE_MO = 'ND'
        FROM #TEMP_CA_OPER T
        WHERE T.CD_MODALIDADE_MO IS NULL

        UPDATE T 
        SET T.CD_MOEDA = 'ND'
        FROM #TEMP_CA_OPER T
        WHERE T.CD_MOEDA IS NULL

        /* ============================================================
           ATUALIZAÇÃO DE PARCELAS
           ============================================================ */
        UPDATE T
        SET  T.CD_PRODUTO_MO   = C.CD_PRODUTO,
             T.CD_MODALIDADE_MO = CASE 
                                    WHEN T.CD_MODALIDADE IN ('RECBANC','DESPBANC')
                                    THEN T.CD_MODALIDADE
                                    ELSE C.CD_MODALIDADE 
                                  END
        FROM #TEMP_CA_PARCELA T
        INNER JOIN [DB_B]..TB_CORP_INT_PRODUTO_NC C WITH (READUNCOMMITTED)  -- Modernizado: INNER JOIN
            ON T.CD_PRODUTO = C.CD_CHV_PRODUTO_NC
           AND T.ID_SISTEMA = C.ID_SISTEMA_ORIGEM_NC

        -- Remove arbitragem
        DELETE FROM #TEMP_CA_PARCELA
        WHERE CD_PRODUTO_MO = 'ARBITRAGEM'

        -- Atualização de moeda das parcelas (3 tentativas com diferentes critérios)
        UPDATE T
        SET T.CD_MOEDA = [DB_C].dbo.FN_CD_OFICIAL_CD_MOEDA(CONVERT(INT, S.CD_MOEDA))
        FROM #TEMP_CA_PARCELA T
        INNER JOIN [DB_A].dbo.VW_TXT_OPERACAO_SALDO S WITH (READUNCOMMITTED)  -- Modernizado: INNER JOIN
            ON T.CD_CONTRATO = S.CD_CONTRATO
           AND T.CD_PRODUTO = S.CD_PRODUTO
           AND T.CD_CHAVE_AUX = S.CD_CHAVE_AUX

        UPDATE T
        SET T.CD_MOEDA = [DB_C].dbo.FN_CD_OFICIAL_CD_MOEDA(CONVERT(INT, S.CD_MOEDA))
        FROM #TEMP_CA_PARCELA T
        INNER JOIN [DB_A].dbo.VW_TXT_OPERACAO_SALDO S WITH (READUNCOMMITTED)  -- Modernizado: INNER JOIN
            ON T.CD_PRODUTO = S.CD_PRODUTO
           AND T.CD_CHAVE_AUX = S.CD_CHAVE_AUX
        WHERE T.CD_MOEDA IS NULL
          AND S.CD_MODALIDADE IN ('DESPBANC','RECBANC')

        UPDATE T
        SET T.CD_MOEDA = [DB_C].dbo.FN_CD_OFICIAL_CD_MOEDA(CONVERT(INT, S.CD_MOEDA))
        FROM #TEMP_CA_PARCELA T
        INNER JOIN [DB_A].dbo.VW_TXT_OPERACAO_SALDO S WITH (READUNCOMMITTED)  -- Modernizado: INNER JOIN
            ON T.CD_PRODUTO = S.CD_PRODUTO
           AND T.CD_CHAVE_AUX = S.CD_CHAVE_AUX
        WHERE T.CD_MOEDA IS NULL

        UPDATE T 
        SET T.CD_PRODUTO_MO = 'ND'
        FROM #TEMP_CA_PARCELA T
        WHERE T.CD_PRODUTO_MO IS NULL

        UPDATE T 
        SET T.CD_MODALIDADE_MO = 'ND'
        FROM #TEMP_CA_PARCELA T
        WHERE T.CD_MODALIDADE_MO IS NULL

        UPDATE T 
        SET T.CD_MOEDA = 'ND'
        FROM #TEMP_CA_PARCELA T
        WHERE T.CD_MOEDA IS NULL

        /* ============================================================
           TOTALIZAÇÃO TEMPORÁRIA
           Modernizado: Removido ORDER BY desnecessário em INSERT
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, 'O', 'Totalização Temporária Operação')

        INSERT INTO #TEMP_TOT_CA
        SELECT
            CD_TIPO_INFO,
            CD_PRODUTO_MO,
            CD_MODALIDADE_MO,
            CD_MOEDA,
            COUNT(*) AS QT_REG,
            SUM(VL_ATUALIZADO),
            SUM(VL_FUTURO)
        FROM #TEMP_CA_OPER T
        GROUP BY CD_TIPO_INFO, CD_PRODUTO_MO, CD_MODALIDADE_MO, CD_MOEDA
        -- Removido ORDER BY: não tem efeito em INSERT...SELECT

        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, 'P', 'Totalização Temporária Parcela')

        INSERT INTO #TEMP_TOT_CA
        SELECT
            CD_TIPO_INFO,
            CD_PRODUTO_MO,
            CD_MODALIDADE_MO,
            CD_MOEDA,
            COUNT(*) AS QT_REG,
            SUM(VL_ATUALIZADO),
            SUM(VL_FUTURO)
        FROM #TEMP_CA_PARCELA T
        GROUP BY CD_TIPO_INFO, CD_PRODUTO_MO, CD_MODALIDADE_MO, CD_MOEDA
        -- Removido ORDER BY: não tem efeito em INSERT...SELECT

        /* ============================================================
           GRAVAÇÃO DA TOTALIZAÇÃO NA BASE DESTINO
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Totalização')

        DELETE FROM [DB_B]..TB_EXP_TOTALIZACAO_CARTEIRA WITH (ROWLOCK)
        WHERE DT_BASE = @DT_BASE

        INSERT INTO [DB_B]..TB_EXP_TOTALIZACAO_CARTEIRA WITH (ROWLOCK) (
            DT_BASE, ID_SISTEMA, CD_TIPO_INFO, CD_PRODUTO, CD_MODALIDADE,
            CD_MOEDA, QT_REGISTROS, VL_ATUALIZADO, VL_FUTURO
        )
        SELECT
            @DT_BASE,
            180,
            CD_TIPO_INFO,
            CD_PRODUTO_MO,
            CD_MODALIDADE_MO,
            CD_MOEDA,
            QT_REG,
            VL_ATUALIZADO_SOMA,
            VL_FUTURO_SOMA
        FROM #TEMP_TOT_CA

        /* ============================================================
           ACC/ACE - OPERAÇÕES
           Modernizado: OUTER APPLY para otimizar subqueries correlacionadas
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação ACC')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,  -- Modernizado: usando OUTER APPLY
            BS_FUT.VL_FUTURO         -- Modernizado: usando OUTER APPLY
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA BP WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = BP.ID_PESSOA
        OUTER APPLY (  -- Modernizado: substituiu subquery correlacionada
            SELECT BS.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_OPERACAO BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE
        ) BS_ATUAL
        OUTER APPLY (  -- Modernizado: substituiu subquery correlacionada
            SELECT BS.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE
        ) BS_FUT
        WHERE BO.CD_PRODUTO IN ('ACC','ACE')
          AND SUP.CD_ORIGEM = 'I'
          AND BO.IC_ATIVO IN ('1','2')
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND (BO.DT_ATUALIZACAO >= @DT_BASE 
               OR (BO.DT_ATUALIZACAO = BO.DT_ABERTURA AND BO.DT_VENCIMENTO > @DT_BASE))
          AND ISNULL(BS_ATUAL.VL_ATUALIZADO, 0) <> 0.0
          AND NOT EXISTS (
                SELECT 1 
                FROM [DB_A]..TB_PARCELA_OPERACAO BP2 WITH (READUNCOMMITTED)
                WHERE BP2.ID_OPERACAO = BO.ID_OPERACAO
          )
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'

        /* ============================================================
           ACC/ACE - PARCELAS
           Modernizado: OUTER APPLY para otimizar subqueries
           ============================================================ */
        INSERT INTO #TEMP_EXP_EC
        SELECT
            'P' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            SP_ATUAL.VL_ATUALIZADO,  -- Modernizado: usando OUTER APPLY
            SP_FUT.VL_FUTURO         -- Modernizado: usando OUTER APPLY
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_A]..TB_PARCELA_OPERACAO BP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = BP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA BC WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = BC.ID_PESSOA
        INNER JOIN [DB_A]..TB_SALDO_PARCELA_D0 BS WITH (READUNCOMMITTED)
            ON BP.ID_OPERACAO = BS.ID_OPERACAO
           AND BP.NO_PARCELA = BS.NO_PARCELA
           AND BP.IC_PAG_REC = BS.IC_PAG_REC
           AND BS.DT_SALDO = @DT_BASE
           AND BS.CD_TIPO_SALDO = 'F'
        OUTER APPLY (  -- Modernizado: substituiu subquery correlacionada
            SELECT SP1.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_PARCELA_D0 SP1 WITH (READUNCOMMITTED)
            WHERE SP1.ID_OPERACAO = BP.ID_OPERACAO 
              AND SP1.NO_PARCELA = BP.NO_PARCELA
              AND SP1.IC_PAG_REC = BP.IC_PAG_REC 
              AND SP1.DT_SALDO = @DT_BASE
              AND SP1.CD_TIPO_SALDO = 'F'
        ) SP_ATUAL
        OUTER APPLY (  -- Modernizado: substituiu subquery correlacionada
            SELECT SP4.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_PARCELA_D0 SP4 WITH (READUNCOMMITTED)
            WHERE SP4.ID_OPERACAO = BP.ID_OPERACAO 
              AND SP4.NO_PARCELA = BP.NO_PARCELA
              AND SP4.IC_PAG_REC = BP.IC_PAG_REC 
              AND SP4.DT_SALDO = @DT_BASE
              AND SP4.CD_TIPO_SALDO = 'F'
        ) SP_FUT
        WHERE BO.CD_PRODUTO IN ('ACC','ACE')
          AND SUP.CD_ORIGEM = 'I'
          AND BO.IC_ATIVO IN ('1','2')
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND (BP.DT_ATUALIZACAO >= @DT_BASE 
               OR (BP.DT_ATUALIZACAO = BO.DT_ABERTURA AND BP.DT_VENCIMENTO > @DT_BASE))
          AND BS.VL_ATUALIZADO <> 0.0
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'
          AND (BP.DT_LIQUIDACAO IS NULL OR BP.DT_LIQUIDACAO > @DT_BASE)

        /* ============================================================
           EXPORTAÇÃO
           Modernizado: OUTER APPLY e INNER JOIN
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação EXP')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA BP WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = BP.ID_PESSOA
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_OPERACAO BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE
        ) BS_FUT
        WHERE BO.CD_PRODUTO = 'EXPORTACAO'
          AND SUP.CD_ORIGEM = 'I'
          AND BO.IC_ATIVO IN ('1','2')
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND (BO.DT_ATUALIZACAO >= @DT_BASE 
               OR (BO.DT_ATUALIZACAO = BO.DT_ABERTURA AND BO.DT_VENCIMENTO > @DT_BASE))
          AND BS_ATUAL.VL_ATUALIZADO <> 0.0
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'
          AND NOT EXISTS (
                SELECT 1
                FROM [DB_A]..TB_OPERACAO BO1 WITH (READUNCOMMITTED)
                INNER JOIN [DB_A]..TB_LIGACAO_OPERACAO LIG WITH (READUNCOMMITTED)
                    ON LIG.ID_OPERACAO = BO1.ID_OPERACAO
                WHERE BO.ID_OPERACAO = LIG.ID_OPERACAO_LIGADA
                  AND BO1.CD_PRODUTO = 'ACC'
                  AND BO1.DT_ABERTURA <= @DT_BASE
          )

        /* ============================================================
           ARBITRAGEM
           Modernizado: LEFT JOIN em vez de *= (deprecated outer join)
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação Arbitragem')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_FUTURO AS VL_ATUALIZADO,  -- Nota: usa VL_FUTURO como VL_ATUALIZADO
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        LEFT JOIN [DB_B]..TB_PESSOA BP WITH (READUNCOMMITTED)  -- Modernizado: era *=
            ON BO.ID_CLIENTE = BP.ID_PESSOA
        OUTER APPLY (
            SELECT VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 WITH (READUNCOMMITTED)
            WHERE ID_OPERACAO = BO.ID_OPERACAO 
              AND DT_SALDO = @DT_BASE 
              AND CD_TIPO_SALDO = 'F'
        ) BS_ATUAL
        OUTER APPLY (
            SELECT VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 WITH (READUNCOMMITTED)
            WHERE ID_OPERACAO = BO.ID_OPERACAO 
              AND DT_SALDO = @DT_BASE 
              AND CD_TIPO_SALDO = 'F'
        ) BS_FUT
        WHERE SUP.CD_ORIGEM = 'I'
          AND BO.CD_PRODUTO IN ('Arbitragem')
          AND BO.IC_ATIVO = '1'
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND (BO.DT_VENCIMENTO IS NULL OR BO.DT_VENCIMENTO > @DT_BASE)
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'

        /* ============================================================
           CÂMBIO PRONTO / INTERBANCÁRIO
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação Cambio Pronto')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA BP WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = BP.ID_PESSOA
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_FUT
        WHERE SUP.CD_ORIGEM = 'I'
          AND BO.CD_PRODUTO IN ('CambioPronto','Interbancario')
          AND BO.IC_ATIVO IN ('1','2')
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND BO.DT_VENCIMENTO > @DT_BASE
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'

        /* ============================================================
           FUNDING
           Modernizado: LEFT JOIN em vez de *= (deprecated outer join)
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação Funding')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        LEFT JOIN [DB_B]..TB_PESSOA BC WITH (READUNCOMMITTED)  -- Modernizado: era *=
            ON BO.ID_CLIENTE = BC.ID_PESSOA
        INNER JOIN [DB_A]..TB_OPERACAO_SUP OS WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = OS.ID_OPERACAO
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_FUT
        WHERE BO.CD_PRODUTO = 'FUNDING'
          AND BO.IC_ATIVO = '1'
          AND OS.CD_ORIGEM = 'I'
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND (BO.DT_ATUALIZACAO >= @DT_BASE 
               OR (BO.DT_ATUALIZACAO = BO.DT_ABERTURA AND BO.DT_VENCIMENTO > @DT_BASE))
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'

        /* ============================================================
           TRAVA
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação Trava')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_B]..TB_PESSOA EMP WITH (READUNCOMMITTED)
            ON EMP.ID_PESSOA = BO.ID_EMPRESA
        INNER JOIN [DB_B]..TB_PESSOA CLI WITH (READUNCOMMITTED)
            ON CLI.ID_PESSOA = BO.ID_CLIENTE
        INNER JOIN [DB_A]..TB_OPERACAO_TRAVA T WITH (READUNCOMMITTED)
            ON T.ID_OPERACAO = BO.ID_OPERACAO
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO
        ) BS_FUT
        WHERE BO.CD_PRODUTO = 'TRAVA'
          AND BO.ID_EMPRESA = 1222
          AND BO.IC_ATIVO IN ('1','2')
          AND T.CD_INDICADOR_CORRECAO_PREMIO = 'USD'
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO < @DT_BASE)
          AND BS_ATUAL.VL_ATUALIZADO > 0
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, 'TRAVA', 'I') = 'S'

        /* ============================================================
           LC (LETTER OF CREDIT)
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação LC')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_B]..TB_PESSOA PES WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = PES.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA CLI WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = CLI.ID_PESSOA
        INNER JOIN [DB_A]..TB_OPERACAO_SUP OS WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = OS.ID_OPERACAO
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO
        ) BS_FUT
        WHERE BO.CD_PRODUTO = 'LC'
          AND OS.CD_ORIGEM = 'I'
          AND BO.IC_ATIVO IN ('1','2')
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO < @DT_BASE)
          AND NOT EXISTS (
                SELECT 1
                FROM [DB_A]..TB_PARCELA_OPERACAO PO WITH (READUNCOMMITTED)
                WHERE PO.ID_OPERACAO = BO.ID_OPERACAO
          )
        
        UNION
        
        SELECT
            'P' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_B]..TB_PESSOA PES WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = PES.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA CLI WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = CLI.ID_PESSOA
        INNER JOIN [DB_A]..TB_PARCELA_OPERACAO PO WITH (READUNCOMMITTED)
            ON PO.ID_OPERACAO = BO.ID_OPERACAO
        INNER JOIN [DB_A]..TB_OPERACAO_SUP OS WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = OS.ID_OPERACAO
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO
            FROM [DB_A]..TB_SALDO_PARCELA_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.NO_PARCELA = PO.NO_PARCELA
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO
            FROM [DB_A]..TB_SALDO_PARCELA_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
              AND BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.NO_PARCELA = PO.NO_PARCELA
        ) BS_FUT
        WHERE BO.CD_PRODUTO = 'LC'
          AND OS.CD_ORIGEM = 'I'
          AND BO.IC_ATIVO IN ('1','2')
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND (PO.DT_LIQUIDACAO IS NULL OR PO.DT_LIQUIDACAO > @DT_BASE)

        /* ============================================================
           FINIMP (FINANCIAMENTO À IMPORTAÇÃO)
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação Finimp')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            CD_PRODUTO,
            CD_MODALIDADE,
            CD_MOEDA,
            CASE 
                WHEN IC_OPERACAO_PARCELA = 'C'
                THEN VL_ATUALIZADO
                ELSE [DB_D].dbo.FN_METADADO_SALDO_OPERPARC(
                    CONVERT(CHAR(10), @DT_BASE, 112),
                    ID_OPERACAO, NO_PARCELA, IC_PAG_REC,
                    'A', IC_OPERACAO_PARCELA, 'F',
                    DT_VENCIMENTO, CD_PRODUTO
                )
            END AS VL_ATUALIZADO,
            [DB_D].dbo.FN_METADADO_SALDO_OPERPARC(
                CONVERT(CHAR(10), @DT_BASE, 112),
                ID_OPERACAO, NO_PARCELA, IC_PAG_REC,
                'F', IC_OPERACAO_PARCELA, 'F',
                DT_VENCIMENTO, CD_PRODUTO
            ) AS VL_FUTURO
        FROM [DB_D].dbo.VW_METADADO_EC_FLXCAIXA WITH (READUNCOMMITTED)
        WHERE DT_ABERTURA <= @DT_BASE
          AND (DT_ATUALIZACAO >= @DT_BASE OR DT_ATUALIZACAO = DT_ABERTURA)
          AND (DT_LIQUIDACAO IS NULL OR DT_LIQUIDACAO > @DT_BASE)
          AND (IC_OPERACAO_PARCELA IN ('O','P') 
               OR (IC_OPERACAO_PARCELA = 'C' AND DT_SALDO = @DT_BASE))
          AND IC_ATIVO IN ('1','2')
          AND CD_MOEDA IS NOT NULL
          AND CD_PRODUTO = 'Finimp'
          AND CD_ORIGEM = 'ORIGEM_X'  -- anonimizado

        /* ============================================================
           APLICAÇÃO BANCOS
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Temporária Exportação AplicacaoBancos')

        INSERT INTO #TEMP_EXP_EC
        SELECT
            'O' AS CD_TIPO_INFO,
            BO.CD_PRODUTO,
            BO.CD_MODALIDADE,
            BO.CD_MOEDA,
            BS_ATUAL.VL_ATUALIZADO,
            BS_FUT.VL_FUTURO
        FROM [DB_A]..TB_OPERACAO BO WITH (READUNCOMMITTED)
        INNER JOIN [DB_A]..TB_OPERACAO_SUP SUP WITH (READUNCOMMITTED)
            ON BO.ID_OPERACAO = SUP.ID_OPERACAO
        INNER JOIN [DB_B]..TB_PESSOA BE WITH (READUNCOMMITTED)
            ON BO.ID_EMPRESA = BE.ID_PESSOA
        INNER JOIN [DB_B]..TB_PESSOA BP WITH (READUNCOMMITTED)
            ON BO.ID_CLIENTE = BP.ID_PESSOA
        OUTER APPLY (
            SELECT BS.VL_ATUALIZADO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_ATUAL
        OUTER APPLY (
            SELECT BS.VL_FUTURO 
            FROM [DB_A]..TB_SALDO_OPERACAO_D0 BS WITH (READUNCOMMITTED)
            WHERE BS.ID_OPERACAO = BO.ID_OPERACAO 
              AND BS.DT_SALDO = @DT_BASE 
              AND BS.CD_TIPO_SALDO = 'F'
        ) BS_FUT
        WHERE SUP.CD_ORIGEM = 'I'
          AND BO.CD_PRODUTO IN ('AplicacaoBancos')
          AND BO.IC_ATIVO = '1'
          AND (BO.DT_LIQUIDACAO IS NULL OR BO.DT_LIQUIDACAO > @DT_BASE)
          AND BO.DT_ABERTURA <= @DT_BASE
          AND BO.DT_ATUALIZACAO >= @DT_BASE
          AND [DB_A].dbo.FN_CHV_EXPORTACAO(74, BO.CD_PRODUTO, 'I') = 'S'

        /* ============================================================
           TOTALIZAÇÃO EXPORTAÇÃO
           ============================================================ */
        INSERT INTO [DB_B]..TB_EXP_LOG_TOTALIZACAO WITH (ROWLOCK)
        VALUES (@DT_BASE, GETDATE(), @CurrentUser, 180, NULL, 'Totalização Exportação')

        INSERT INTO #TEMP_EXP_TOTALIZACAO
        SELECT
            @DT_BASE,
            'I' AS CD_ORIGEM,
            74 AS ID_SISTEMA,
            CD_TIPO_INFO,
            CD_PRODUTO,
            CD_MODALIDADE,
            CD_MOEDA,
            COUNT(*) AS QT_REGISTROS,
            SUM(ISNULL(VL_ATUALIZADO, 0)),
            SUM(ISNULL(VL_FUTURO, 0))
        FROM #TEMP_EXP_EC
        GROUP BY CD_TIPO_INFO, CD_PRODUTO, CD_MODALIDADE, CD_MOEDA

        DELETE FROM [DB_B]..TB_EXP_TOTALIZACAO_EXPORTACAO WITH (ROWLOCK)
        WHERE DT_BASE = @DT_BASE

        INSERT INTO [DB_B]..TB_EXP_TOTALIZACAO_EXPORTACAO WITH (ROWLOCK)
        SELECT
            DT_BASE,
            CD_ORIGEM,
            ID_SISTEMA,
            CD_TIPO_INFO,
            CD_PRODUTO,
            CD_MODALIDADE,
            CD_MOEDA,
            QT_REGISTROS,
            VL_ATUALIZADO,
            VL_FUTURO
        FROM #TEMP_EXP_TOTALIZACAO

        SELECT @QT_REGISTROS = @@ROWCOUNT

        /* ============================================================
           CONTRATOS DE EXPORTAÇÃO
           ============================================================ */
        -- Deleta operações do dia (evitar duplicidade por reprocessamentos)
        DELETE FROM [DB_B].dbo.TB_EXP_CONTRATO_CARTEIRA
        WHERE DT_GRAVACAO = @DT_BASE

        -- Insere novos registros de exportação enviados
        INSERT INTO [DB_B].dbo.TB_EXP_CONTRATO_CARTEIRA (
            DT_GRAVACAO, ID_SISTEMA, CD_PRODUTO, CD_CONTRATO,
            CD_CONTRATO_COMPLEMENTAR, DT_ABERTURA, DT_VENCIMENTO,
            VL_ABERTURA, VL_ATUALIZADO, VL_FUTURO
        )
        SELECT
            DT_ATUALIZACAO,
            180,
            [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') AS CD_PRODUTO,
            CD_CONTRATO,
            CD_CONTRATO_COMPLEMENTAR,
            DT_ABERTURA,
            DT_VENCIMENTO,
            VL_ABERTURA,
            VL_ATUALIZADO,
            VL_FUTURO
        FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T WITH (READUNCOMMITTED)
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE
          AND CD_PRODUTO = '97158'
          AND NOT EXISTS (
                SELECT 1
                FROM [DB_B].dbo.TB_EXP_CONTRATO_CARTEIRA E1 WITH (READUNCOMMITTED)
                WHERE E1.CD_CONTRATO_COMPLEMENTAR = T.CD_CONTRATO_COMPLEMENTAR
          )

        /* ============================================================
           FLUXO POR CONTRATO DE EXPORTAÇÃO
           ============================================================ */
        -- Fluxo por contrato de exportação
        DELETE FROM [DB_B].dbo.TB_EXP_FLUXO_CONTRATO_EXPORTACAO
        WHERE DT_BASE = @DT_BASE

        INSERT INTO [DB_B].dbo.TB_EXP_FLUXO_CONTRATO_EXPORTACAO (
            DT_BASE, CD_CONTRATO_EXPORTACAO, CD_CONTRATO, CD_PRODUTO,
            ID_OPERACAO, DT_ABERTURA, DT_VENCIMENTO,
            VL_ABERTURA, VL_ATUALIZADO, VL_FUTURO
        )
        SELECT
            DT_ATUALIZACAO,
            CD_CONTRATO_COMPLEMENTAR,
            CD_CONTRATO_COMPLEMENTAR,
            [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') AS CD_PRODUTO,
            NULL AS ID_OPERACAO,
            DT_ABERTURA,
            DT_VENCIMENTO,
            VL_ABERTURA,
            VL_ATUALIZADO,
            VL_FUTURO
        FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T WITH (READUNCOMMITTED)
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE
          AND CD_PRODUTO = '97158'

        -- ACC/ACE com contrato de exportação no arquivo
        INSERT INTO [DB_B].dbo.TB_EXP_FLUXO_CONTRATO_EXPORTACAO (
            DT_BASE, CD_CONTRATO_EXPORTACAO, CD_CONTRATO, CD_PRODUTO,
            ID_OPERACAO, DT_ABERTURA, DT_VENCIMENTO,
            VL_ABERTURA, VL_ATUALIZADO, VL_FUTURO
        )
        SELECT
            DT_ATUALIZACAO,
            CD_CONTRATO_COMPLEMENTAR,
            CD_CONTRATO,
            [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') AS CD_PRODUTO,
            NULL AS ID_OPERACAO,
            DT_ABERTURA,
            DT_VENCIMENTO,
            VL_ABERTURA,
            VL_ATUALIZADO,
            VL_FUTURO
        FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T WITH (READUNCOMMITTED)
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE
          AND [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') IN ('ACC','ACE','TRAVA')
          AND EXISTS (
                SELECT 1
                FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T2 WITH (READUNCOMMITTED)
                WHERE T2.CD_CONTRATO_COMPLEMENTAR = T.CD_CONTRATO_COMPLEMENTAR
                  AND T2.ID_SISTEMA = 180
                  AND T2.CD_PRODUTO = '97158'
          )

        -- ACC/ACE com contrato enviado anteriormente
        INSERT INTO [DB_B].dbo.TB_EXP_FLUXO_CONTRATO_EXPORTACAO (
            DT_BASE, CD_CONTRATO_EXPORTACAO, CD_CONTRATO, CD_PRODUTO,
            ID_OPERACAO, DT_ABERTURA, DT_VENCIMENTO,
            VL_ABERTURA, VL_ATUALIZADO, VL_FUTURO
        )
        SELECT
            DT_ATUALIZACAO,
            CD_CONTRATO_COMPLEMENTAR,
            CD_CONTRATO,
            [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') AS CD_PRODUTO,
            NULL AS ID_OPERACAO,
            DT_ABERTURA,
            DT_VENCIMENTO,
            VL_ABERTURA,
            VL_ATUALIZADO,
            VL_FUTURO
        FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T WITH (READUNCOMMITTED)
        WHERE ID_SISTEMA = 180
          AND DT_ATUALIZACAO = @DT_BASE
          AND [DB_C].dbo.FN_CHV_PROD_NC_CD_PRODUTO(180, CD_PRODUTO, 'O') IN ('ACC','ACE','TRAVA')
          AND NOT EXISTS (
                SELECT 1
                FROM [DB_A].dbo.VW_TXT_OPERACAO_SALDO T2 WITH (READUNCOMMITTED)
                WHERE T2.CD_CONTRATO_COMPLEMENTAR = T.CD_CONTRATO_COMPLEMENTAR
                  AND T2.ID_SISTEMA = 180
                  AND T2.CD_PRODUTO = '97158'
          )
          AND EXISTS (
                SELECT 1
                FROM [DB_B].dbo.TB_EXP_CONTRATO_CARTEIRA T3 WITH (READUNCOMMITTED)
                WHERE T3.CD_CONTRATO_COMPLEMENTAR = T.CD_CONTRATO_COMPLEMENTAR
          )

        SET NOCOUNT OFF
        
    END TRY
    BEGIN CATCH
        -- Tratamento de erros modernizado
        SELECT 
