package com.ibm.space.space;

/**
 * Game configuration constants.
 * Centralizes all magic numbers for better maintainability.
 */
public final class GameConstants {
    
    // Grid dimensions
    public static final int GRID_SIZE = 20;
    public static final int GRID_MIN = 0;
    public static final int GRID_MAX = 19;
    
    // Player configuration
    public static final int PLAYER_Y_POSITION = 19;
    public static final int PLAYER_ID = 0;
    
    // Enemy configuration
    public static final int ENEMY_COUNT = 40;
    public static final int ENEMY_ROWS = 4;
    public static final int ENEMY_COLUMNS = 10;
    public static final int ENEMY_MAX_Y = 15;
    
    // Bomb configuration
    public static final int BOMB_SPAWN_CHANCE_PERCENT = 30;
    public static final int BOMB_MIN_Y = 0;
    public static final int BOMB_MAX_Y = 20;
    
    // Game timing
    public static final int GAME_TICK_MS = 400;
    
    // Key codes
    public static final int KEY_RESET = 48;      // '0' key
    public static final int KEY_MOVE_LEFT = 111; // 'o' key
    public static final int KEY_MOVE_RIGHT = 112; // 'p' key
    public static final int KEY_SHOOT = 32;      // Space bar
    
    // HTTP timeouts (milliseconds)
    public static final int CONNECT_TIMEOUT_MS = 5000;
    public static final int READ_TIMEOUT_MS = 10000;
    
    // Private constructor to prevent instantiation
    private GameConstants() {
        throw new AssertionError("Cannot instantiate constants class");
    }
}

// Made with Bob
