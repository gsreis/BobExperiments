package com.ibm.space.space;

import java.io.StringReader;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonObject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
public class Space {
	
	private static final Logger LOGGER = Logger.getLogger(Space.class.getName());
	
	// Singleton JAX-RS client for reuse (prevents resource leaks)
	private static final Client REST_CLIENT = ClientBuilder.newClient();
	
	private final Random random = new Random();
	
	// Service URLs - externalized via system properties
	private static final String[] SERVICE_URLS = {
		"http://" + System.getProperty("enemyip", "127.0.0.1:9081") + "/enemy-1.0/",
		"http://" + System.getProperty("playerip", "127.0.0.1:9081") + "/player-1.0/",
		"http://" + System.getProperty("bombip", "127.0.0.1:9081") + "/bomb-1.0/",
		"http://" + System.getProperty("collisionip", "127.0.0.1:9081") + "/collision-1.0/"
	};

	   @GET
	@Path("/position")
	   @Produces("application/json")
	public Response position() {
		try {
			JsonArrayBuilder allelements = Json.createArrayBuilder();
			for (int i = 0; i < SERVICE_URLS.length; i++) {
				String json = callRest(SERVICE_URLS[i] + "position");
				JsonArray array = Json.createReader(new StringReader(json)).readArray();
				for (int j = 0; j < array.size(); j++) {
					allelements.add(array.get(j));
				}
			}
			return Response.status(200).entity(allelements.build())
					.header("Access-Control-Allow-Headers", "Content-Type")
					.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
					.header("Access-Control-Allow-Origin", "*")
					.build();
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Error getting positions from services", e);
			return Response.serverError()
					.entity(Json.createObjectBuilder()
							.add("error", "Failed to retrieve positions")
							.build())
					.build();
		}
	   }
    
    @GET
 @Path("/run")
    public Response run() {
  try {
   // Redirect commands to other Microservices
   for (int i = 0; i < SERVICE_URLS.length; i++) {
    callRest(SERVICE_URLS[i] + "run");
   }
   
   // Create bombs from enemies
   String json = callRest(getURLFromName("enemy") + "position");
   JsonArray array = Json.createReader(new StringReader(json)).readArray();
   int biggerX = 0;
   int lowerX = 0;
   int biggerY = 0;
   for (int j = 0; j < array.size(); j++) {
    int objectX = ((JsonObject)array.get(j)).getInt("x");
    int objectY = ((JsonObject)array.get(j)).getInt("y");
    if (objectX > biggerX) biggerX = objectX;
    if (objectX < lowerX) lowerX = objectX;
    if (objectY > biggerY) biggerY = objectY;
   }
   // Use constant for bomb spawn chance
   if (random.nextInt(100) < GameConstants.BOMB_SPAWN_CHANCE_PERCENT) {
    int posx = lowerX + random.nextInt(biggerX - lowerX);
    int posy = biggerY + 1;
    callRest(getURLFromName("bomb") + "create/" + posx + "/" + posy + "/false");
    LOGGER.log(Level.FINE, "Enemy bomb created at ({0},{1})", new Object[]{posx, posy});
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error in game loop execution", e);
   return Response.serverError().build();
  }
    }

 @GET
 @Path("/destroy/{id}")
 public Response destroy(@PathParam("id") int id) {
  try {
   for (int i = 0; i < SERVICE_URLS.length; i++) {
    callRest(SERVICE_URLS[i] + "destroy/" + id);
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error destroying entity: " + id, e);
   return Response.serverError().build();
  }
 }

    @GET
 @Path("/move/{key}")
 public Response move(@PathParam("key") String key) {
  try {
   for (int i = 0; i < SERVICE_URLS.length; i++) {
    callRest(SERVICE_URLS[i] + "move/" + key);
   }
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error processing move: " + key, e);
   return Response.serverError().build();
  }
    }
    
    @GET
 @Path("/create/{x}/{y}/{fromPlayer}")
 public Response createBomb(@PathParam("x") String x, @PathParam("y") String y, @PathParam("fromPlayer") String up) {
  try {
   callRest(getURLFromName("bomb") + "create/" + x + "/" + y + "/" + up);
   return Response.ok().build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error creating bomb", e);
   return Response.serverError().build();
  }
    }
    
    @GET
 @Path("/isFinished")
    @Produces("application/json")
 public Response isFinished() {
  try {
   boolean finished = false;
   for (int i = 0; i < SERVICE_URLS.length; i++) {
    String json = callRest(SERVICE_URLS[i] + "isFinished");
    JsonObject jobj = Json.createReader(new StringReader(json)).readObject();
    if (jobj != null && jobj.getBoolean("finished")) {
    	finished = true;
    }
   }
   return Response.status(200)
    	.entity(Json.createObjectBuilder().add("finished", finished).build())
    	.header("Access-Control-Allow-Headers", "Content-Type")
    	.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    	.header("Access-Control-Allow-Origin", "*")
    	.build();
  } catch (Exception e) {
   LOGGER.log(Level.SEVERE, "Error checking game status", e);
   return Response.serverError().build();
  }
    }
    
 /**
  * Calls a REST endpoint using the singleton client.
  * Proper exception handling with logging.
  */
 private String callRest(String urlin) {
  try {
   return REST_CLIENT.target(urlin)
    	.request(MediaType.APPLICATION_JSON)
    	.get(String.class);
  } catch (Exception e) {
   LOGGER.log(Level.WARNING, "Failed to call REST endpoint: " + urlin, e);
   return "[]";
  }
 }
 
 /**
  * Finds service URL by service name.
  */
 private String getURLFromName(String name) {
  for (int j = 0; j < SERVICE_URLS.length; j++) {
   if (SERVICE_URLS[j].indexOf(name) != -1) {
    return SERVICE_URLS[j];
   }
  }
  LOGGER.log(Level.WARNING, "Service URL not found for: " + name);
  return null;
 }
    
}

