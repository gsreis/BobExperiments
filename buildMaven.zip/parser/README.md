# JSON Parser - WebSphere Migration Analysis Tool

A Maven-based Java application for parsing and analyzing WebSphere migration JSON reports.

## Project Structure

```
parser/
├── pom.xml                          # Maven configuration
├── .gitignore                       # Git ignore rules
├── README.md                        # This file
├── src/
│   ├── main/
│   │   └── java/
│   │       └── parser/              # Source code package
│   │           ├── Parser.java      # Main entry point
│   │           ├── Parser2.java     # Alternative parser
│   │           ├── ExcelBean.java   # Data model
│   │           ├── API.java         # API model
│   │           ├── Technology.java  # Technology model
│   │           ├── ServerType.java  # Server type model
│   │           ├── Erro.java        # Error model
│   │           ├── Messages.java    # Messages handler
│   │           ├── Sumary.java      # Summary model
│   │           ├── SummaryTech.java # Technology summary
│   │           └── InventorySum.java # Inventory summary
│   └── test/
│       └── java/                    # Test sources (empty)
└── target/                          # Build output (generated)
```

## Dependencies

- **Apache Commons IO 2.15.1** - File and stream utilities
- **org.json 20231013** - JSON parsing library

## Building the Project

### Prerequisites
- Java 8 or higher
- Maven 3.6 or higher

### Build Commands

1. **Clean and compile:**
   ```bash
   mvn clean compile
   ```

2. **Package (creates JAR files):**
   ```bash
   mvn package
   ```

3. **Clean build:**
   ```bash
   mvn clean package
   ```

### Build Artifacts

After running `mvn package`, you'll find in the `target/` directory:

- `json-parser-1.0.0.jar` - Main JAR (requires dependencies in classpath)
- `json-parser-1.0.0-jar-with-dependencies.jar` - Standalone JAR with all dependencies
- `lib/` - Directory containing dependency JARs

## Running the Application

### Using the standalone JAR (recommended):
```bash
java -jar target/json-parser-1.0.0-jar-with-dependencies.jar
```

### Using the main JAR with dependencies:
```bash
java -cp "target/json-parser-1.0.0.jar:target/lib/*" parser.Parser
```

### With command-line arguments:
```bash
java -jar target/json-parser-1.0.0-jar-with-dependencies.jar <directory> <system-name>
```

## Configuration

The main parser (`Parser.java`) currently has hardcoded paths:
- Input directory: `/Users/glaucoreis/Desktop/bradesco/teste`
- System name: `was9`

To use different paths, either:
1. Modify the source code and rebuild
2. Uncomment the command-line argument handling in `Parser.java` (lines 28-33)

## Output Files

The application generates CSV reports:
- `sumarios_<system>.csv` - Summary of application compatibility
- `sumtech_<system>.csv` - Technology usage summary
- `invsum_<system>.csv` - Inventory summary
- `messages_<system>.csv` - Analysis messages
- `was_<system>_report.csv` - Detailed report

## Development

### IDE Setup

**IntelliJ IDEA:**
```bash
mvn idea:idea
```

**Eclipse:**
```bash
mvn eclipse:eclipse
```

**VS Code:**
Open the project folder - Maven support is automatic with Java extensions.

### Adding Dependencies

Edit `pom.xml` and add dependencies in the `<dependencies>` section, then run:
```bash
mvn clean install
```

## Troubleshooting

### Build Issues

If you encounter build issues:
1. Ensure Java 8+ is installed: `java -version`
2. Ensure Maven is installed: `mvn -version`
3. Clean the project: `mvn clean`
4. Delete the `target/` directory manually if needed

### Deprecated API Warnings

The project uses some deprecated APIs (Integer constructor). These are warnings and don't prevent compilation. To fix them, replace:
```java
new Integer(string)
```
with:
```java
Integer.parseInt(string)
```

## License

[Add your license information here]

## Author

[Add author information here]