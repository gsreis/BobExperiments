package parser;

import java.util.Vector;

public class ExcelBean {
	private String aplicacao;
	public String getAplicacao() { return aplicacao; }
	public void setAplicacao(String aplicacao) { this.aplicacao = aplicacao; }
	
	private Vector<Erro> erros = new Vector<Erro>();
	public Vector<Erro> getErros() {
		return erros;
	}
	public void setErros(Vector<Erro> erros) {
		this.erros = erros;
	}
	public void addErro(String erro, int numero) {
		erros.add(new Erro(erro, numero));
	}
	

	// inventory
	private Vector<API> inventario = new Vector<API>();
	public Vector<API> getInventario() {
		return inventario;
	}
	public void setInventario(Vector<API> apis) {
		this.inventario = apis;
	}
	
	private Vector<Technology> technologies = new Vector<Technology>();
	public Vector<Technology> getTechnologies() {
		return technologies;
	}
	public void setTechnologies(Vector<Technology> technologies) {
		this.technologies = technologies;
	}
	
	
}
