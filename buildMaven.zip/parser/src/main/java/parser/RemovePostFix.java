package parser;

import java.io.File;

public class RemovePostFix {

	private static String dir = "/Users/gsreis/Desktop/AnaliseWASBRADESCO/was8.5.5";

	public static void main(String[] args) {
		File f[] = new File(dir).listFiles();
		for (int i = 0; i < f.length; i++) {
			String filename = f[i].getAbsolutePath().substring(f[i].getAbsolutePath().lastIndexOf("/") + 1, f[i].getAbsolutePath().indexOf("_MigrationReport.json"));
			System.out.println(filename);
		}
	}

}
