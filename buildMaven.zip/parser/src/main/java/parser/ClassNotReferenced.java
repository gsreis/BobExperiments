package parser;

import java.util.Vector;

public class ClassNotReferenced {
	private Vector<String> notreferenced = new Vector<String>();

	public Vector<String> getNotreferenced() {
		return notreferenced;
	}

	public void setNotreferenced(Vector<String> notreferenced) {
		this.notreferenced = notreferenced;
	} 
}
