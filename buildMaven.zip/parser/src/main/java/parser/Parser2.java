package parser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

//$ANALYSIS-IGNORE
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

public class Parser2 {

	private static String dir = "/Users/glaucoreis/Desktop/sicoobworkspace/json";
	private static String sistema = "was9";

	// parser1
	private static Vector<Sumary> sumarios = new Vector<>();
	private static SummaryTech sumtech = new SummaryTech();
	private static InventorySum invsum = new InventorySum();
	private static Messages messages = new Messages();

	// parser2
	private static Vector<UmInventario> inventarios = new Vector<UmInventario>();
	private static Vector<UmEval> evals = new Vector<UmEval>();

	public static void main(String[] args) throws Exception {

		Parser2 parser = new Parser2();

		// leitura arquivos inventory
		parser.leituraInventarios();

		// Arquivos inventory
		parser.generateSummaryCount2File();

		parser.generateSummaryArchives2File();

		parser.generateConflict2File();

		parser.generateUnused2File();

		// leitura arquivos eval
		parser.leituraEval();

		// gera relatório de tecnologias suportadas por aplicação X tipo servidor
		parser.generateReportEval1();

		// gera relatório de tecnologias suportadas por aplicação x tecnologia
		parser.generateReportEval2();
	}

	private void generateReportEval2() throws Exception {
		Set<String> techs = getAllTechonologies();

		File f = new File(dir + "/evaltechnology.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		for (String value : techs) {
			out.write("," + value);
		}
		out.write("\r\n");

		boolean found = false;
		for (int i = 0; i < evals.size(); i++) {
			UmEval eval = evals.get(i);
			out.write(eval.getName() + ",");
			found = false;
			for (String value : techs) {
				for (int j = 0; j < eval.getTechs().size(); j++) {
					OneTechnology onetech = eval.getTechs().get(j);
					if (onetech.getName().equals(value)) {
						out.write("X,");
						found = true;
						break;
					}
				}
				if (!found)
					out.write(",");
			}
			out.write("\r\n");
		}
		out.flush();
		out.close();
	}

	private Set<String> getAllTechonologies() throws Exception {
		Set<String> alltech = new HashSet<String>();
		for (int i = 0; i < evals.size(); i++) {
			UmEval eval = evals.get(i);
			for (int j = 0; j < eval.getTechs().size(); j++) {
				OneTechnology onetech = eval.getTechs().get(j);
				alltech.add(onetech.getName());
			}
		}
		return alltech;
	}

	private void generateReportEval1() throws Exception {
		File f = new File(dir + "/evaltech.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(
				",openLiberty,libertyCore,liberty,websphereTraditional,ndLiberty,ndTraditional,zosLiberty,zosTraditional\r\n");
		for (int i = 0; i < evals.size(); i++) {
			UmEval eval1 = evals.get(i);
			out.write(eval1.getName() + "," +
					(eval1.isOpenLiberty() ? "X," : ",") +
					(eval1.isLibertyCore() ? "X," : ",") +
					(eval1.isLiberty() ? "X," : ",") +
					(eval1.isWebsphereTraditional() ? "X," : ",") +
					(eval1.isNdLiberty() ? "X," : ",") +
					(eval1.isNdTraditional() ? "X," : ",") +
					(eval1.isZosLiberty() ? "X," : ",") +
					(eval1.isZosTraditional() ? "X," : ",") +
					"\r\n");
		}
		out.flush();
		out.close();
	}

	private void leituraEval() {
		File f[] = new File(dir + "/eval").listFiles();
		if (f == null) return;
		for (int i = 0; i < f.length; i++) {
			if (f[i].getAbsolutePath().endsWith("json"))
				try {
					geraUmEval(dir, "file://" + f[i].getAbsolutePath(), sistema);
				} catch (Exception e) {
					System.out.println(e);
				}
		}
	}

	private void geraUmEval(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url))); // pega JSON para este arquivo inventário

		UmEval umeval = new UmEval();
		umeval.setName(getAppNameEval(json));

		JSONArray arr1 = (JSONArray) json.get("applications");
		JSONObject json1 = arr1.getJSONObject(0);

		umeval.setOpenLiberty((json1.getJSONObject("summary")).getBoolean("openLiberty"));
		umeval.setLibertyCore((json1.getJSONObject("summary")).getBoolean("libertyCore"));
		umeval.setLiberty((json1.getJSONObject("summary")).getBoolean("liberty"));
		umeval.setWebsphereTraditional((json1.getJSONObject("summary")).getBoolean("websphereTraditional"));
		umeval.setNdLiberty((json1.getJSONObject("summary")).getBoolean("ndLiberty"));
		umeval.setNdTraditional((json1.getJSONObject("summary")).getBoolean("ndTraditional"));
		umeval.setZosLiberty((json1.getJSONObject("summary")).getBoolean("zosLiberty"));
		umeval.setZosTraditional((json1.getJSONObject("summary")).getBoolean("zosTraditional"));

		JSONArray techs = (JSONArray) json1.getJSONArray("technologies");
		for (int i = 0; i < techs.length(); i++) {
			JSONObject jobj = techs.getJSONObject(i);
			OneTechnology onetech = new OneTechnology();
			onetech.setName(jobj.getString("technology"));
			onetech.setOpenLiberty(jobj.getBoolean("openLiberty"));
			onetech.setLibertyCore(jobj.getBoolean("libertyCore"));
			onetech.setLiberty(jobj.getBoolean("liberty"));
			onetech.setWebsphereTraditional(jobj.getBoolean("websphereTraditional"));
			onetech.setNdLiberty(jobj.getBoolean("ndLiberty"));
			onetech.setNdTraditional(jobj.getBoolean("ndTraditional"));
			onetech.setZosLiberty(jobj.getBoolean("zosLiberty"));
			onetech.setZosTraditional(jobj.getBoolean("zosTraditional"));
			umeval.getTechs().add(onetech);
		}

		evals.add(umeval);
	}

	// pega o nome da aplicação
	private String getAppNameEval(JSONObject json) throws JSONException {
		// nome da aplicacao
		JSONArray arr = (JSONArray) json.get("applications");
		JSONObject obj = arr.getJSONObject(0);
		String app = obj.getString("application");
		app = app.substring(app.lastIndexOf("/") + 1);
		return app;
	}

	private void generateUnused2File() throws Exception {
		File f = new File(dir + "/unused.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		for (int i = 0; i < inventarios.size(); i++) {
			UmInventario uminv = inventarios.get(i);
			out.write("JARs não utilizados  em " + uminv.getName() + "\r\n");
			out.write(uminv.getProblems().getNotreferenced().size() + "\r\n");
			PotentialProblems pot = uminv.getProblems();
			Vector<String> notref = pot.getNotreferenced();
			for (int j = 0; j < notref.size(); j++) {
				String umdup = notref.get(j);
				out.write(umdup + "\r\n");
			}
			out.write("\r\n");
		}
		out.flush();
		out.close();
	}

	private void generateConflict2File() throws Exception {
		File f = new File(dir + "/conflict.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		for (int i = 0; i < inventarios.size(); i++) {
			UmInventario uminv = inventarios.get(i);
			out.write("Conflitos em " + uminv.getName() + "\r\n");
			PotentialProblems pot = uminv.getProblems();
			Vector<DuplicatedClasses> dup = pot.getDuplicated();
			for (int j = 0; j < dup.size(); j++) {
				DuplicatedClasses umdup = dup.get(j);
				out.write("packages afetadas \r\n");
				for (int k = 0; k < umdup.getPackages().size(); k++) {
					out.write(" , " + umdup.getPackages().get(k) + " \r\n ");
				}
				out.write("\r\n");
				out.write("jars conflitantes \r\n");
				for (int k = 0; k < umdup.getJars().size(); k++) {
					out.write(" , " + umdup.getJars().get(k) + " \r\n ");
				}
				out.write("\r\n");
			}
		}
		out.flush();
		out.close();
	}

	private void generateSummaryArchives2File() throws Exception {
		String headers[] = {
				"ears",
				"wars",
				"rars",
				"ejbs",
				"webFragments",
				"utilityJars",
				"appClients"
		};
		File f = new File(dir + "/archives.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		for (int i = 0; i < headers.length; i++) {
			out.write("," + headers[i]);
		}
		out.write("\r\n");

		for (int i = 0; i < inventarios.size(); i++) {
			UmInventario uminv = inventarios.get(i);
			out.write(uminv.getName());
			for (int j = 0; j < headers.length; j++) {
				int val = 0;
				try {
					val = uminv.getArchives().getArchives().get(headers[j]);
				} catch (Exception e) {
				}
				out.write("," + val);
			}
			out.write("\r\n");
		}
		out.flush();
		out.close();
	}

	private void generateSummaryCount2File() throws Exception {
		String headers[] = {
				"servlets",
				"jsps",
				"jpaEntities",
				"bmpEntityBeans",
				"cmpEntityBeans",
				"messageDrivenBeans",
				"singletonSessionBeans",
				"statefulSessionBeans",
				"statelessSessionBeans",
				"jaxrpcConsumers",
				"jaxrpcProviders",
				"jaxrsConsumers",
				"jaxrsProviders",
				"jaxwsConsumers",
				"jaxwsProviders",
				"springBeans"
		};
		File f = new File(dir + "/sumarios.csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		for (int i = 0; i < headers.length; i++) {
			out.write("," + headers[i]);
		}
		out.write("\r\n");

		for (int i = 0; i < inventarios.size(); i++) {
			UmInventario uminv = inventarios.get(i);
			out.write(uminv.getName());
			for (int j = 0; j < headers.length; j++) {
				out.write("," + uminv.getSummary().getSummary().get(headers[j]));
			}
			out.write("\r\n");
		}
		out.flush();
		out.close();
	}

	private void leituraInventarios() {
		File f[] = new File(dir + "/inventory").listFiles();
		for (int i = 0; i < f.length; i++) {
			if (f[i].getAbsolutePath().endsWith("json"))
				try {
					geraUmInventario(dir, "file://" + f[i].getAbsolutePath(), sistema);
				} catch (Exception e) {
					System.out.println(e);
				}
		}
	}

	private void geraUmInventario(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {

		JSONObject json = new JSONObject(IOUtils.toString(new URL(url))); // pega JSON para este arquivo inventário

		UmInventario inventario = new UmInventario();
		inventario.setName(getAppName(json));

		getSharedLibraries(inventario, json);
		generateArchives(inventario, json);
		generateSummary(inventario, json);
		getPotentialProblems(inventario, json);

		inventarios.add(inventario);

	}

	private void getPotentialProblems(UmInventario inventario, JSONObject json) throws Exception {
		JSONArray po1 = ((JSONArray) json.get("archiveInventory"));
		JSONObject po2 = po1.getJSONObject(0);
		JSONArray potential1 = po2.getJSONArray("potentialDeploymentProblemsDetails");
		// JSONObject potential = potential1.getJSONObject(0);

		for (int k = 0; k < potential1.length(); k++) {
			JSONObject potential = potential1.getJSONObject(k);
			String reason = potential.keys().next().toString();
			JSONArray duplicatedClassloader2 = ((JSONArray) potential.getJSONArray(reason));
			for (int i = 0; i < duplicatedClassloader2.length(); i++) {
				JSONObject duplicatedClassloader = duplicatedClassloader2.getJSONObject(i);
				// conflicting packages
				DuplicatedClasses duplicated = new DuplicatedClasses();
				duplicated.setReason(reason);

				JSONArray duplicatedjson = null;
				try {
					duplicatedjson = duplicatedClassloader.getJSONArray("conflictingPackages");
				} catch (Exception e) {
				}

				if (duplicatedjson != null) {
					for (int j = 0; j < duplicatedjson.length(); j++) {
						duplicated.getPackages().add(duplicatedjson.get(j).toString());
					}

					duplicatedjson = duplicatedClassloader.getJSONArray("packageLocation");
					for (int j = 0; j < duplicatedjson.length(); j++) {
						duplicated.getJars().add(duplicatedjson.get(j).toString());
					}
					inventario.getProblems().getDuplicated().add(duplicated);
				} else {
					if (reason.equals("archivesNotReferenced")) {
						for (int j = 0; j < duplicatedClassloader2.length(); j++) {
							String unused = duplicatedClassloader2.getJSONObject(j).getString("archive");
							inventario.getProblems().getNotreferenced().add(unused);
						}
					}
				}

			}
		}
	}

	private void generateSummary(UmInventario inventario, JSONObject json) throws Exception {
		JSONObject archieves = (JSONObject) json.get("summary");
		Summary summary = inventario.getSummary();
		summary.getSummary().put("servlets", new Integer(archieves.get("servlets").toString()));
		summary.getSummary().put("jsps", new Integer(archieves.get("jsps").toString()));
		summary.getSummary().put("jpaEntities", new Integer(archieves.get("jpaEntities").toString()));
		summary.getSummary().put("bmpEntityBeans", new Integer(archieves.get("bmpEntityBeans").toString()));
		summary.getSummary().put("cmpEntityBeans", new Integer(archieves.get("cmpEntityBeans").toString()));
		summary.getSummary().put("messageDrivenBeans", new Integer(archieves.get("messageDrivenBeans").toString()));
		summary.getSummary().put("singletonSessionBeans",
				new Integer(archieves.get("singletonSessionBeans").toString()));
		summary.getSummary().put("statefulSessionBeans", new Integer(archieves.get("statefulSessionBeans").toString()));
		summary.getSummary().put("statelessSessionBeans",
				new Integer(archieves.get("statelessSessionBeans").toString()));
		summary.getSummary().put("jaxrpcConsumers", new Integer(archieves.get("jaxrpcConsumers").toString()));
		summary.getSummary().put("jaxrpcProviders", new Integer(archieves.get("jaxrpcProviders").toString()));
		summary.getSummary().put("jaxrsConsumers", new Integer(archieves.get("jaxrsConsumers").toString()));
		summary.getSummary().put("jaxrsProviders", new Integer(archieves.get("jaxrsProviders").toString()));
		summary.getSummary().put("jaxwsConsumers", new Integer(archieves.get("jaxwsConsumers").toString()));
		summary.getSummary().put("jaxwsProviders", new Integer(archieves.get("jaxwsProviders").toString()));
		summary.getSummary().put("springBeans", new Integer(archieves.get("springBeans").toString()));
	}

	private void generateArchives(UmInventario inventario, JSONObject json) throws Exception {
		JSONObject archieves = (JSONObject) json.get("archives");
		Archives arch = inventario.getArchives();
		arch.getArchives().put("ears", new Integer(archieves.get("ears").toString()));
		arch.getArchives().put("wars", new Integer(archieves.get("wars").toString()));
		arch.getArchives().put("ejbs", new Integer(archieves.get("ejbs").toString()));
		arch.getArchives().put("webFragments", new Integer(archieves.get("webFragments").toString()));
		arch.getArchives().put("utilityJars", new Integer(archieves.get("utilityJars").toString()));
		arch.getArchives().put("appClients", new Integer(archieves.get("appClients").toString()));
	}

	// sumariza shared Libraries de um EAR
	private void getSharedLibraries(UmInventario inventario, JSONObject json) throws Exception {
		JSONArray libraries = (JSONArray) json.get("sharedLibraries");
		for (int i = 0; i < libraries.length(); i++) {
			inventario.getShared().add(libraries.getString(i));
		}
	}

	// pega o nome da aplicação
	private String getAppName(JSONObject json) throws JSONException {
		// nome da aplicacao
		JSONArray arr = (JSONArray) json.get("applications");
		String app = arr.get(0).toString();
		app = app.substring(app.lastIndexOf("/") + 1);
		return app;
	}

	private static void geraMessages() throws Exception {
		File f = new File(dir + "/messages_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(messages.toString());
		out.flush();
		out.close();
	}

	private static void geraInventorySum() throws Exception {
		File f = new File(dir + "/invsum_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(invsum.toString());
		out.flush();
		out.close();
	}

	private static void geraSumTech() throws Exception {
		File f = new File(dir + "/sumtech_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(sumtech.toString());
		out.flush();
		out.close();
	}

	private static void geraSumarios() throws Exception {
		File f = new File(dir + "/sumarios_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(
				"Aplicacao,Liberty for Java on IBM Bluemix, Liberty Core, Liberty, WebSphere traditional, Network Deployment Liberty, Network Deployment traditional, Liberty for z/OS, WebSphere traditional for z/OS\n");
		for (int i = 0; i < sumarios.size(); i++) {
			Sumary s1 = sumarios.get(i);
			out.write(s1.getFilename() + "," + s1.getBluemixLiberty() + "," + s1.getLibertyCore() + ","
					+ s1.getLiberty() + "," + s1.getWebsphereTraditional() + "," + s1.getNdLiberty() + ","
					+ s1.getNdTraditional() + "," + s1.getZosLiberty() + "," + s1.getZosTraditional() + "\n");
		}
		out.flush();
		out.close();
	}

	private static void geraUmError(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url)));

		ExcelBean bean = new ExcelBean();

		// nome da aplicacao
		String app = json.get("application").toString();
		app = app.substring(app.lastIndexOf("/") + 1);
		bean.setAplicacao(app);
		// erros
		JSONArray errors = (JSONArray) ((JSONArray) json.get("rules"));
		for (int i = 0; i < errors.length(); i++) {
			String ruleName = ((JSONObject) errors.get(i)).get("ruleName").toString();
			int contador = ((JSONArray) ((JSONObject) errors.get(i)).get("results")).length();
			bean.getErros().add(new Erro(ruleName, contador));
		}
	}

	private static void geraUmHTML(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url)));

		ExcelBean bean = new ExcelBean();

		// nome da aplicacao
		String app = json.get("application").toString();
		app = app.substring(app.lastIndexOf("/") + 1);
		bean.setAplicacao(app);
		// elegivel para qual servidor

		// gera o HTML na saída
		generateHTML(dir, bean, sistema);
	}

	private static void geraUmSumario(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url)));

		ExcelBean bean = new ExcelBean();

		// nome da aplicacao
		String app = json.get("application").toString();
		app = app.substring(app.lastIndexOf("/") + 1);
		bean.setAplicacao(app);
		// elegivel para qual servidor

		// pega sumario e salva
		Sumary suma = new Sumary();
		suma.setFilename(bean.getAplicacao());
		JSONObject sumaries = ((JSONObject) ((JSONObject) json.get("summary")));
		suma.setBluemixLiberty(((boolean) sumaries.get("bluemixLiberty")) ? "X" : "");
		suma.setLibertyCore(((boolean) sumaries.get("libertyCore")) ? "X" : "");
		suma.setLiberty(((boolean) sumaries.get("liberty")) ? "X" : "");
		suma.setWebsphereTraditional(((boolean) sumaries.get("websphereTraditional")) ? "X" : "");
		suma.setNdLiberty(((boolean) sumaries.get("ndLiberty")) ? "X" : "");
		suma.setNdTraditional(((boolean) sumaries.get("ndTraditional")) ? "X" : "");
		suma.setZosLiberty(((boolean) sumaries.get("zosLiberty")) ? "X" : "");
		suma.setZosTraditional(((boolean) sumaries.get("zosTraditional")) ? "X" : "");
		sumarios.add(suma);
	}

	private static void geraUmAnalyze(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url)));

		ExcelBean bean = new ExcelBean();

		// nome da aplicacao
		String app = json.get("application").toString();
		app = app.substring(app.lastIndexOf("/") + 1);
		bean.setAplicacao(app);
		// elegivel para qual servidor

		// grava mensagens
		JSONArray messag = (JSONArray) ((JSONObject) json.get("analyze")).get("rules");
		for (int i = 0; i < messag.length(); i++) {
			String ruleName = ((JSONObject) messag.get(i)).get("ruleName").toString();
			String level = ((JSONObject) messag.get(i)).get("severity").toString();
			messages.addMessage(ruleName, level);
		}
	}

	private static void sumarizaInventario(Vector<API> inventario) {
		for (int i = 0; i < inventario.size(); i++) {
			invsum.count(inventario.get(i));
		}
	}

	private static void generateHTML(String dir, ExcelBean bean, String sistema) throws Exception {
		// TODO Auto-generated method stub
		BufferedWriter out = new BufferedWriter(new FileWriter(dir + "/was_" + sistema + "_report.csv", true));
		out.write(bean.getAplicacao() + "\r");
		for (int i = 0; i < bean.getInventario().size(); i++) {
			API api = bean.getInventario().get(i);
			out.write(api.getName() + " , " + api.getCount() + "\r");
		}
		out.write("Erros\r");
		for (int i = 0; i < bean.getErros().size(); i++) {
			Erro err = bean.getErros().get(i);
			out.write(err.getErro().replaceAll(",", "-") + " , " + err.getNumeroErros() + "\r");
		}
		for (int i = 0; i < bean.getTechnologies().size(); i++) {
			Technology tech = bean.getTechnologies().get(i);
			if (i == 0) {
				out.write(",");
				for (int j = 0; j < tech.getServers().size(); j++) {
					out.write(tech.getServers().get(j).getName().replaceAll(",", "-") + " , ");
				}
			}
			out.write("\r");
			out.write(tech.getTechnology() + " , ");
			for (int j = 0; j < tech.getServers().size(); j++) {
				out.write(tech.getServers().get(j).isSupported() ? "X" : " ");
				out.write(",");
			}
		}
		out.write("\r");
		out.flush();
		out.close();
	}

}
