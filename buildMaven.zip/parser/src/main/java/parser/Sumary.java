package parser;

public class Sumary {
	private String filename;
	private String bluemixLiberty;
	private String libertyCore;
	private String liberty;
	private String websphereTraditional;
	private String ndLiberty;
	private String ndTraditional;
	private String zosLiberty;
	private String zosTraditional;

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getBluemixLiberty() {
		return bluemixLiberty;
	}

	public void setBluemixLiberty(String bluemixLiberty) {
		this.bluemixLiberty = bluemixLiberty;
	}

	public String getLibertyCore() {
		return libertyCore;
	}

	public void setLibertyCore(String libertyCore) {
		this.libertyCore = libertyCore;
	}

	public String getLiberty() {
		return liberty;
	}

	public void setLiberty(String liberty) {
		this.liberty = liberty;
	}

	public String getWebsphereTraditional() {
		return websphereTraditional;
	}

	public void setWebsphereTraditional(String websphereTraditional) {
		this.websphereTraditional = websphereTraditional;
	}

	public String getNdLiberty() {
		return ndLiberty;
	}

	public void setNdLiberty(String ndLiberty) {
		this.ndLiberty = ndLiberty;
	}

	public String getNdTraditional() {
		return ndTraditional;
	}

	public void setNdTraditional(String ndTraditional) {
		this.ndTraditional = ndTraditional;
	}

	public String getZosLiberty() {
		return zosLiberty;
	}

	public void setZosLiberty(String zosLiberty) {
		this.zosLiberty = zosLiberty;
	}

	public String getZosTraditional() {
		return zosTraditional;
	}

	public void setZosTraditional(String zosTraditional) {
		this.zosTraditional = zosTraditional;
	}

	 @Override
	public String toString() {
		return getFilename() + "," + getBluemixLiberty() + "," + getLibertyCore() + "," + getLiberty() + "," + getWebsphereTraditional() + "," + getNdLiberty() + "," + getNdTraditional() + "," + getZosLiberty() + "," + getZosTraditional() + "\n";
	}
}
