package parser;

import java.util.Vector;

public class UmInventario {
	private String name;
	private Vector<String> shared = new Vector<String>(); //shared libraries
	private Archives archives = new Archives();
	private PotentialProblems problems = new PotentialProblems();
	private Summary summary = new Summary();

	
	
	public PotentialProblems getProblems() {
		return problems;
	}

	public void setProblems(PotentialProblems problems) {
		this.problems = problems;
	}


	public Summary getSummary() {
		return summary;
	}

	public void setSummary(Summary summary) {
		this.summary = summary;
	}

	public Archives getArchives() {
		return archives;
	}

	public void setArchives(Archives archives) {
		this.archives = archives;
	}

	public Vector<String> getShared() {
		return shared;
	}

	public void setShared(Vector<String> shared) {
		this.shared = shared;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
