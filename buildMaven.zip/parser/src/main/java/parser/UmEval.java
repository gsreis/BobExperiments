package parser;

import java.util.Vector;

public class UmEval {
	private String name;
    private boolean openLiberty;
    
	private boolean libertyCore;
    private boolean liberty;
    private boolean websphereTraditional;
    private boolean ndLiberty;
    private boolean ndTraditional;
    private boolean zosLiberty;
    private boolean zosTraditional;
    
    private Vector<OneTechnology> techs = new Vector<OneTechnology>();
    
    public Vector<OneTechnology> getTechs() {
		return techs;
	}

	public void setTechs(Vector<OneTechnology> techs) {
		this.techs = techs;
	}

	public boolean isOpenLiberty() {
		return openLiberty;
	}

	public void setOpenLiberty(boolean openLiberty) {
		this.openLiberty = openLiberty;
	}

	public boolean isLibertyCore() {
		return libertyCore;
	}

	public void setLibertyCore(boolean libertyCore) {
		this.libertyCore = libertyCore;
	}

	public boolean isLiberty() {
		return liberty;
	}

	public void setLiberty(boolean liberty) {
		this.liberty = liberty;
	}

	public boolean isWebsphereTraditional() {
		return websphereTraditional;
	}

	public void setWebsphereTraditional(boolean websphereTraditional) {
		this.websphereTraditional = websphereTraditional;
	}

	public boolean isNdLiberty() {
		return ndLiberty;
	}

	public void setNdLiberty(boolean ndLiberty) {
		this.ndLiberty = ndLiberty;
	}

	public boolean isNdTraditional() {
		return ndTraditional;
	}

	public void setNdTraditional(boolean ndTraditional) {
		this.ndTraditional = ndTraditional;
	}

	public boolean isZosLiberty() {
		return zosLiberty;
	}

	public void setZosLiberty(boolean zosLiberty) {
		this.zosLiberty = zosLiberty;
	}

	public boolean isZosTraditional() {
		return zosTraditional;
	}

	public void setZosTraditional(boolean zosTraditional) {
		this.zosTraditional = zosTraditional;
	}	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
