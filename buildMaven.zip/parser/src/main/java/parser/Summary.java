package parser;

import java.util.HashMap;

public class Summary {
	private HashMap <String, Integer> summary = new HashMap <String, Integer>();

	public HashMap<String, Integer> getSummary() {
		return summary;
	}

	public void setSummary(HashMap<String, Integer> archives) {
		this.summary = archives;
	}
	
	

}
