package parser;

import java.util.HashMap;

public class Archives {
	private HashMap <String, Integer> archives = new HashMap <String, Integer>();

	public HashMap<String, Integer> getArchives() {
		return archives;
	}

	public void setArchives(HashMap<String, Integer> archives) {
		this.archives = archives;
	}
	
	

}
