package parser;

import java.util.Vector;

public class Messages {
    private Vector<String> error = new Vector<>();
    private Vector<String> warning = new Vector<>();
    private Vector<String> info = new Vector<>();
    
    public void addMessage(String message, String type) {
    	switch (type) {
		case "Severe":
			if (!error.contains(message) )
				error.add(message);
			break;

		case "Warning" :
			if (!warning.contains(message) )
				warning.add(message);			
			break;
			
		case "Information" :
			if (!info.contains(message) )
				info.add(message);			
			break;
			
		}
    }
    
    @Override
    public String toString() {
    	String ret = "Severe\n";
    	for (int i = 0; i < error.size(); i++) {
			ret += error.get(i) + "\n";
		}
    	ret += "Warning\n";
    	for (int i = 0; i < warning.size(); i++) {
			ret += warning.get(i) + "\n";
		}
    	ret += "Information\n";
    	for (int i = 0; i < info.size(); i++) {
			ret += info.get(i) + "\n";
		}    	
    	return ret;
    }
}
