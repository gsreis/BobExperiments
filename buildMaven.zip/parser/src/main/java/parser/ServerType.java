package parser;

public class ServerType {
     private String name;
     private boolean supported;
     
    public ServerType(String name, boolean supported) {
    	this.name = name;
    	this.supported = supported;
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isSupported() {
		return supported;
	}
	public void setSupported(boolean supported) {
		this.supported = supported;
	}
     
}
