package parser;

public class Erro {
	private String erro;
	private int numeroErros;
	public String getErro() {
		return erro;
	}
	public void setErro(String erro) {
		this.erro = erro;
	}
	public int getNumeroErros() {
		return numeroErros;
	}
	public void setNumeroErros(int numeroErros) {
		this.numeroErros = numeroErros;
	}
	public Erro(String erro, int numero) {
		this.erro = erro;
		this.numeroErros = numero;
	}
}
