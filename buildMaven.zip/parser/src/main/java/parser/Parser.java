package parser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

//$ANALYSIS-IGNORE
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

public class Parser {

	private static String dir = "/Users/glaucoreis/Desktop/bradesco/teste";
	private static String sistema = "was9";
	private static Vector<Sumary> sumarios = new Vector<>();
	private static SummaryTech sumtech = new SummaryTech();
	private static InventorySum invsum = new InventorySum();
	private static Messages messages = new Messages();

	public static void main(String[] args) throws Exception {

// Para rodar direto na linha de comando
//		if (args.length != 2) {
//			System.out.println("Chamada Parser <diretório com os JSONs> <nome da aplicação>");
//		}
//		dir = args[0];
//		sistema = args[1];
		
		
		File f[] = new File(dir).listFiles();
		for (int i = 0; i < f.length; i++) {
			if (f[i].getAbsolutePath().endsWith("json"))
			   geraUmArquivo(dir, "file://" + f[i].getAbsolutePath(), sistema);	
		}

		geraSumarios();
		geraSumTech();
		geraInventorySum();
		geraMessages();
		
		
	}

	private static void geraMessages() throws Exception {
		File f = new File(dir + "/messages_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(messages.toString());
		out.flush();
		out.close();	}

	private static void geraInventorySum() throws Exception{
		File f = new File(dir + "/invsum_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(invsum.toString());
		out.flush();
		out.close();	
	}

	private static void geraSumTech() throws Exception {
		File f = new File(dir + "/sumtech_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write(sumtech.toString());
		out.flush();
		out.close();		
	}

	private static void geraSumarios() throws Exception{
		File f = new File(dir + "/sumarios_" + sistema + ".csv");
		BufferedWriter out = new BufferedWriter(new FileWriter(f, true));
		out.write("Aplicacao,Liberty for Java on IBM Bluemix, Liberty Core, Liberty, WebSphere traditional, Network Deployment Liberty, Network Deployment traditional, Liberty for z/OS, WebSphere traditional for z/OS\n");
		for (int i = 0; i < sumarios.size(); i++) {
			Sumary s1 = sumarios.get(i);
			out.write(s1.getFilename() + "," + s1.getBluemixLiberty() + "," + s1.getLibertyCore() + "," + s1.getLiberty() + "," + s1.getWebsphereTraditional() + "," + s1.getNdLiberty() + "," + s1.getNdTraditional() + "," + s1.getZosLiberty() + "," + s1.getZosTraditional() + "\n");
		}
		out.flush();
		out.close();
	}

	private static void geraUmArquivo(String dir, String url, String sistema)
			throws JSONException, IOException, MalformedURLException, Exception {
		JSONObject json = new JSONObject(IOUtils.toString(new URL(url)));
		
		ExcelBean bean = new ExcelBean();

		// nome da aplicacao
		String app = json.get("application").toString();
		app = app.substring(app.lastIndexOf("/")+1);
		bean.setAplicacao(app);
		
		// Inventario
		JSONObject inventory = (JSONObject) ((JSONObject)json.get("inventory")).get("summary");
		bean.getInventario().add( new API("servlets", Integer.parseInt(inventory.get("servlets").toString())));
		bean.getInventario().add( new API("jsps", Integer.parseInt(inventory.get("jsps").toString())));
		bean.getInventario().add( new API("jpaEntities", Integer.parseInt(inventory.get("jpaEntities").toString())));
		bean.getInventario().add( new API("bmpEntityBeans", Integer.parseInt(inventory.get("bmpEntityBeans").toString())));
		bean.getInventario().add( new API("cmpEntityBeans", Integer.parseInt(inventory.get("cmpEntityBeans").toString())));
		bean.getInventario().add( new API("messageDrivenBeans", Integer.parseInt(inventory.get("messageDrivenBeans").toString())));
		bean.getInventario().add( new API("singletonSessionBeans", Integer.parseInt(inventory.get("singletonSessionBeans").toString())));
		bean.getInventario().add( new API("statefulSessionBeans", Integer.parseInt(inventory.get("statefulSessionBeans").toString())));
		bean.getInventario().add( new API("statelessSessionBeans", Integer.parseInt(inventory.get("statelessSessionBeans").toString())));
		bean.getInventario().add( new API("jaxrpcConsumers", Integer.parseInt(inventory.get("jaxrpcConsumers").toString())));
		bean.getInventario().add( new API("jaxrpcProviders", Integer.parseInt(inventory.get("jaxrpcProviders").toString())));
		bean.getInventario().add( new API("jaxrsConsumers", Integer.parseInt(inventory.get("jaxrsConsumers").toString())));
		bean.getInventario().add( new API("jaxrsProviders", Integer.parseInt(inventory.get("jaxrsProviders").toString())));
		bean.getInventario().add( new API("jaxwsConsumers", Integer.parseInt(inventory.get("jaxwsConsumers").toString())));
		bean.getInventario().add( new API("jaxwsProviders", Integer.parseInt(inventory.get("jaxwsProviders").toString())));
		
		sumarizaInventario(bean.getInventario());
		
		// erros
		JSONArray errors = (JSONArray) ((JSONObject)json.get("analyze")).get("rules");
		for (int i = 0; i < errors.length(); i++) {
			String ruleName = ((JSONObject)errors.get(i)).get("ruleName").toString();
			int contador = ((JSONArray)
					         ((JSONObject)
					        		errors.get(i)).get("results")).length();
			bean.getErros().add(new Erro(ruleName, contador));
			
		}
		
		// elegivel para qual servidor
		JSONArray technologies = (JSONArray) ((JSONObject)json.get("evaluate")).get("technologies");
		for (int i = 0; i < technologies.length(); i++) {
			Technology tech = new Technology();
			tech.setTechnology(((JSONObject)technologies.get(i)).getString("technology"));
			sumtech.count(tech.getTechnology());
			tech.addServer("bluemixLiberty", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("bluemixLiberty").toString()));
			tech.addServer("libertyCore", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("libertyCore").toString()));
			tech.addServer("liberty", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("liberty").toString()));
			tech.addServer("websphereTraditional", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("websphereTraditional").toString()));
			tech.addServer("ndLiberty", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("ndLiberty").toString()));
			tech.addServer("ndTraditional", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("ndTraditional").toString()));
			tech.addServer("zosLiberty", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("zosLiberty").toString()));
			tech.addServer("zosTraditional", Boolean.parseBoolean(((JSONObject)technologies.get(i)).get("zosTraditional").toString()));
			bean.getTechnologies().add(tech);	
		}

		// gera o HTML na saída
		generateHTML(dir, bean, sistema);
		
		// pega sumario e salva
		Sumary suma = new Sumary(); 
		suma.setFilename(bean.getAplicacao());
		JSONObject sumaries = ((JSONObject)((JSONObject)json.get("evaluate")).get("summary"));
		suma.setBluemixLiberty(((boolean)sumaries.get("bluemixLiberty"))?"X":"");
		suma.setLibertyCore(((boolean)sumaries.get("libertyCore"))?"X":"");
		suma.setLiberty(((boolean)sumaries.get("liberty"))?"X":"");
		suma.setWebsphereTraditional(((boolean)sumaries.get("websphereTraditional"))?"X":"");
		suma.setNdLiberty(((boolean)sumaries.get("ndLiberty"))?"X":"" );
		suma.setNdTraditional(((boolean)sumaries.get("ndTraditional"))?"X":"");
		suma.setZosLiberty(((boolean)sumaries.get("zosLiberty"))?"X":"" );
		suma.setZosTraditional(((boolean)sumaries.get("zosTraditional"))?"X":"");
		sumarios.add(suma);
		
		// grava mensagens
		JSONArray messag = (JSONArray) ((JSONObject)json.get("analyze")).get("rules");
		for (int i = 0; i < messag.length(); i++) {
			String ruleName = ((JSONObject)messag.get(i)).get("ruleName").toString();
			String level = ((JSONObject)messag.get(i)).get("severity").toString();
			messages.addMessage(ruleName, level);
		}
	}

	private static void sumarizaInventario(Vector<API> inventario) {
		for (int i = 0; i < inventario.size(); i++) {
			invsum.count(inventario.get(i));
		}
		
	}

	private static void generateHTML(String dir, ExcelBean bean, String sistema) throws Exception{
		// TODO Auto-generated method stub
		BufferedWriter out = new BufferedWriter(new FileWriter(dir + "/was_" + sistema  + "_report.csv", true));
		out.write(bean.getAplicacao() + "\r");
		for (int i = 0; i < bean.getInventario().size(); i++) {
			API api = bean.getInventario().get(i);
			out.write(api.getName() + " , " + api.getCount() + "\r");
		}
		out.write("Erros\r");
		for (int i = 0; i < bean.getErros().size(); i++) {
			Erro err = bean.getErros().get(i);
			out.write(err.getErro().replaceAll(",", "-") + " , " + err.getNumeroErros() + "\r");
		}
		for (int i = 0; i < bean.getTechnologies().size(); i++) {
			Technology tech = bean.getTechnologies().get(i);
			if (i ==0) {
				out.write(",");
				for (int j = 0; j < tech.getServers().size(); j++) {
					out.write(tech.getServers().get(j).getName().replaceAll(",", "-") + " , ");
				}
			}
			out.write("\r");
			out.write(tech.getTechnology() + " , ");
			for (int j = 0; j < tech.getServers().size(); j++) {
				out.write(tech.getServers().get(j).isSupported()?"X":" ");
				out.write(",");
			}
			//out.write("\r");
		}
		out.write("\r");
		out.flush();
		out.close();
	}

}
