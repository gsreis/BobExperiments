package parser;

public class API {
	private String name;
	private int count;
	
	public API(String name, int counter) {
		this.name = name;
		this.count = counter;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
