package parser;

import java.util.Vector;

public class SummaryTech {
	
	Vector<SumTech> countTech = new Vector<>();
	
    public void count(String techname) {
    	for (int i = 0; i < countTech.size(); i++) {
			if (countTech.get(i).getName().equals(techname))
			{
				countTech.get(i).setCount(countTech.get(i).getCount()+1);
				return ;
			}
		}
    	countTech.add(new SumTech(techname));
    }
    
    @Override
    public String toString() {
    	String resp = "";
    	for (int i = 0; i < countTech.size(); i++) {
			resp += countTech.get(i).getName() + "," + countTech.get(i).getCount() + "\n";
		}
    	return resp;
    }
}

class SumTech {
	private String name; 
	private int count;
	
	public SumTech(String name) {
		this.name = name;
		this.count = 0;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}