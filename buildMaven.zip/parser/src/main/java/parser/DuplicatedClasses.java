package parser;

import java.util.Vector;

public class DuplicatedClasses {
	
	private Vector<String> packages = new Vector<String>(); 
	private Vector<String> jars = new Vector<String>();
	
	private String reason; 
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Vector<String> getPackages() {
		return packages;
	}
	public void setPackages(Vector<String> packages) {
		this.packages = packages;
	}
	public Vector<String> getJars() {
		return jars;
	}
	public void setJars(Vector<String> jars) {
		this.jars = jars;
	}


}
