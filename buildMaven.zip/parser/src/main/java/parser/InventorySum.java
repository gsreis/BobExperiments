package parser;

import java.util.Vector;

public class InventorySum {
	private Vector<API> inventario = new Vector<API>();
	public void count(API api) {
    	for (int i = 0; i < inventario.size(); i++) {
			if (inventario.get(i).getName().equals(api.getName()))
			{
				inventario.get(i).setCount(inventario.get(i).getCount()+api.getCount());
				return ;
			}
		}
    	inventario.add(new API(api.getName(), api.getCount()));		
	}
	
	@Override
	public String toString() {
		String resp = "";
		for (int i = 0; i < inventario.size(); i++) {
			resp += inventario.get(i).getName() + "," + inventario.get(i).getCount() + "\n";
		}
		return resp;
	}
}
