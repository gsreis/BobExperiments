package parser;

import java.util.Vector;

public class PotentialProblems {
	Vector<DuplicatedClasses> duplicated = new Vector<DuplicatedClasses>();
	public Vector<DuplicatedClasses> getDuplicated() {
		return duplicated;
	}
	public void setDuplicated(Vector<DuplicatedClasses> duplicated) {
		this.duplicated = duplicated;
	}
	public Vector<String> getNotreferenced() {
		return notreferenced;
	}
	public void setNotreferenced(Vector<String> notreferenced) {
		this.notreferenced = notreferenced;
	}
	Vector<String> notreferenced = new Vector<String>();

	
}
