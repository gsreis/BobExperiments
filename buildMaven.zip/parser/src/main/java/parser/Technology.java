package parser;

import java.util.Vector;

public class Technology {
	private String technology;
	private Vector<ServerType> servers = new Vector<ServerType>();

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public Vector<ServerType> getServers() {
		return servers;
	}

	public void setServers(Vector<ServerType> servers) {
		this.servers = servers;
	}
	
	public void addServer(String servername, boolean supported) {
		servers.add(new ServerType(servername, supported));
	}

}
