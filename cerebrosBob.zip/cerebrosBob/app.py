from flask import Flask, render_template, request, jsonify
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import os

app = Flask(__name__)

print("=" * 50)
print("Carregando modelo treinado...")
print("=" * 50)

# Carregar modelo e tokenizer
model_path = "./granite_finetuned_final"
base_model_name = "ibm-granite/granite-3.0-3b-a800m-instruct"

print("\n1. Carregando tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
print("   ✓ Tokenizer carregado")

print("\n2. Carregando modelo base...")
base_model = AutoModelForCausalLM.from_pretrained(
    base_model_name,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
    low_cpu_mem_usage=True
)
print("   ✓ Modelo base carregado")

print("\n3. Carregando adaptadores LoRA...")
model = PeftModel.from_pretrained(base_model, model_path)
model.eval()
print("   ✓ Modelo completo carregado e pronto!")

print("\n" + "=" * 50)
print("Servidor Flask iniciando...")
print("=" * 50 + "\n")

def generate_answer(question):
    """Gera resposta para uma pergunta usando o modelo treinado"""
    prompt = f"Pergunta: {question}\nResposta:"
    
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=200,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id
        )
    
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    # Extrair apenas a resposta
    if "Resposta:" in response:
        answer = response.split("Resposta:")[-1].strip()
    else:
        answer = response.strip()
    
    return answer

@app.route('/')
def home():
    """Página inicial"""
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    """Endpoint para processar perguntas"""
    data = request.json
    question = data.get('question', '')
    
    if not question:
        return jsonify({'error': 'Pergunta não fornecida'}), 400
    
    try:
        answer = generate_answer(question)
        return jsonify({'answer': answer})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("\n🚀 Servidor rodando em http://127.0.0.1:5000")
    print("📝 Acesse o navegador para fazer perguntas sobre computação quântica!\n")
    app.run(debug=False, host='127.0.0.1', port=5000)

# Made with Bob
