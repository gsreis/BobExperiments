#!/usr/bin/env python3
"""
Script para monitorar o progresso do treinamento
"""
import os
import time
import subprocess

def check_training_status():
    """Verifica o status do treinamento"""
    print("\n" + "="*60)
    print("MONITORAMENTO DO TREINAMENTO")
    print("="*60 + "\n")
    
    # Verificar processo
    result = subprocess.run(
        ["ps", "aux"],
        capture_output=True,
        text=True
    )
    
    if "python run_all.py" in result.stdout or "train_model.py" in result.stdout:
        print("✅ Status: TREINAMENTO EM PROGRESSO")
    else:
        print("❌ Status: NENHUM TREINAMENTO ATIVO")
    
    print()
    
    # Verificar modelo final
    if os.path.exists("granite_finetuned_final") and \
       os.path.exists("granite_finetuned_final/adapter_config.json"):
        print("✅ Modelo Final: SALVO")
        print("   Localização: ./granite_finetuned_final/")
        
        # Listar arquivos
        files = os.listdir("granite_finetuned_final")
        print(f"   Arquivos: {len(files)}")
        for f in sorted(files)[:5]:
            print(f"   - {f}")
        if len(files) > 5:
            print(f"   ... e mais {len(files) - 5} arquivos")
    else:
        print("⏳ Modelo Final: AINDA NÃO SALVO")
    
    print()
    
    # Verificar checkpoints
    if os.path.exists("granite_finetuned"):
        checkpoints = [d for d in os.listdir("granite_finetuned") 
                      if d.startswith("checkpoint-")]
        if checkpoints:
            print(f"📊 Checkpoints Intermediários: {len(checkpoints)}")
            for cp in sorted(checkpoints):
                print(f"   - {cp}")
        else:
            print("📊 Checkpoints: Nenhum ainda")
    
    print("\n" + "="*60)

if __name__ == "__main__":
    try:
        while True:
            check_training_status()
            
            # Verificar se o treinamento terminou
            if os.path.exists("granite_finetuned_final/adapter_config.json"):
                print("\n🎉 TREINAMENTO CONCLUÍDO!")
                print("Execute 'python app.py' para iniciar a interface web")
                break
            
            print("\n⏳ Aguardando... (verificando novamente em 30 segundos)")
            print("   Pressione Ctrl+C para sair do monitor\n")
            time.sleep(30)
            
    except KeyboardInterrupt:
        print("\n\n👋 Monitor encerrado pelo usuário")

# Made with Bob
