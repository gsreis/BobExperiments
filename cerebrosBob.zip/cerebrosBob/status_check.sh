#!/bin/bash
# Script para verificar o status do treinamento

echo "======================================"
echo "Status do Treinamento"
echo "======================================"
echo ""

# Verificar se o processo está rodando
if ps aux | grep -v grep | grep "python run_all.py" > /dev/null; then
    echo "✅ Processo de treinamento está ATIVO"
else
    echo "❌ Processo de treinamento NÃO está rodando"
fi

echo ""

# Verificar se o modelo foi salvo
if [ -d "granite_finetuned_final" ] && [ -f "granite_finetuned_final/adapter_config.json" ]; then
    echo "✅ Modelo treinado ENCONTRADO"
    echo "   Arquivos:"
    ls -lh granite_finetuned_final/ | tail -n +2
else
    echo "⏳ Modelo ainda NÃO foi salvo (treinamento em progresso)"
fi

echo ""

# Verificar checkpoints intermediários
if [ -d "granite_finetuned" ]; then
    checkpoint_count=$(find granite_finetuned -name "checkpoint-*" -type d 2>/dev/null | wc -l)
    if [ $checkpoint_count -gt 0 ]; then
        echo "📊 Checkpoints intermediários: $checkpoint_count"
        find granite_finetuned -name "checkpoint-*" -type d | sort
    fi
fi

echo ""
echo "======================================"

# Made with Bob
