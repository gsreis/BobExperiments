#!/usr/bin/env python3
"""
Script completo para treinar o modelo Granite e iniciar a interface web
"""
import subprocess
import sys
import os
import time
import webbrowser
from threading import Timer

def run_training():
    """Executa o treinamento do modelo"""
    print("=" * 60)
    print("ETAPA 1: TREINAMENTO DO MODELO")
    print("=" * 60)
    
    result = subprocess.run([sys.executable, "train_model.py"], 
                          capture_output=False, 
                          text=True)
    
    if result.returncode != 0:
        print("\n❌ Erro durante o treinamento!")
        sys.exit(1)
    
    print("\n✅ Treinamento concluído com sucesso!")
    return True

def open_browser():
    """Abre o navegador após 2 segundos"""
    time.sleep(2)
    webbrowser.open('http://127.0.0.1:5000')

def run_web_app():
    """Executa a aplicação web"""
    print("\n" + "=" * 60)
    print("ETAPA 2: INICIANDO INTERFACE WEB")
    print("=" * 60)
    
    # Agendar abertura do navegador
    Timer(2.0, open_browser).start()
    
    # Iniciar servidor Flask
    subprocess.run([sys.executable, "app.py"])

def main():
    """Função principal"""
    print("\n" + "🚀" * 30)
    print("SISTEMA DE Q&A COM GRANITE AI")
    print("Treinamento e Deploy Automatizado")
    print("🚀" * 30 + "\n")
    
    try:
        # Verificar se o modelo já foi treinado
        if os.path.exists("./granite_finetuned_final") and \
           os.path.exists("./granite_finetuned_final/adapter_config.json"):
            print("✅ Modelo treinado encontrado!")
            print("⏭️  Pulando etapa de treinamento...\n")
        else:
            print("📚 Modelo não encontrado. Iniciando treinamento...\n")
            run_training()
        
        # Iniciar aplicação web
        run_web_app()
        
    except KeyboardInterrupt:
        print("\n\n👋 Encerrando aplicação...")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

# Made with Bob
