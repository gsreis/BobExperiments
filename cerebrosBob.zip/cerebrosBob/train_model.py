import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import os

print("=" * 50)
print("Iniciando treinamento do modelo Granite")
print("=" * 50)

# Carregar dados de treinamento
print("\n1. Carregando dados de treinamento...")
with open('quantum_computing_qa.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

training_data = data['training_data']
print(f"   ✓ {len(training_data)} exemplos carregados")

# Preparar dataset
print("\n2. Preparando dataset...")
formatted_data = []
for item in training_data:
    text = f"Pergunta: {item['question']}\nResposta: {item['answer']}"
    formatted_data.append({"text": text})

dataset = Dataset.from_list(formatted_data)
print(f"   ✓ Dataset criado com {len(dataset)} exemplos")

# Carregar modelo Granite mais pequeno (3B)
print("\n3. Carregando modelo ibm-granite/granite-3.0-3b-a800m-instruct...")
model_name = "ibm-granite/granite-3.0-3b-a800m-instruct"

print("   - Carregando tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token
print("   ✓ Tokenizer carregado")

print("   - Carregando modelo (pode demorar alguns minutos)...")
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
    low_cpu_mem_usage=True
)
print("   ✓ Modelo carregado")

# Configurar LoRA para treinamento eficiente
print("\n4. Configurando LoRA para fine-tuning eficiente...")
lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

model = prepare_model_for_kbit_training(model)
model = get_peft_model(model, lora_config)
print("   ✓ LoRA configurado")

# Tokenizar dataset
print("\n5. Tokenizando dataset...")
def tokenize_function(examples):
    # Tokenize the text
    model_inputs = tokenizer(examples["text"], truncation=True, padding="max_length", max_length=512)
    # Set labels to be the same as input_ids for causal language modeling
    model_inputs["labels"] = model_inputs["input_ids"].copy()
    return model_inputs

tokenized_dataset = dataset.map(tokenize_function, batched=True, remove_columns=["text"])
print("   ✓ Dataset tokenizado")

# Configurar treinamento
print("\n6. Configurando parâmetros de treinamento...")
training_args = TrainingArguments(
    output_dir="./granite_finetuned",
    num_train_epochs=3,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=4,
    learning_rate=2e-4,
    fp16=True,
    save_steps=50,
    logging_steps=10,
    save_total_limit=2,
    report_to="none"
)
print("   ✓ Parâmetros configurados")

# Criar trainer
print("\n7. Criando trainer...")
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset,
)
print("   ✓ Trainer criado")

# Treinar modelo
print("\n8. Iniciando treinamento (isso pode levar alguns minutos)...")
print("-" * 50)
trainer.train()
print("-" * 50)
print("   ✓ Treinamento concluído!")

# Salvar modelo
print("\n9. Salvando modelo treinado...")
model.save_pretrained("./granite_finetuned_final")
tokenizer.save_pretrained("./granite_finetuned_final")
print("   ✓ Modelo salvo em ./granite_finetuned_final")

print("\n" + "=" * 50)
print("Treinamento concluído com sucesso!")
print("=" * 50)

# Made with Bob
