# 🔬 Assistente de Computação Quântica com IBM Granite AI

Sistema de perguntas e respostas sobre computação quântica usando o modelo IBM Granite 3B fine-tuned.

## 📋 Descrição

Este projeto implementa um assistente de IA especializado em computação quântica, treinado com o modelo IBM Granite 3.0 3B Instruct. O sistema inclui:

- **Modelo**: IBM Granite 3.0 3B (menor modelo disponível)
- **Técnica**: Fine-tuning com LoRA (Low-Rank Adaptation)
- **Dataset**: 25 perguntas e respostas sobre computação quântica em português
- **Interface**: Aplicação web com Flask

## 🚀 Estrutura do Projeto

```
cerebrosBob/
├── quantum_computing_qa.json    # Dataset de treinamento
├── train_model.py               # Script de treinamento
├── app.py                       # Aplicação Flask
├── run_all.py                   # Script principal (treina + executa)
├── requirements.txt             # Dependências
├── templates/
│   └── index.html              # Interface web
└── granite_finetuned_final/    # Modelo treinado (gerado após treino)
```

## 📦 Instalação

```bash
# Instalar dependências
pip install -r requirements.txt
```

## 🎯 Uso

### Opção 1: Executar tudo automaticamente
```bash
python run_all.py
```

Este script irá:
1. Verificar se o modelo já foi treinado
2. Se não, baixar e treinar o modelo Granite
3. Iniciar a interface web
4. Abrir automaticamente o navegador

### Opção 2: Executar manualmente

**Passo 1: Treinar o modelo**
```bash
python train_model.py
```

**Passo 2: Iniciar a interface web**
```bash
python app.py
```

**Passo 3: Acessar no navegador**
```
http://127.0.0.1:5000
```

## 💡 Exemplos de Perguntas

- O que é um qubit?
- O que é superposição quântica?
- O que é emaranhamento quântico?
- O que é o algoritmo de Shor?
- Qual a diferença entre computador quântico e clássico?
- O que é decoerência quântica?
- O que é a porta Hadamard?
- O que é NISQ?

## 🛠️ Tecnologias Utilizadas

- **PyTorch**: Framework de deep learning
- **Transformers**: Biblioteca Hugging Face
- **PEFT**: Parameter-Efficient Fine-Tuning
- **LoRA**: Low-Rank Adaptation para fine-tuning eficiente
- **Flask**: Framework web Python
- **IBM Granite 3B**: Modelo de linguagem

## 📊 Detalhes do Treinamento

- **Modelo Base**: ibm-granite/granite-3.0-3b-a800m-instruct
- **Técnica**: LoRA (r=8, alpha=16)
- **Épocas**: 3
- **Batch Size**: 1 (com gradient accumulation de 4)
- **Learning Rate**: 2e-4
- **Max Length**: 512 tokens

## 🎨 Interface Web

A interface web oferece:
- Design moderno e responsivo
- Chat interativo
- Exemplos de perguntas pré-definidos
- Respostas em tempo real
- Histórico de conversação

## 📝 Dataset

O dataset contém 25 pares de perguntas e respostas sobre:
- Conceitos básicos de computação quântica
- Qubits e estados quânticos
- Algoritmos quânticos
- Portas quânticas
- Aplicações práticas

## ⚙️ Requisitos do Sistema

- Python 3.8+
- 8GB+ RAM recomendado
- GPU opcional (acelera o treinamento)
- Conexão com internet (para download do modelo)

## 🔧 Configuração Avançada

Para modificar os parâmetros de treinamento, edite `train_model.py`:

```python
training_args = TrainingArguments(
    num_train_epochs=3,           # Número de épocas
    per_device_train_batch_size=1, # Tamanho do batch
    learning_rate=2e-4,            # Taxa de aprendizado
    # ... outros parâmetros
)
```

## 📄 Licença

Este projeto é para fins educacionais e demonstrativos.

## 🤝 Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para:
- Adicionar mais perguntas ao dataset
- Melhorar a interface
- Otimizar o treinamento
- Reportar bugs

## 📧 Contato

Para dúvidas ou sugestões, abra uma issue no repositório.

---

**Desenvolvido com ❤️ usando IBM Granite AI**